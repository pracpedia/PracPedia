"use client"

import * as React from "react"
import * as SwitchPrimitive from "@radix-ui/react-switch"

import { cn } from "@/lib/utils"

function Switch({
  className,
  ...props
}: React.ComponentProps<typeof SwitchPrimitive.Root>) {
  return (
    <SwitchPrimitive.Root
      data-slot="switch"
      className={cn(
        "peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    >
      <SwitchPrimitive.Thumb
        data-slot="switch-thumb"
        className={cn(
          // Knob sized relative to track height — adapts to any track size.
          // h-[calc(100%-4px)] = 2px padding top + bottom.
          // aspect-square = perfect circle.
          // When unchecked: ml-[2px] (left padding).
          // When checked: ml-auto pushes knob to right edge, mr-[2px] = right padding.
          "bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block rounded-full ring-0 transition-all",
          "h-[calc(100%-4px)] aspect-square",
          "data-[state=unchecked]:ml-[2px]",
          "data-[state=checked]:ml-auto data-[state=checked]:mr-[2px]"
        )}
      />
    </SwitchPrimitive.Root>
  )
}

export { Switch }
