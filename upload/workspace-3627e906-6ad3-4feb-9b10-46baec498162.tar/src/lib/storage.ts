// Safe localStorage wrapper with in-memory fallback (used in client-side only)
'use client';

const inMemoryStorage: Record<string, string> = {};

let canUseLocalStorage = false;
try {
  if (typeof window !== 'undefined') {
    const testKey = '__storage_test__';
    window.localStorage.setItem(testKey, testKey);
    window.localStorage.removeItem(testKey);
    canUseLocalStorage = true;
  }
} catch {
  canUseLocalStorage = false;
}

export const safeLocalStorage = {
  getItem(key: string): string | null {
    if (canUseLocalStorage) {
      try {
        return window.localStorage.getItem(key);
      } catch {
        // fall through to in-memory
      }
    }
    return inMemoryStorage[key] !== undefined ? inMemoryStorage[key] : null;
  },

  setItem(key: string, value: string): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch {
        // fall through
      }
    }
    inMemoryStorage[key] = String(value);
  },

  removeItem(key: string): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.removeItem(key);
        return;
      } catch {
        // fall through
      }
    }
    delete inMemoryStorage[key];
  },

  clear(): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.clear();
        return;
      } catch {
        // fall through
      }
    }
    for (const key in inMemoryStorage) {
      delete inMemoryStorage[key];
    }
  },
};
