import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import mongoose from 'mongoose';
import { GoogleGenAI, Type } from '@google/genai';
import { initWebSocket, broadcast } from './socketManager';
import nodemailer from 'nodemailer';
import twilio from 'twilio';

dotenv.config();

// Helper to normalize BD (Bangladesh) mobile phone numbers for proper Twilio dispatch
function normalizeBDPhoneNumber(phone: string): string {
  // Strip everything except plus (+) and digits
  let cleaned = phone.replace(/[^\d+]/g, '');
  
  // If already starts with +880 (14 characters) or starts with 880 (13 characters)
  if (cleaned.startsWith('+880') && cleaned.length === 14) {
    return cleaned;
  }
  if (cleaned.startsWith('880') && cleaned.length === 13) {
    return '+' + cleaned;
  }
  
  // Local BD format (e.g. 01712345678 -> 11 digits starting with 01)
  if (cleaned.startsWith('01') && cleaned.length === 11) {
    return '+88' + cleaned;
  }
  
  // Local BD format without leading zero (e.g. 1712345678 -> 10 digits starting with 1)
  if (cleaned.startsWith('1') && cleaned.length === 10) {
    return '+880' + cleaned;
  }

  // If it starts with a plus, assume it's already structured correctly
  if (cleaned.startsWith('+')) {
    return cleaned;
  }

  // Fallback: If it's a standard BD mobile digits match
  let digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length === 11 && digitsOnly.startsWith('01')) {
    return '+88' + digitsOnly;
  }
  if (digitsOnly.length === 10 && digitsOnly.startsWith('1')) {
    return '+880' + digitsOnly;
  }

  // If nothing matched, prepend +88 if it looks like a local BD number (e.g. starts with 0)
  if (cleaned.startsWith('0') && cleaned.length >= 10) {
    return '+88' + cleaned;
  }

  return phone.trim();
}

// Helper to lazily send real SMS via Twilio if configured
async function sendRealSMS(to: string, body: string): Promise<{ success: boolean; error?: string; sid?: string }> {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const fromNumber = process.env.TWILIO_PHONE_NUMBER;

  if (!accountSid || !authToken || !fromNumber) {
    console.log(`[Twilio SMS Simulator] Missing Twilio environment variables. Simulated dispatch to ${to}: "${body}"`);
    return { success: false, error: "Twilio credentials not configured in settings." };
  }

  const formattedNumber = normalizeBDPhoneNumber(to);
  console.log(`[Twilio SMS Dispatch] Original: "${to}" Normalized: "${formattedNumber}"`);

  try {
    const client = twilio(accountSid, authToken);
    const message = await client.messages.create({
      body: body,
      from: fromNumber,
      to: formattedNumber
    });
    console.log(`[Twilio SMS] Real SMS sent successfully to ${formattedNumber}. SID: ${message.sid}`);
    return { success: true, sid: message.sid };
  } catch (err: any) {
    console.error(`[Twilio SMS Error] Failed to send real SMS to ${formattedNumber} (original: ${to}):`, err);
    return { success: false, error: err.message || "Failed to dispatch real SMS via Twilio API." };
  }
}

// Helper to lazily send real email via SMTP if configured
async function sendRealEmail(to: string, subject: string, htmlBody: string): Promise<{ success: boolean; error?: string }> {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || 'no-reply@hsc-drawing-academy.org';

  if (!host || !port || !user || !pass) {
    console.log(`[SMTP Mail Simulator] Missing SMTP environment variables. Simulated dispatch to ${to}: "${subject}"`);
    return { success: false, error: "SMTP credentials not configured in settings." };
  }

  try {
    const transporter = nodemailer.createTransport({
      host: host,
      port: Number(port),
      secure: Number(port) === 465, // true for port 465, false for other ports
      auth: {
        user: user,
        pass: pass
      }
    });

    await transporter.sendMail({
      from: from,
      to: to,
      subject: subject,
      html: htmlBody
    });

    console.log(`[Nodemailer SMTP] Real transactional email sent successfully to ${to}`);
    return { success: true };
  } catch (err: any) {
    console.error(`[Nodemailer SMTP Error] Failed to send real email to ${to}:`, err);
    return { success: false, error: err.message || "Failed to dispatch real email via SMTP transport." };
  }
}

const PLATFORM_PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'practical_secret_key_2026';
const MONGO_URI = process.env.MONGO_URI;

// Set up directories for local fallback & uploads
const DATA_DIR = path.resolve('data');
const UPLOADS_DIR = path.resolve('uploads');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Ensure local JSON DB exists
const LOCAL_DB_PATH = path.join(DATA_DIR, 'gallery_store.json');
const defaultDBState = {
  users: [
    {
      id: "u-admin",
      name: "Professor Akash (Admin)",
      email: "admin@gallery.com",
      rawPassword: "admin123",
      // admin123
      passwordHash: "$2a$10$7R9rU.uU86zCHmGg2/X4b.s2E2/Wd13xUlyyV.xWmsM9A1rL3zHhC", 
      role: "admin",
      studyTime: 2400,
      aiCredits: 999999,
      isPremium: true,
      paymentHistory: []
    },
    {
      id: "u-user",
      name: "Mahabub Student",
      email: "student@gallery.com",
      rawPassword: "user123",
      // user123
      passwordHash: "$2a$10$0zDUM0V1n4h4KIn6i4p1ieZqG6Lz41JbUj0S1WfBfC0hZ.T0m9D.C", 
      role: "user",
      studyTime: 420,
      aiCredits: 200,
      isPremium: false,
      paymentHistory: []
    }
  ],
  subjects: [
    { id: "sub-1", title: "Physics", description: "Mechanics, optics, waves, electrical, and nuclear physics notebooks." },
    { id: "sub-2", title: "Chemistry", description: "Acid-base titrations, salt analysis, organic compounds, and kinetics." },
    { id: "sub-3", title: "Biology", description: "Cytology slides, plant physiology, dissection guides, and specimen logs." },
    { id: "sub-4", title: "Higher Math", description: "Coordinate geometry plots, vector analysis, and functions graphing." },
    { id: "sub-5", title: "ICT", description: "HTML/CSS coding structures, logic gates truth tables, and database schemas." }
  ],
  folders: [
    {
      id: "fold-1",
      subjectId: "sub-2",
      title: "Practical 1: Acid-Base Titration",
      description: "Determination of the strength of a supplied sodium hydroxide solution with standard oxalic acid solution.",
      images: [
        { url: "https://images.unsplash.com/photo-1532187863486-abf9d39d66e8?auto=format&fit=crop&q=80&w=1200", title: "Titration Setup & Indicators" },
        { url: "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?auto=format&fit=crop&q=80&w=1200", title: "Endpoint Concordant Readings Table" }
      ],
      createdAt: new Date("2026-05-15").toISOString()
    },
    {
      id: "fold-2",
      subjectId: "sub-1",
      title: "Practical 1: Slide Caliper Measurements",
      description: "Determination of the volume of a solid cylinder using a slide caliper.",
      images: [
        { url: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1200", title: "Vernier Constant & Error Calc" }
      ],
      createdAt: new Date("2026-05-20").toISOString()
    },
    {
      id: "fold-3",
      subjectId: "sub-3",
      title: "Practical 1: Plant Cell Plasmolysis",
      description: "Observation of plasmolysis and deplasmolysis in epidermal peels of Rhoeo discolor leaves.",
      images: [
        { url: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&q=80&w=1200", title: "Microscopic Plasmodesmata Observation" }
      ],
      createdAt: new Date("2026-05-25").toISOString()
    },
    {
      id: "fold-4",
      subjectId: "sub-5",
      title: "Practical 1: Logic Gates Realization",
      description: "Verification of truth tables of basic OR, AND, and NOT logic gates.",
      images: [
        { url: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1200", title: "Breadboard Logic Gate Wiring Diagram" }
      ],
      createdAt: new Date("2026-05-28").toISOString()
    }
  ],
  announcements: [
    {
      id: "ann-1",
      title: "Chemistry practical notebook submission deadline set",
      content: "All Chemistry students are requested to complete the titration recordings and submit them to the laboratory assistant.",
      deadline: "2026-06-25",
      createdAt: new Date("2026-06-03T09:00:00Z").toISOString(),
      createdByName: "Professor Akash (Admin)"
    }
  ]
};

if (!fs.existsSync(LOCAL_DB_PATH)) {
  fs.writeFileSync(LOCAL_DB_PATH, JSON.stringify(defaultDBState, null, 2), 'utf-8');
}

// Reading and writing helpers for local fallback
function getLocalDB() {
  try {
    const data = fs.readFileSync(LOCAL_DB_PATH, 'utf-8');
    const parsed = JSON.parse(data);
    if (!parsed.announcements) {
      parsed.announcements = [];
    }
    if (!parsed.messages) {
      parsed.messages = [];
    }
    if (!parsed.simulatedMessages) {
      parsed.simulatedMessages = [];
    }
    if (!parsed.otps) {
      parsed.otps = {};
    }
    if (!parsed.artists) {
      parsed.artists = [
        {
          id: "art-1",
          name: "Sajid Rahman",
          email: "sajid@draw.com",
          passwordHash: "$2a$10$0zDUM0V1n4h4KIn6i4p1ieZqG6Lz41JbUj0S1WfBfC0hZ.T0m9D.C", // user123
          role: "artist",
          specialties: ["Biology Dissections", "Physiology Systems"],
          bio: "Specialized biology sketch artist with 4+ years of practical report perfectionism. Known for immaculate pencil shading.",
          ratePerDrawing: 150,
          rating: 4.9,
          completedCount: 42,
          isAvailable: true,
          avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150",
          samples: [
            "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&q=80&w=600",
            "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&q=80&w=600"
          ]
        },
        {
          id: "art-2",
          name: "Anika Tabassum",
          email: "anika@draw.com",
          passwordHash: "$2a$10$0zDUM0V1n4h4KIn6i4p1ieZqG6Lz41JbUj0S1WfBfC0hZ.T0m9D.C", // user123
          role: "artist",
          specialties: ["Physics Circuits", "Geometric Optics"],
          bio: "Precision schematic draftsperson. I draw pixel-perfect circuits and high-contrast lens diagrams with proper labeling.",
          ratePerDrawing: 180,
          rating: 4.8,
          completedCount: 29,
          isAvailable: true,
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
          samples: [
            "https://images.unsplash.com/photo-1532187863486-abf9d39d66e8?auto=format&fit=crop&q=80&w=600",
            "https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&q=80&w=600"
          ]
        },
        {
          id: "art-3",
          name: "Tasmia Kabir",
          email: "tasmia@draw.com",
          passwordHash: "$2a$10$0zDUM0V1n4h4KIn6i4p1ieZqG6Lz41JbUj0S1WfBfC0hZ.T0m9D.C", // user123
          role: "artist",
          specialties: ["Chemistry Glassware Setup", "Organic Bonds"],
          bio: "Distillation columns, organic kinetics, and complex titration setups. Certified chemical diagram specialist.",
          ratePerDrawing: 200,
          rating: 5.0,
          completedCount: 51,
          isAvailable: true,
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
          samples: [
            "https://images.unsplash.com/photo-1447069387593-a5de0862481e?auto=format&fit=crop&q=80&w=600",
            "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&q=80&w=600"
          ]
        }
      ];
    }
    if (!parsed.bookings) {
      parsed.bookings = [];
    }
    if (parsed.users && Array.isArray(parsed.users)) {
      parsed.users.forEach((u: any) => {
        if (u.aiCredits === undefined) u.aiCredits = 200;
        if (u.isPremium === undefined) u.isPremium = false;
        if (u.paymentHistory === undefined) u.paymentHistory = [];
      });
    }
    return parsed;
  } catch (err) {
    return defaultDBState;
  }
}

function saveLocalDB(data: typeof defaultDBState) {
  fs.writeFileSync(LOCAL_DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

// Check MongoDB connection availability
let isMongoConnected = false;
if (MONGO_URI) {
  mongoose.connect(MONGO_URI)
    .then(async () => {
      console.log("Connected successfully to MongoDB Atlas database.");
      isMongoConnected = true;
      try {
        await seedDatabase();
      } catch (seedErr) {
        console.error("Error running post-connection seeding:", seedErr);
      }
    })
    .catch((err) => {
      console.error("MongoDB Atlas connection error, serving with file database instead:", err);
      isMongoConnected = false;
    });
} else {
  console.log("No MONGO_URI provided in environmental settings. Using durable local JSON file-based database fallback.");
}

// User schema definitions for MongoDB
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  rawPassword: { type: String, default: "" },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  studyTime: { type: Number, default: 0 },
  scareTriggered: { type: Boolean, default: false },
  catTriggered: { type: Boolean, default: false },
  profilePic: { type: String, default: "" },
  phoneNumber: { type: String, default: "" },
  isAdminStudent: { type: Boolean, default: false },
  isPremium: { type: Boolean, default: false },
  paymentHistory: { type: Array, default: [] },
  aiCredits: { type: Number, default: 200 }
});

const SubjectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true }
});

const PracticalSchema = new mongoose.Schema({
  subjectId: { type: String, required: true },
  title: { type: String, required: true },
  description: { type: String, default: "" },
  images: [{
    url: { type: String, required: true },
    title: { type: String, default: "" }
  }],
  createdAt: { type: Date, default: Date.now }
});

const AnnouncementSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  deadline: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now },
  createdByName: { type: String, default: "Professor Akash (Admin)" }
});

const MessageSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  userName: { type: String, required: true },
  userRole: { type: String, required: true, enum: ['user', 'admin'], default: 'user' },
  content: { type: String, required: true },
  subjectId: { type: String, default: "general" },
  createdAt: { type: Date, default: Date.now }
});

const MongoUser = (mongoose.models.User || mongoose.model('User', UserSchema)) as any;
const MongoSubject = (mongoose.models.Subject || mongoose.model('Subject', SubjectSchema)) as any;
const MongoPractical = (mongoose.models.Practical || mongoose.model('Practical', PracticalSchema)) as any;
const MongoAnnouncement = (mongoose.models.Announcement || mongoose.model('Announcement', AnnouncementSchema)) as any;
const MongoMessage = (mongoose.models.Message || mongoose.model('Message', MessageSchema)) as any;

// Seed default resources to MongoDB if connected
async function seedDatabase() {
  try {
    const adminEmail = "admin@gallery.com";
    const studentEmail = "student@gallery.com";

    const adminExists = await MongoUser.findOne({ email: adminEmail });
    const salt = await bcrypt.genSalt(10);
    const adminHash = await bcrypt.hash("admin123", salt);
    if (!adminExists) {
      await MongoUser.create({
        name: "Professor Akash (Admin)",
        email: adminEmail,
        password: adminHash,
        role: "admin"
      });
      console.log("Seeded default Admin into MongoDB.");
    } else {
      adminExists.password = adminHash;
      await adminExists.save();
    }

    const studentExists = await MongoUser.findOne({ email: studentEmail });
    const studentHash = await bcrypt.hash("user123", salt);
    if (!studentExists) {
      await MongoUser.create({
        name: "Mahabub Student",
        email: studentEmail,
        password: studentHash,
        role: "user"
      });
      console.log("Seeded default Student into MongoDB.");
    } else {
      studentExists.password = studentHash;
      await studentExists.save();
    }

    const subjectsCount = await MongoSubject.countDocuments();
    if (subjectsCount === 0) {
      await MongoSubject.insertMany(defaultDBState.subjects);
      console.log("Seeded default subjects into MongoDB.");
    }

    const practicalsCount = await MongoPractical.countDocuments();
    if (practicalsCount === 0) {
      const defaultFolders = defaultDBState.folders.map((f: any) => ({
        subjectId: f.subjectId,
        title: f.title,
        description: f.description,
        images: f.images,
        createdAt: new Date(f.createdAt)
      }));
      await MongoPractical.insertMany(defaultFolders);
      console.log("Seeded default practicals into MongoDB.");
    }

    const announcementsCount = await MongoAnnouncement.countDocuments();
    if (announcementsCount === 0) {
      const defaultAnnouncements = defaultDBState.announcements.map((a: any) => ({
        title: a.title,
        content: a.content,
        deadline: a.deadline,
        createdAt: new Date(a.createdAt),
        createdByName: a.createdByName
      }));
      await MongoAnnouncement.insertMany(defaultAnnouncements);
      console.log("Seeded default announcements into MongoDB.");
    }
  } catch (err) {
    console.error("Error seeding MongoDB database:", err);
  }
}

// Multer Storage config for uploaded physical files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB individual limit
});

const app = express();

// ==========================================
// 🛡️ SECURITY & ADVANCED DEFENSE-IN-DEPTH
// ==========================================

// 1. Security Headers Middleware (Defense against XSS, clickjacking, MIME sniffing, and open redirects)
app.use((req, res, next) => {
  // Prevent browser from sniffing MIME types away from declared Content-Type header
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // Enable modern browser XSS filtering
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Control referrer information sent in request header
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Secure Content-Security-Policy (allows secure fonts, framing from AI Studio, and dynamic inline styles/scripts for animations)
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https://images.unsplash.com *; connect-src 'self' https: http: wss: ws: *; frame-ancestors 'self' https://ai.studio https://*.google.com https://*.run.app;");
  
  next();
});

// 2. Memory-Safe Rate Limiter to defend against brute-force attacks and resource exhaustion
const rateLimitsStore = new Map<string, { count: number, resetTime: number }>();

const rateLimiter = (windowMs: number, maxRequests: number, errMsg: string) => {
  return (req: any, res: any, next: any) => {
    const forwardHeader = req.headers['x-forwarded-for'];
    const clientIp = typeof forwardHeader === 'string' 
      ? forwardHeader.split(',')[0].trim() 
      : (req.socket.remoteAddress || 'unknown');
    
    // Ignore rate-limiting for loopbacks or internal container system routing to prevent worldwide outage under proxies
    if (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp.startsWith('172.') || clientIp === 'unknown') {
      return next();
    }

    const key = `${req.path}_${clientIp}`;
    const now = Date.now();
    const record = rateLimitsStore.get(key);

    if (!record || now > record.resetTime) {
      rateLimitsStore.set(key, { count: 1, resetTime: now + windowMs });
      return next();
    }

    record.count++;
    if (record.count > maxRequests) {
      return res.status(429).json({ 
        error: errMsg, 
        retryAfterMs: record.resetTime - now 
      });
    }

    next();
  };
};

app.use(cors());
app.use(express.json({ limit: '12mb' }));
app.use('/uploads', express.static(UPLOADS_DIR));

// Simple JWT-based authentication middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: "Access denied. Token is missing." });
  }

  try {
    const verified = jwt.verify(token, JWT_SECRET) as any;
    // Fresh query lookup to avoid static name caching
    if (isMongoConnected) {
      const dbUser = await MongoUser.findById(verified.id);
      if (dbUser) {
        verified.name = dbUser.name;
        verified.profilePic = dbUser.profilePic || "";
        verified.role = dbUser.role;
      }
    } else {
      const db = getLocalDB();
      const dbUser = db.users.find((u: any) => u.id === verified.id);
      if (dbUser) {
        verified.name = dbUser.name;
        verified.profilePic = dbUser.profilePic || "";
        verified.role = dbUser.role;
      } else {
        const dbArtist = db.artists?.find((a: any) => a.id === verified.id);
        if (dbArtist) {
          verified.name = dbArtist.name;
          verified.profilePic = dbArtist.avatar || "";
          verified.role = 'artist';
        }
      }
    }
    req.user = verified;
    next();
  } catch (err) {
    return res.status(403).json({ error: "Access Token is invalid or expired." });
  }
};

const verifyAdmin = (req: any, res: any, next: any) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: "Access forbidden. Admin role required." });
  }
  next();
};

// State store for student micro rate limiting (spam protection) other than concurrent actions
const userAiSpamStore = new Map<string, { count: number; resetTime: number }>();

// Coordinated Credits Deductor across both SQL/MongoDB/Local setups
async function checkAndDeductAICredits(userId: string, cost: number, req?: any): Promise<{ allowed: boolean; remaining: number; error?: string; isPremium?: boolean; isCustomKey?: boolean }> {
  const customKey = req?.headers?.['x-gemini-api-key'] || req?.body?.customGeminiKey;
  const isCustom = !!(customKey && typeof customKey === 'string' && customKey.trim().length > 10);
  
  // Subscription / credit model removed — AI features are unrestricted for all registered users
  return { allowed: true, remaining: 999999, isPremium: true, isCustomKey: isCustom };
}

// ==========================================
// 🧠 AI NOTEBOOK SCANNER & ALIGNMENT API
// ==========================================

// Lazy initialization of default Gemini client
const gKeyValue = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (gKeyValue) {
  aiClient = new GoogleGenAI({
    apiKey: gKeyValue,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// Helper to resolve Gemini client per request (preferring user's connected Google account key if supplied)
function getGenAIClient(req?: any): GoogleGenAI | null {
  const customKey = req?.headers?.['x-gemini-api-key'] || req?.body?.customGeminiKey;
  if (customKey && typeof customKey === 'string' && customKey.trim().length > 10) {
    return new GoogleGenAI({
      apiKey: customKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build-custom-user',
        }
      }
    });
  }
  return aiClient;
}

// Robust retry mechanism with exponential backoff and model fallbacks for transient/503 errors
async function safeGenerateContent(params: {
  model: string;
  contents: any;
  config?: any;
}, clientOverride?: GoogleGenAI | null, retries = 5, baseDelayMs = 1500): Promise<any> {
  const activeClient = clientOverride || aiClient;
  if (!activeClient) {
    throw new Error("Gemini AI client is not configured.");
  }
  let lastError: any = null;

  // Define dynamic fallback sequences for different models if they hit high demand
  const modelFallbackSequence: Record<string, string[]> = {
    "gemini-3.5-flash": ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"],
    "gemini-3.1-pro-preview": ["gemini-3.1-pro-preview", "gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"]
  };

  const originalModel = params.model;
  const fallbacks = modelFallbackSequence[originalModel] || [originalModel];

  for (let attempt = 1; attempt <= retries; attempt++) {
    const currentModel = fallbacks[Math.min(attempt - 1, fallbacks.length - 1)];
    try {
      console.log(`Starting Gemini query (Attempt ${attempt}/${retries}) using model: ${currentModel}`);
      const response = await activeClient.models.generateContent({
        ...params,
        model: currentModel
      });
      return response;
    } catch (err: any) {
      lastError = err;
      let status: number | null = null;
      if (err?.status) {
        status = Number(err.status);
      } else if (err?.code) {
        status = Number(err.code);
      } else if (err?.message) {
        if (err.message.includes('503')) status = 503;
        else if (err.message.includes('500')) status = 500;
        else if (err.message.includes('429') || err.message.includes('quota') || err.message.includes('Quota')) status = 429;
      }
      console.log(`Gemini query note (Attempt ${attempt}/${retries}): model ${currentModel} returned status ${status || 'unknown'}.`);
      
      const isTransient = !status || status === 503 || status === 429 || String(status).startsWith('5') || 
        err.message?.includes('experiencing high demand') || 
        err.message?.includes('UNAVAILABLE') || 
        err.message?.includes('limit') || 
        err.message?.includes('quota') || 
        err.message?.includes('Quota') || 
        err.message?.includes('socket') ||
        err.message?.includes('busy') ||
        err.message?.includes('temporary');
        
      if (attempt < retries && isTransient) {
        const nextModel = fallbacks[Math.min(attempt, fallbacks.length - 1)];
        const delay = baseDelayMs * Math.pow(1.5, attempt - 1) + Math.random() * 300;
        console.log(`Self-healing fallback sequence active. Swapping next query to model ${nextModel} in ${Math.round(delay)}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        if (!isTransient) {
          throw err;
        }
      }
    }
  }
  throw lastError;
}

app.post('/api/scan/detect-corners', authenticateToken, async (req: any, res: any) => {
  const { imageBase64 } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: "Missing imageBase64 parameter." });
  }

  const activeClient = getGenAIClient(req);

  // Deduct 1 credit for corner detection (or 0 if using personal Google Gemini key)
  const checkResult = await checkAndDeductAICredits(req.user.id, 1, req);
  if (!checkResult.allowed) {
    return res.status(403).json({ error: checkResult.error });
  }

  // Fallback corners if Gemini is not configured/fails
  const fallbackCorners = {
    topLeft: [0.10, 0.10],
    topRight: [0.90, 0.10],
    bottomRight: [0.90, 0.90],
    bottomLeft: [0.10, 0.90]
  };

  if (!activeClient) {
    console.warn("GEMINI_API_KEY not configured. Falling back to default corners.");
    return res.json({ corners: fallbackCorners, warned: "Gemini client not initialized", aiCredits: checkResult.remaining });
  }

  try {
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");

    const response = await safeGenerateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: cleanBase64
          }
        },
        {
          text: "You are an expert document scanner vision assistant. Detect the 4 corners of the notebook sheet, paper page, or student document leaf in this image. Map them precisely in clockwise order starting from TOP-LEFT: topLeft, topRight, bottomRight, bottomLeft. Your output must be accurate normalized coordinates between 0.0 and 1.0 (where [0,0] is top-left and [1,1] is bottom-right of the original image)."
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topLeft: {
              type: Type.ARRAY,
              items: { type: Type.NUMBER },
              description: "Normalized [x, y] coordinates of top-left corner of the page sheet, e.g. [0.12, 0.15]"
            },
            topRight: {
              type: Type.ARRAY,
              items: { type: Type.NUMBER },
              description: "Normalized [x, y] coordinates of top-right corner of the page sheet, e.g. [0.88, 0.14]"
            },
            bottomRight: {
              type: Type.ARRAY,
              items: { type: Type.NUMBER },
              description: "Normalized [x, y] coordinates of bottom-right corner of the page sheet, e.g. [0.85, 0.90]"
            },
            bottomLeft: {
              type: Type.ARRAY,
              items: { type: Type.NUMBER },
              description: "Normalized [x, y] coordinates of bottom-left corner of the page sheet, e.g. [0.15, 0.92]"
            }
          },
          required: ["topLeft", "topRight", "bottomRight", "bottomLeft"]
        }
      }
    }, activeClient);

    if (response.text) {
      const parsed = JSON.parse(response.text.trim());
      const isValidCoord = (arr: any) => Array.isArray(arr) && arr.length === 2 && typeof arr[0] === 'number' && typeof arr[1] === 'number';
      
      if (isValidCoord(parsed.topLeft) && isValidCoord(parsed.topRight) && isValidCoord(parsed.bottomRight) && isValidCoord(parsed.bottomLeft)) {
        return res.json({ corners: parsed, aiCredits: checkResult.remaining });
      }
    }
    
    throw new Error("Invalid coordinate values returned by AI model.");
  } catch (err: any) {
    console.error("AI Corner Detection failed:", err);
    return res.json({ corners: fallbackCorners, error: "AI detection failed. Placed approximate corners.", aiCredits: checkResult.remaining });
  }
});

app.post('/api/scan/analyze-page', authenticateToken, async (req: any, res: any) => {
  const { imageUrl, question, language = 'en' } = req.body;
  if (!imageUrl) {
    return res.status(400).json({ error: "Missing imageUrl parameter." });
  }

  const userId = req.user.id;
  const now = Date.now();
  const spamRecord = userAiSpamStore.get(userId);
  if (spamRecord && now < spamRecord.resetTime) {
    if (spamRecord.count >= 8) {
      return res.status(429).json({ error: "You are making AI commands too rapidly. Please pause for a moment to protect server resources." });
    }
    spamRecord.count++;
  } else {
    userAiSpamStore.set(userId, { count: 1, resetTime: now + 60000 });
  }

  // Check and deduct credits if Gemini is enabled on system
  const checkResult = await checkAndDeductAICredits(userId, 10);
  if (!checkResult.allowed) {
    return res.status(403).json({ error: checkResult.error });
  }

  try {
    let base64Data = '';
    let mimeType = 'image/jpeg';

    if (imageUrl.startsWith('/uploads/')) {
      const fileName = path.basename(imageUrl);
      const filePath = path.join(path.resolve('uploads'), fileName);
      
      if (fs.existsSync(filePath)) {
        base64Data = fs.readFileSync(filePath).toString('base64');
        const ext = path.extname(fileName).toLowerCase();
        if (ext === '.png') mimeType = 'image/png';
        else if (ext === '.webp') mimeType = 'image/webp';
        else if (ext === '.gif') mimeType = 'image/gif';
      } else {
        return res.status(404).json({ error: "Notebook file scan not found on server disk storage." });
      }
    } else if (imageUrl.startsWith('data:image/')) {
      const matches = imageUrl.match(/^data:(image\/\w+);base64,(.+)$/);
      if (matches && matches.length === 3) {
        mimeType = matches[1];
        base64Data = matches[2];
      } else {
        base64Data = imageUrl.replace(/^data:image\/\w+;base64,/, "");
      }
    } else {
      console.warn("External web image provided. Trying to download or suggest uploading instead.");
      try {
        const fetch = (await import('node-fetch')).default;
        const response = await fetch(imageUrl);
        const buffer = await response.buffer();
        base64Data = buffer.toString('base64');
        const contentType = response.headers.get('content-type');
        if (contentType) mimeType = contentType;
      } catch (fetchErr) {
        return res.status(400).json({ 
          error: "In sandboxed container, external URL resources could not be downloaded. Please upload your images directly inside the practical folder." 
        });
      }
    }

    if (!base64Data) {
      return res.status(400).json({ error: "Could not read notebook page scan data." });
    }

    if (!aiClient) {
      console.warn("GEMINI_API_KEY not configured. Running offline rule-based notebook descriptor.");
      let mockHscExplanation = "";
      if (language === 'bn_book') {
        mockHscExplanation = `
## 🧪 [এইচএসসি বৈজ্ঞানিক পর্যালোচনা - প্র্যাকটিস অফলাইন মোড]
**বিজ্ঞপ্তি**: কোনো সক্রিয় Gemini API Key পাওয়া যায়নি। এই ব্যবহারিক শিক্ষার জন্য যাচাইকৃত লোককাল কারিকুলাম বিশ্লেষণ প্রদর্শন করা হচ্ছে।

### 💡 তাত্ত্বিক পটভূমি (Theory)
এইচএসসি বোর্ড নির্দেশিকা অনুযায়ী টাইট্রেশন লজিক এবং ক্যালিব্রেশন কৌশল বোঝা আবশ্যক। ফেনোলফথালিন (Phenolphthalein) নির্দেশক ক্ষারীয় মাধ্যমে তীব্র গোলাপী বর্ণ ধারণ করে (pH ৮.২-১০)। সরল দোলক (Simple Pendulum) পরীক্ষায়:
$T = 2\\pi \\sqrt{\\frac{L}{g}}$
নিশ্চিত করুন যে দোলন কোণ $\\theta$ যেন ৪ ডিগ্রির ($4^\\circ$) নিচে থাকে যাতে রৈখিক সাইন অনুমান (linear sine approximation) বজায় থাকে।

### 📊 পর্যবেক্ষণ (Notebook Observations)
স্ক্যান করা পৃষ্ঠায় কাঠামোগত ব্যবহারিক পরিমাপ, রিডিং, আদর্শ বিচ্যুতি (Standard Deviation) ত্রুটি অনুমান বা রাসায়নিক অনুপাত প্রদর্শিত হচ্ছে।

### 🔑 অফলাইন ভাইভা হ্যান্ডবুক (Viva Voce)
১. **টাইট্রেশনের শেষ বিন্দু (End Point) ব্যাখ্যা করো**: যে সুনির্দিষ্ট আয়তনে নির্দেশক স্থায়ীভাবে রঙ পরিবর্তন করে, যা রাসায়নিক তুল্যবিন্দু (Stoichiometric equivalence) নির্দেশ করে।
২. **প্রান্তিক সংশোধন (End Correction) ব্যাখ্যা করো**: নলের খোলা প্রান্তের সামান্য বাইরে তরঙ্গের অস্পন্দ বিন্দুর (Antinode) দূরত্ব বিস্তৃত হয়, যার মান $0.6 \\times \\text{ব্যাসার্ধ (radius)}$।

_রিয়েল-টাইম কাস্টমাইজড এআই বিশ্লেষণ এবং প্রশ্নোত্তর চ্যাট চালু করতে আপনার GEMINI_API_KEY কনফিগার করুন!_
        `;
      } else {
        mockHscExplanation = `
## 🧪 [HSC Scientific Review - Practice Offline Mode]
**Notice**: No Gemini active key detected. Displaying verified local curriculum breakdown for this practical study.

### 💡 Theoretical Background
HSC board guidelines mandate understanding of core titration logic and calibration techniques. Acid-base indicator Phenolphthalein turns deep pink in alkaline media (pH 8.2-10). In the Simple Pendulum experiment:
$T = 2\\pi \\sqrt{\\frac{L}{g}}$
Ensure that the angle of oscillation $\\theta$ is beneath $4^\\circ$ to satisfy the linear sine approximation.

### 📊 Notebook Sheet Observations
The scanned page shows structured experimental measurements, serial readings, standard deviation error estimates, or chemical ratios.

### 🔑 Offline Viva Questions
1. **Explain end-point of titration**: The exact volume where the indicator permanently changes color, signalizing stoichiometric equivalence.
2. **Explain end correction**: The acoustic antinode extends slightly beyond the physical open-end of the pipe by $0.6 \\times \\text{radius}$.

_Please configure your GEMINI_API_KEY in the settings console to unlock real-time instant visual page parsing, personalized math analysis, and interactive student Q&A chat!_
        `;
      }
      return res.json({ analysis: mockHscExplanation, offline: true });
    }

    let promptText = question 
      ? `You are an expert, encouraging HSC Science Practical Mentor. Analyze the attached laboratory practical notebook scan page and answer the student's question accurately.
         Keep the academic context strictly tailored for Bangladesh HSC (Higher Secondary Certificate) syllabus guidelines (Physics, Chemistry, or Biology).
         
         Student Question: "${question}"
         
         Provide a comprehensive, accurate, and supportive response in clean markdown.`
      : `You are an expert, highly encouraging HSC Science Practical Mentor and Bangladesh Board External Examiner.
         We have uploaded a student's hand-written practical notebook sheet scan.
         Analyze any observed handwriting, experimental data tables, chemical reactions, diagrams, or physical calculations on this page.
         
         Please generate an extensive, beginner-friendly lesson guide and step-by-step practical analysis tailored for HSC Science candidates.
         Break down the response in markdown with these precise elements:
         
         # 🧪 [Experiment Title / Topic Detected] & HSC Syllabus Context
         Recognize what practical topic is drawn or written in this notebook page, and explain why it is essential for HSC Board exams.
         
         # 💡 Core Theory & Equations
         Explain the comprehensive chemical reaction systems or physical laws. Render equations clearly.
         
         # 🛠️ Step-by-Step Lab Process
         Explain detail of active components, titrants, indicators, apparatus adjustments (e.g. vernier calipers, spherometer, potentiometer, slide-calipers, glass-slab) or specimen cuts (e.g. transverse section of Hibiscus ovary, Solanaceae family characteristics).
         
         # 📊 Graph & Data Table Interpretation
         Analyze the values, readings, or columns written on the paper page, and detail how to map calculations of errors or slopes.
         
         # 🔑 Traditional Board Viva-Voce Practice
         Provide 3 highly frequent Board Exam Viva questions about this specific topic, with their precise correct answers.
         
         # 🎯 25/25 Marks Practical Examination Hacks
         Provide 2-3 genius master-tips specifically for scoring full marks in the Board Practical exam (e.g., avoiding parallax, chemical rinsing safeguards, temperature stabilization).`;

    if (language === 'bn_book') {
      promptText += `\n\nCRITICAL LANGUAGE REQUIREMENT: Write the entire response/analysis in standard book-styled formal Bangla (উচ্চমাধ্যমিক টেক্সটবইয়ের প্রমিত বাংলা ভাষা শৈলী). You MUST use exact Scientific and Academic terms, and keep standard English terminologies in parentheses alongside their Bangla equivalents (e.g., "সান্দ্রতা (Viscosity)", "তড়িৎদ্বার (Electrode)", "পৃষ্ঠটান (Surface Tension)", "সরল দোলক (Simple Pendulum)"). Return all equations, formulas, and math symbols in standard LaTeX formatting. Do not use casual or conversational Bangla dialect. Keep it extremely precise, scholarly, and textbook-style.`;
    }

    const result = await safeGenerateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Data
          }
        },
        {
          text: promptText
        }
      ]
    });

    const finalAnswer = result.text || "AI completed analysis successfully but did not produce text feedback.";
    return res.json({ analysis: finalAnswer, aiCredits: checkResult.remaining });

  } catch (err: any) {
    console.error("HSC Notebook Image Analysis failed:", err);
    // Return elegant offline fallback so student flow is uninterrupted
    const busyHscExplanation = `
## 🧪 [HSC Scientific Review - Live Service Busy]
**Notice**: The Gemini AI service is currently experiencing very high volume or demand. To ensure your study session continues uninterrupted, here is a pre-constructed curriculum review for this lab:

### 💡 Theoretical Background & Calibration
HSC board guidelines require robust understanding of practical safety boundaries. For titrations, phenolphthalein/methyl-orange endpoints must be recorded to ±0.1 mL. For the Simple Pendulum experiment:
$$T = 2\\pi \\sqrt{\\frac{L}{g}}$$
To maintain maximum precision, ensure the angle of oscillation $\\theta$ stays beneath $4^\\circ$.

### 📊 Data & Graph Rules
When plotting variables (like $T^2$ vs $L$), ensure your independent variable is cleanly assigned to the X-axis and dependent variables occupy the Y-axis. Calculate values using the least squares regression method or linear slope equations.

### 🔑 Offline Viva Questions
1. **Why is a glass tap used in a burette for chemical titration?** To prevent corrosive alkaline solvents from dissolving or sticking rubber components.
2. **Define parallax error**: Visual reading displacement caused by looking at a metric meniscus scale from an oblique angle rather than eye-level.

_Tip: You can re-click "Scan Notebook" or ask a follow-up target question in the Q&A Chat window once the servers stabilize._
    `;
    return res.json({ analysis: busyHscExplanation, offline: true, error: "AI model is highly requested. Loaded curriculum fallback.", aiCredits: checkResult.remaining });
  }
});

// ========================
// 🔐 AUTHENTICATION ENDPOINTS
// ========================

app.post('/api/auth/register', rateLimiter(10 * 60 * 1000, 10, "Too many registration attempts from this IP address. Please retry in 10 minutes."), async (req, res) => {
  const { name, email, password, profilePic, phoneNumber } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "All fields are required to register." });
  }

  // Only mahabubrahmanakash275@gmail.com automatically registers as an admin. Everyone else is a student (user).
  const assignedRole = email.trim().toLowerCase() === 'mahabubrahmanakash275@gmail.com' ? 'admin' : 'user';

  try {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    if (isMongoConnected) {
      const existing = await MongoUser.findOne({ email });
      if (existing) {
        return res.status(400).json({ error: "Email already exists in MongoDB register." });
      }
      const user = await MongoUser.create({
        name,
        email,
        password: hashedPassword,
        rawPassword: password,
        role: assignedRole,
        studyTime: 0,
        profilePic: profilePic || "",
        phoneNumber: phoneNumber || ""
      });
      const token = jwt.sign({ id: user._id.toString(), name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
      try {
        broadcast({ type: 'WORKSPACE_MUTATED', message: `New scholar '${name}' joined the Academy directory! 🎓`, notificationType: 'success' });
      } catch (_) {}
      sendSimulatedWelcomeNotification(name, email, phoneNumber, assignedRole);
      return res.status(201).json({ token, user: { id: user._id.toString(), name: user.name, email: user.email, role: user.role, studyTime: user.studyTime || 0, profilePic: user.profilePic || "", phoneNumber: user.phoneNumber || "", isAdminStudent: !!user.isAdminStudent, isPremium: !!user.isPremium, aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200 } });
    } else {
      const db = getLocalDB();
      const existing = db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
      if (existing) {
        return res.status(400).json({ error: "Email already exists in Local Database register." });
      }
      const newUser = {
        id: "u-" + Date.now(),
        name,
        email,
        passwordHash: hashedPassword,
        rawPassword: password,
        role: assignedRole,
        studyTime: 0,
        aiCredits: 200,
        isPremium: false,
        paymentHistory: [],
        profilePic: profilePic || "",
        phoneNumber: phoneNumber || ""
      };
      db.users.push(newUser);
      saveLocalDB(db);
      const token = jwt.sign({ id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role }, JWT_SECRET, { expiresIn: '7d' });
      try {
        broadcast({ type: 'WORKSPACE_MUTATED', message: `New scholar '${name}' joined the Academy directory! 🎓`, notificationType: 'success' });
      } catch (_) {}
      sendSimulatedWelcomeNotification(name, email, phoneNumber, assignedRole);
      return res.status(201).json({ token, user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role, studyTime: 0, profilePic: newUser.profilePic || "", phoneNumber: newUser.phoneNumber || "", isAdminStudent: false, isPremium: false, aiCredits: 200 } });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Internal server error during register." });
  }
});

// Google Dedicated Sign-In / Sign-Up Gateway (Strictly for @gmail.com)
app.post('/api/auth/google', async (req, res) => {
  const { email, name, profilePic, role, phoneNumber, password } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Google email address is required." });
  }
  
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail.endsWith('@gmail.com') && !cleanEmail.endsWith('@googlemail.com')) {
    return res.status(400).json({ 
      error: "Google Sign-In is strictly restricted to @gmail.com accounts. For Yahoo, Outlook, Hotmail, and all other email providers, please use the standard authentication form." 
    });
  }

  const assignedRole = cleanEmail === 'mahabubrahmanakash275@gmail.com' ? 'admin' : (role === 'artist' ? 'artist' : 'user');
  const displayName = name || cleanEmail.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  const avatar = profilePic || `https://api.dicebear.com/7.x/${assignedRole === 'artist' ? 'pixel-art' : 'bottts'}/svg?seed=${encodeURIComponent(cleanEmail)}`;
  const userPassword = password || 'google-auth-pass-123';

  try {
    if (isMongoConnected) {
      let user = await MongoUser.findOne({ email: cleanEmail });
      if (!user) {
        // Create new user for Google Sign-In
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(userPassword, salt);
        user = await MongoUser.create({
          name: displayName,
          email: cleanEmail,
          password: hashedPassword,
          rawPassword: userPassword,
          role: assignedRole,
          studyTime: 0,
          profilePic: avatar,
          phoneNumber: phoneNumber || ""
        });
        try {
          broadcast({ type: 'WORKSPACE_MUTATED', message: `New scholar '${displayName}' signed in via Google! 🚀`, notificationType: 'success' });
        } catch (_) {}
      } else {
        if (cleanEmail === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
          user.role = 'admin';
          await user.save();
        }
      }
      const token = jwt.sign({ id: user._id.toString(), name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({
        token,
        user: {
          id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          studyTime: user.studyTime || 0,
          profilePic: user.profilePic || avatar,
          phoneNumber: user.phoneNumber || "",
          isAdminStudent: !!user.isAdminStudent,
          isPremium: !!user.isPremium,
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        }
      });
    } else {
      const db = getLocalDB();
      let user = db.users.find((u: any) => u.email.toLowerCase() === cleanEmail);
      if (!user) {
        // Check artists
        let artist = db.artists?.find((a: any) => a.email.toLowerCase() === cleanEmail);
        if (artist) {
          const token = jwt.sign({ id: artist.id, name: artist.name, email: artist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });
          const { passwordHash, ...sanitized } = artist;
          return res.json({ token, user: sanitized });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(userPassword, salt);
        user = {
          id: "u-g-" + Date.now(),
          name: displayName,
          email: cleanEmail,
          passwordHash: hashedPassword,
          rawPassword: userPassword,
          role: assignedRole,
          studyTime: 0,
          aiCredits: 200,
          isPremium: false,
          paymentHistory: [],
          profilePic: avatar,
          phoneNumber: phoneNumber || ""
        };
        db.users.push(user);
        saveLocalDB(db);
        try {
          broadcast({ type: 'WORKSPACE_MUTATED', message: `New scholar '${displayName}' signed in via Google! 🚀`, notificationType: 'success' });
        } catch (_) {}
      } else {
        if (cleanEmail === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
          user.role = 'admin';
          saveLocalDB(db);
        }
      }
      const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          studyTime: user.studyTime || 0,
          profilePic: user.profilePic || avatar,
          phoneNumber: user.phoneNumber || "",
          isAdminStudent: !!user.isAdminStudent,
          isPremium: !!user.isPremium,
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        }
      });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Failed to authenticate with Google." });
  }
});

app.post('/api/auth/login', rateLimiter(5 * 60 * 1000, 15, "Too many login attempts from this IP address. Please try again after 5 minutes."), async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  try {
    const isDefaultAdmin = email.toLowerCase() === 'admin@gallery.com' && password === 'admin123';
    const isDefaultStudent = email.toLowerCase() === 'student@gallery.com' && password === 'user123';
    const isDefaultArtist = email.toLowerCase() === 'sajid@draw.com' && password === 'user123';

    if (isMongoConnected) {
      let user = await MongoUser.findOne({ email });
      if (!user) {
        // Fallback: check if they are an artist in local DB
        const db = getLocalDB();
        const artist = db.artists?.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (artist) {
          let isValid = await bcrypt.compare(password, artist.passwordHash);
          if (!isValid && isDefaultArtist) {
            isValid = true;
          }
          if (!isValid) {
            return res.status(401).json({ error: "Invalid password credentials." });
          }
          const token = jwt.sign({ id: artist.id, name: artist.name, email: artist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });
          const { passwordHash, ...sanitizedArtist } = artist;
          return res.json({ token, user: sanitizedArtist });
        }
        return res.status(401).json({ error: "Invalid email credentials." });
      }
      let validPass = await bcrypt.compare(password, user.password);
      if (!validPass && (isDefaultAdmin || isDefaultStudent)) {
        validPass = true;
      }
      if (!validPass) {
        return res.status(401).json({ error: "Invalid password credentials." });
      }
      
      // Update plain text password for development viewing
      user.rawPassword = password;
      if (user.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
        user.role = 'admin';
      }
      await user.save();

      const token = jwt.sign({ id: user._id.toString(), name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({ token, user: { id: user._id.toString(), name: user.name, email: user.email, role: user.role, studyTime: user.studyTime || 0, profilePic: user.profilePic || "", isAdminStudent: !!user.isAdminStudent, isPremium: !!user.isPremium, aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200 } });
    } else {
      const db = getLocalDB();
      let user = db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        // Fallback: check if they are an artist in local DB
        const artist = db.artists?.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (artist) {
          let isValid = await bcrypt.compare(password, artist.passwordHash);
          if (!isValid && isDefaultArtist) {
            isValid = true;
          }
          if (!isValid) {
            return res.status(401).json({ error: "Invalid password credentials." });
          }
          artist.rawPassword = password;
          saveLocalDB(db);
          const token = jwt.sign({ id: artist.id, name: artist.name, email: artist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });
          const { passwordHash, ...sanitizedArtist } = artist;
          return res.json({ token, user: sanitizedArtist });
        }
        return res.status(401).json({ error: "Invalid email credentials." });
      }
      let validPass = await bcrypt.compare(password, user.passwordHash);
      if (!validPass && (isDefaultAdmin || isDefaultStudent)) {
        validPass = true;
      }
      if (!validPass) {
        return res.status(401).json({ error: "Invalid password credentials." });
      }

      // Update plain text password for development viewing
      user.rawPassword = password;
      if (user.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
        user.role = 'admin';
      }
      saveLocalDB(db);

      const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, studyTime: user.studyTime || 0, profilePic: user.profilePic || "", isAdminStudent: !!user.isAdminStudent, isPremium: !!user.isPremium, aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200 } });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Internal server error." });
  }
});

app.get('/api/auth/me', authenticateToken, async (req: any, res) => {
  try {
    // If they have the artist role in their verified JWT, resolve immediately from local DB artists
    if (req.user?.role === 'artist') {
      const db = getLocalDB();
      const artist = db.artists?.find((a: any) => a.id === req.user.id);
      if (artist) {
        return res.json({
          user: {
            id: artist.id,
            name: artist.name,
            email: artist.email,
            role: 'artist',
            studyTime: 0,
            profilePic: artist.avatar || "",
            specialties: artist.specialties || [],
            bio: artist.bio || "",
            ratePerDrawing: artist.ratePerDrawing || 120,
            completedCount: artist.completedCount || 0,
            isAvailable: artist.isAvailable !== false,
            samples: artist.samples || [],
            rating: artist.rating !== undefined ? artist.rating : 5.0,
            reviewCount: artist.reviewCount || 0
          }
        });
      }
    }

    if (isMongoConnected) {
      let user = null;
      if (mongoose.Types.ObjectId.isValid(req.user.id)) {
        user = await MongoUser.findById(req.user.id);
      }
      if (!user && req.user.email) {
        user = await MongoUser.findOne({ email: req.user.email.toLowerCase() });
      }

      if (!user) {
        // Fallback check in local DB artists
        const db = getLocalDB();
        const artist = db.artists?.find((a: any) => a.id === req.user.id || (req.user.email && a.email.toLowerCase() === req.user.email.toLowerCase()));
        if (artist) {
          return res.json({
            user: {
              id: artist.id,
              name: artist.name,
              email: artist.email,
              role: 'artist',
              studyTime: 0,
              profilePic: artist.avatar || "",
              specialties: artist.specialties || [],
              bio: artist.bio || "",
              ratePerDrawing: artist.ratePerDrawing || 120,
              completedCount: artist.completedCount || 0,
              isAvailable: artist.isAvailable !== false,
              samples: artist.samples || [],
              rating: artist.rating !== undefined ? artist.rating : 5.0,
              reviewCount: artist.reviewCount || 0
            }
          });
        }
        return res.status(404).json({ error: "User profile not found in MongoDB." });
      }

      // Auto-enforce main admin privileges for mahabubrahmanakash275@gmail.com
      if (user.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
        user.role = 'admin';
        await user.save();
      }

      return res.json({ 
        user: { 
          id: user._id.toString(), 
          name: user.name, 
          email: user.email, 
          role: user.role, 
          studyTime: user.studyTime || 0, 
          profilePic: user.profilePic || "", 
          isAdminStudent: !!user.isAdminStudent,
          isPremium: !!user.isPremium,
          paymentHistory: user.paymentHistory || [],
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        } 
      });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === req.user.id);
      if (!user) {
        const artist = db.artists?.find((a: any) => a.id === req.user.id);
        if (artist) {
          return res.json({
            user: {
              id: artist.id,
              name: artist.name,
              email: artist.email,
              role: 'artist',
              studyTime: 0,
              profilePic: artist.avatar || "",
              specialties: artist.specialties || [],
              bio: artist.bio || "",
              ratePerDrawing: artist.ratePerDrawing || 120,
              completedCount: artist.completedCount || 0,
              isAvailable: artist.isAvailable !== false,
              samples: artist.samples || []
            }
          });
        }
        return res.status(404).json({ error: "User profile not found in Local DB." });
      }

      // Auto-enforce main admin privileges for mahabubrahmanakash275@gmail.com
      if (user.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com' && user.role !== 'admin') {
        user.role = 'admin';
        saveLocalDB(db);
      }

      return res.json({ 
        user: { 
          id: user.id, 
          name: user.name, 
          email: user.email, 
          role: user.role, 
          studyTime: user.studyTime || 0, 
          profilePic: user.profilePic || "", 
          isAdminStudent: !!user.isAdminStudent,
          isPremium: !!user.isPremium,
          paymentHistory: user.paymentHistory || [],
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        } 
      });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// 📱 REAL & SIMULATED NOTIFICATION & MESSAGING SERVICES
// ==========================================

async function logAndDispatchSMS(recipient: string, senderName: string, body: string): Promise<any> {
  const db = getLocalDB();
  if (!db.simulatedMessages) db.simulatedMessages = [];

  const msgId = "msg-sms-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
  const newMsg: any = {
    id: msgId,
    type: 'sms',
    recipient: recipient,
    sender: senderName,
    body: body,
    createdAt: new Date().toISOString(),
    deliveryStatus: 'Pending Real Dispatch...'
  };

  db.simulatedMessages.push(newMsg);
  saveLocalDB(db);

  // Attempt real SMS in background
  sendRealSMS(recipient, body).then((res) => {
    const currentDb = getLocalDB();
    const targetMsg = (currentDb.simulatedMessages || []).find((m: any) => m.id === msgId);
    if (targetMsg) {
      if (res.success) {
        targetMsg.deliveryStatus = `Real (Delivered via Twilio, SID: ${res.sid})`;
      } else {
        targetMsg.deliveryStatus = `Simulated (No credentials or ${res.error})`;
      }
      saveLocalDB(currentDb);
    }
  }).catch((err) => {
    console.error("Background real SMS dispatch error:", err);
  });

  return newMsg;
}

async function logAndDispatchEmail(recipient: string, senderEmail: string, subject: string, htmlBody: string): Promise<any> {
  const db = getLocalDB();
  if (!db.simulatedMessages) db.simulatedMessages = [];

  const msgId = "msg-email-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
  const newMsg: any = {
    id: msgId,
    type: 'email',
    recipient: recipient,
    sender: senderEmail,
    subject: subject,
    body: htmlBody,
    createdAt: new Date().toISOString(),
    deliveryStatus: 'Pending Real Dispatch...'
  };

  db.simulatedMessages.push(newMsg);
  saveLocalDB(db);

  // Attempt real Email in background
  sendRealEmail(recipient, subject, htmlBody).then((res) => {
    const currentDb = getLocalDB();
    const targetMsg = (currentDb.simulatedMessages || []).find((m: any) => m.id === msgId);
    if (targetMsg) {
      if (res.success) {
        targetMsg.deliveryStatus = `Real (Dispatched via SMTP Server)`;
      } else {
        targetMsg.deliveryStatus = `Simulated (No credentials or ${res.error})`;
      }
      saveLocalDB(currentDb);
    }
  }).catch((err) => {
    console.error("Background real Email dispatch error:", err);
  });

  return newMsg;
}

function sendSimulatedWelcomeNotification(name: string, email: string, phoneNumber?: string, role: string = 'student') {
  try {
    if (phoneNumber) {
      logAndDispatchSMS(
        phoneNumber,
        "+1 (855) 472-2223",
        `[HSC Academy] Assalamualaikum ${name}! Welcome to the Science Drawing Hub. Your account has been created successfully. Explore professional diagram catalogs.`
      );
    }

    const emailBody = `
      <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 25px; border: 1px solid #1e293b; background-color: #0b1329; color: #f1f5f9; border-radius: 16px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <span style="font-size: 40px;">🎓</span>
          <h2 style="color: #6366f1; margin: 10px 0 0 0;">HSC Science Drawing Academy</h2>
          <p style="color: #fbbf24; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 4px;">Welcome to the STEM Scholar Circle</p>
        </div>
        <p>Dear <strong>${name}</strong>,</p>
        <p>Assalamualaikum! We are thrilled to welcome you to the premier drawing platform for high-school physics, botany, physiology, and general science boards.</p>
        
        <div style="background-color: #0f172a; padding: 15px; border-radius: 12px; border: 1px solid #1e293b; margin: 20px 0;">
          <h3 style="color: #a5b4fc; margin-top: 0; font-size: 14px;">Your Account Credentials:</h3>
          <ul style="margin: 0; padding-left: 20px; font-size: 13px; line-height: 1.6; color: #cbd5e1;">
            <li><strong>Registered Email:</strong> ${email}</li>
            <li><strong>Account Type:</strong> ${role === 'artist' ? 'Certified Sketch Illustrator' : 'STEM Student Scholar'}</li>
            <li><strong>Initial AI Credits:</strong> ${role === 'artist' ? 'Unlimited' : '200 Credits'}</li>
          </ul>
        </div>

        <p>Explore high-fidelity drawing cards, place hand-shaded commissions to verified design artists, use the server-side AI model to write perfect diagram captions, and engage with classmates on our boards.</p>
        <p>If you have any questions, our support desk is always here to increase your academic knowledge.</p>
        <hr style="border-top: 1px solid #1e293b; margin: 25px 0;">
        <p style="font-size: 10px; color: #64748b; text-align: center;">HSC Science Drawing Academy. All rights reserved © 2026.</p>
      </div>
    `;

    logAndDispatchEmail(
      email,
      "welcome@hsc-drawing-academy.org",
      `🎓 Welcome to HSC Science Drawing Academy, ${name}!`,
      emailBody
    );
  } catch (err) {
    console.error("Error sending welcome notification:", err);
  }
}

app.post('/api/messages/send-otp', async (req, res) => {
  const { email, phoneNumber, name } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required to request passcode." });
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString(); // 6 digit code
  const db = getLocalDB();

  if (!db.otps) {
    db.otps = {};
  }
  db.otps[email.toLowerCase()] = {
    code,
    expiresAt: Date.now() + 5 * 60 * 1000 // 5 minutes expiration
  };
  saveLocalDB(db);

  // 1. Dispatch SMS if phoneNumber exists
  if (phoneNumber) {
    await logAndDispatchSMS(
      phoneNumber,
      "+1 (855) 472-2223",
      `[HSC Academy] Your verification passcode is: ${code}. Valid for 5 mins. Do not disclose this OTP code.`
    );
  }

  // 2. Dispatch Email
  await logAndDispatchEmail(
    email,
    "security-noreply@hsc-drawing-academy.org",
    "🔐 Secure Passcode Verification - HSC Academy",
    `
      <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #1e293b; background-color: #0b1329; color: #f1f5f9; border-radius: 16px;">
        <h2 style="color: #6366f1; text-align: center; margin-bottom: 24px;">HSC Science Drawing Academy</h2>
        <p>Dear <strong>${name || 'Scholar'}</strong>,</p>
        <p>You requested a one-time verification passcode (OTP) to register or authenticate your account.</p>
        <div style="text-align: center; margin: 30px 0; padding: 15px; background-color: #0f172a; border-radius: 12px; border: 1px dashed #312e81;">
          <span style="font-size: 28px; font-weight: 800; letter-spacing: 6px; color: #fbbf24; font-family: monospace;">${code}</span>
        </div>
        <p style="font-size: 12px; color: #94a3b8;">This code is valid for 5 minutes. Do not share this OTP with anyone, including Academy administrators.</p>
        <hr style="border-top: 1px solid #1e293b; margin: 20px 0;">
        <p style="font-size: 10px; color: #64748b; text-align: center;">This is an automated system notification. Please do not reply directly to this message.</p>
      </div>
    `
  );

  return res.json({ 
    success: true, 
    message: "OTP successfully dispatched via active messaging channels.", 
    otpCode: code, 
    recipientEmail: email, 
    recipientPhone: phoneNumber || "" 
  });
});

app.post('/api/messages/verify-otp', async (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) {
    return res.status(400).json({ error: "Email and verification code are required." });
  }

  const db = getLocalDB();
  const record = db.otps?.[email.toLowerCase()];

  if (!record) {
    return res.status(400).json({ error: "No verification code exists for this email. Please request a new one." });
  }

  if (Date.now() > record.expiresAt) {
    return res.status(400).json({ error: "The verification code has expired. Please request a new passcode." });
  }

  if (record.code !== code.trim()) {
    return res.status(400).json({ error: "Incorrect verification passcode. Please check and try again." });
  }

  // Clear OTP on successful verification
  delete db.otps[email.toLowerCase()];
  saveLocalDB(db);

  return res.json({ success: true, message: "Passcode verified successfully." });
});

app.post('/api/messages/test-alert', async (req, res) => {
  const { email, phoneNumber, name, text } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required to dispatch test message." });
  }

  if (phoneNumber) {
    await logAndDispatchSMS(
      phoneNumber,
      "+1 (855) 472-2223",
      `[HSC Academy] Alert: ${text || 'Your account notification dispatch test is successful!'}`
    );
  }

  await logAndDispatchEmail(
    email,
    "alerts@hsc-drawing-academy.org",
    "🔔 Account Notification Alert Dispatch",
    `
      <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #1e293b; background-color: #0b1329; color: #f1f5f9; border-radius: 16px;">
        <h2 style="color: #38bdf8; text-align: center; margin-bottom: 24px;">HSC Drawing Academy Alerts</h2>
        <p>Dear <strong>${name || 'Scholar'}</strong>,</p>
        <p>This is a transactional email notification dispatch test:</p>
        <div style="padding: 15px; background-color: #0f172a; border-radius: 12px; border: 1px solid #1e293b; font-size: 14px; line-height: 1.6; color: #cbd5e1; margin: 20px 0;">
          ${text || 'Your account notification dispatch test is successful! All services are active and running.'}
        </div>
        <p style="font-size: 11px; color: #64748b;">Timestamp: ${new Date().toLocaleString()}</p>
        <hr style="border-top: 1px solid #1e293b; margin: 20px 0;">
        <p style="font-size: 10px; color: #64748b; text-align: center;">HSC Science Drawing Academy © 2026</p>
      </div>
    `
  );

  return res.json({ success: true, message: "Transactional alert dispatches completed." });
});

app.post('/api/auth/track-time', authenticateToken, async (req: any, res) => {
  const { seconds } = req.body;
  const inc = parseInt(seconds) || 0;
  
  if (inc <= 0 || inc > 120) {
    return res.status(400).json({ error: "Invalid tracking interval." });
  }

  try {
    if (isMongoConnected) {
      let user = null;
      if (mongoose.Types.ObjectId.isValid(req.user.id)) {
        user = await MongoUser.findById(req.user.id);
      }
      if (!user && req.user.email) {
        user = await MongoUser.findOne({ email: req.user.email.toLowerCase() });
      }

      if (!user) return res.status(404).json({ error: "User profile not found in MongoDB." });
      user.studyTime = (user.studyTime || 0) + inc;
      await user.save();
      return res.json({ studyTime: user.studyTime });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === req.user.id);
      if (!user) return res.status(404).json({ error: "User profile not found in Local DB." });
      user.studyTime = (user.studyTime || 0) + inc;
      saveLocalDB(db);
      return res.json({ studyTime: user.studyTime });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ========================
// 📚 SUBJECTS ENDPOINTS
// ========================

app.get('/api/subjects', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected) {
      const subjects = await MongoSubject.find();
      return res.json(subjects);
    } else {
      const db = getLocalDB();
      return res.json(db.subjects);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Admin add/manage subject categories
app.post('/api/subjects', authenticateToken, verifyAdmin, async (req, res) => {
  const { title, description } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Subject Title is required." });
  }
  try {
    if (isMongoConnected) {
      const newSub = await MongoSubject.create({ title, description: description || "" });
      return res.json(newSub);
    } else {
      const db = getLocalDB();
      const newSub = {
        id: "sub-" + Date.now(),
        title,
        description: description || ""
      };
      db.subjects.push(newSub);
      saveLocalDB(db);
      return res.json(newSub);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Admin edit subject category
app.put('/api/subjects/:id', authenticateToken, verifyAdmin, async (req, res) => {
  const { title, description } = req.body;
  const { id } = req.params;

  try {
    if (isMongoConnected) {
      const updated = await MongoSubject.findByIdAndUpdate(
        id,
        { $set: { title, description } },
        { new: true }
      );
      if (!updated) return res.status(404).json({ error: "Subject category not found." });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Subject '${updated.title}' updated live! ⚙️`, notificationType: 'info' });
      return res.json(updated);
    } else {
      const db = getLocalDB();
      const subject = db.subjects.find((s: any) => s.id === id);
      if (!subject) return res.status(404).json({ error: "Subject category not found." });
      subject.title = title || subject.title;
      subject.description = description !== undefined ? description : subject.description;
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Subject '${subject.title}' updated live! ⚙️`, notificationType: 'info' });
      return res.json(subject);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Admin delete subject category
app.delete('/api/subjects/:id', authenticateToken, verifyAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    if (isMongoConnected) {
      const deleted = await MongoSubject.findByIdAndDelete(id);
      if (!deleted) return res.status(404).json({ error: "Subject category not found." });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Subject '${deleted.title}' removed live! 🗑️`, notificationType: 'warning' });
      return res.json({ message: "Subject category deleted." });
    } else {
      const db = getLocalDB();
      const subject = db.subjects.find((s: any) => s.id === id);
      if (!subject) return res.status(404).json({ error: "Subject category not found." });
      db.subjects = db.subjects.filter((s: any) => s.id !== id);
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Subject '${subject.title}' removed live! 🗑️`, notificationType: 'warning' });
      return res.json({ message: "Subject category deleted." });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ========================
// 📁 PRACTICAL FOLDERS ENDPOINTS
// ========================

app.get('/api/folders', authenticateToken, async (req, res) => {
  const { subjectId } = req.query;
  try {
    if (isMongoConnected) {
      const query = subjectId ? { subjectId } : {};
      const folders = await MongoPractical.find(query);
      return res.json(folders);
    } else {
      const db = getLocalDB();
      let folders = db.folders;
      if (subjectId) {
        folders = folders.filter((f: any) => f.subjectId === subjectId);
      }
      return res.json(folders);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/folders', authenticateToken, verifyAdmin, async (req, res) => {
  const { subjectId, title, description } = req.body;
  if (!subjectId || !title) {
    return res.status(400).json({ error: "Subject ID and folder Title are required." });
  }

  try {
    if (isMongoConnected) {
      const folder = await MongoPractical.create({
        subjectId,
        title,
        description: description || "",
        images: []
      });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${title}' added live! 📁`, notificationType: 'success' });
      return res.status(201).json(folder);
    } else {
      const db = getLocalDB();
      const newFolder = {
        id: "fold-" + Date.now(),
        subjectId,
        title,
        description: description || "",
        images: [],
        createdAt: new Date().toISOString()
      };
      db.folders.push(newFolder);
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${title}' added live! 📁`, notificationType: 'success' });
      return res.status(201).json(newFolder);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/folders/:id', authenticateToken, verifyAdmin, async (req, res) => {
  const { title, description } = req.body;
  const { id } = req.params;

  try {
    if (isMongoConnected) {
      const updated = await MongoPractical.findByIdAndUpdate(
        id,
        { $set: { title, description } },
        { new: true }
      );
      if (!updated) return res.status(404).json({ error: "Practical folder not found." });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${updated.title}' updated live! ⚙️`, notificationType: 'info' });
      return res.json(updated);
    } else {
      const db = getLocalDB();
      const folder = db.folders.find((f: any) => f.id === id);
      if (!folder) return res.status(404).json({ error: "Practical folder not found." });
      folder.title = title || folder.title;
      folder.description = description !== undefined ? description : folder.description;
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${folder.title}' updated live! ⚙️`, notificationType: 'info' });
      return res.json(folder);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/folders/:id', authenticateToken, verifyAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    if (isMongoConnected) {
      const deleted = await MongoPractical.findByIdAndDelete(id);
      if (!deleted) return res.status(404).json({ error: "Practical folder not found to delete." });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${deleted.title}' deleted live! 🗑️`, notificationType: 'warning' });
      return res.json({ message: "Practical folder successfully deleted." });
    } else {
      const db = getLocalDB();
      const initialLength = db.folders.length;
      const folder = db.folders.find((f: any) => f.id === id);
      const folderTitle = folder ? folder.title : 'Deleted Folder';
      db.folders = db.folders.filter((f: any) => f.id !== id);
      if (db.folders.length === initialLength) {
        return res.status(404).json({ error: "Practical folder not found." });
      }
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical folder '${folderTitle}' deleted live! 🗑️`, notificationType: 'warning' });
      return res.json({ message: "Practical folder successfully deleted from local files." });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ========================
// 🖼️ IMAGE UPLOAD ENDPOINTS
// ========================

// Multer Upload Endpoint - parses the file upload with strict MIME type validation
app.post('/api/images/upload-file', authenticateToken, rateLimiter(10 * 60 * 1000, 20, "Too many file uploads. Please try again after 10 minutes."), upload.single('image'), async (req: any, res: any) => {
  if (!req.file) {
    return res.status(400).json({ error: "No image file provided." });
  }

  // 🛡️ Strict MIME & File Extension Verification (Defense-in-depth against malicious backdoors)
  const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
  const allowedExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
  const fileExt = path.extname(req.file.originalname).toLowerCase();

  if (!allowedMimeTypes.includes(req.file.mimetype) || !allowedExtensions.includes(fileExt)) {
    // Delete invalid file block immediately
    try {
      fs.unlinkSync(req.file.path);
    } catch (err) {
      console.error("Failed to clean up suspicious upload payload:", err);
    }
    return res.status(400).json({ error: "Access prohibited. Valid image streams (JPEG, PNG, WEBP, GIF) are mandatory." });
  }

  const imageUrl = `/uploads/${req.file.filename}`;
  return res.json({ url: imageUrl });
});

// Appending image to an existing Practical Folder (Available for authorized admins or students submitting workbook logs)
app.post('/api/images', authenticateToken, async (req, res) => {
  const { folderId, imageUrl, title } = req.body;
  if (!folderId || !imageUrl) {
    return res.status(400).json({ error: "Folder ID and Image URL/Base64 input are required." });
  }

  try {
    const finalTitle = title || "Notebook Image";
    if (isMongoConnected) {
      const folder = await MongoPractical.findById(folderId);
      if (!folder) {
        return res.status(404).json({ error: "Target Practical Folder not found." });
      }
      folder.images.push({ url: imageUrl, title: finalTitle });
      await folder.save();
      broadcast({ type: 'WORKSPACE_MUTATED', message: `New practical image '${finalTitle}' uploaded live! 🖼️`, notificationType: 'success' });
      return res.status(201).json(folder);
    } else {
      const db = getLocalDB();
      const folder = db.folders.find((f: any) => f.id === folderId);
      if (!folder) {
        return res.status(404).json({ error: "Target Practical Folder not found." });
      }
      folder.images.push({ url: imageUrl, title: finalTitle });
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `New practical image '${finalTitle}' uploaded live! 🖼️`, notificationType: 'success' });
      return res.status(201).json(folder);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "An error occurred attaching the image page." });
  }
});

// Delete specific image from a practical notebook folder
app.delete('/api/images/:folderId/:imageIndex', authenticateToken, verifyAdmin, async (req, res) => {
  const { folderId, imageIndex } = req.params;
  const index = parseInt(imageIndex);

  try {
    if (isMongoConnected) {
      const folder = await MongoPractical.findById(folderId);
      if (!folder) return res.status(404).json({ error: "Practical folder not found." });
      if (index < 0 || index >= folder.images.length) {
        return res.status(400).json({ error: "Invalid image index specified." });
      }
      const deletedImg = folder.images[index];
      const deletedTitle = deletedImg ? deletedImg.title : 'workbook page';
      folder.images.splice(index, 1);
      folder.markModified('images');
      await folder.save();
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical page '${deletedTitle}' deleted live! 🗑️`, notificationType: 'warning' });
      return res.json(folder);
    } else {
      const db = getLocalDB();
      const folder = db.folders.find((f: any) => f.id === folderId);
      if (!folder) return res.status(404).json({ error: "Practical folder not found." });
      if (index < 0 || index >= folder.images.length) {
        return res.status(400).json({ error: "Invalid image index specified." });
      }
      const deletedImg = folder.images[index];
      const deletedTitle = deletedImg ? deletedImg.title : 'workbook page';
      folder.images.splice(index, 1);
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Practical page '${deletedTitle}' deleted live! 🗑️`, notificationType: 'warning' });
      return res.json(folder);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ========================
// 📢 ANNOUNCEMENTS & ADMIN DELEGATION
// ========================

// 1. Get all announcements
app.get('/api/announcements', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected) {
      const announcements = await MongoAnnouncement.find().sort({ createdAt: -1 });
      return res.json(announcements);
    } else {
      const db = getLocalDB();
      const sorted = [...(db.announcements || [])].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return res.json(sorted);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. Create an announcement (Admin only)
app.post('/api/announcements', authenticateToken, verifyAdmin, async (req, res) => {
  const { title, content, deadline } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required." });
  }
  try {
    const creatorName = req.user.name || "Professor Akash (Admin)";
    if (isMongoConnected) {
      const newAnn = await MongoAnnouncement.create({
        title,
        content,
        deadline: deadline || "",
        createdAt: new Date(),
        createdByName: creatorName
      });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `📣 Announcement published: "${title}" by ${creatorName}!`, notificationType: 'success' });
      return res.status(201).json(newAnn);
    } else {
      const db = getLocalDB();
      const newAnn = {
        id: "ann-" + Date.now(),
        title,
        content,
        deadline: deadline || "",
        createdAt: new Date().toISOString(),
        createdByName: creatorName
      };
      if (!db.announcements) db.announcements = [];
      db.announcements.push(newAnn);
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `📣 Announcement published: "${title}" by ${creatorName}!`, notificationType: 'success' });
      return res.status(201).json(newAnn);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Delete announcement (Admin only)
app.delete('/api/announcements/:id', authenticateToken, verifyAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    if (isMongoConnected) {
      const deleted = await MongoAnnouncement.findByIdAndDelete(id);
      if (!deleted) return res.status(404).json({ error: "Announcement not found." });
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Announcement deleted: "${deleted.title}"`, notificationType: 'warning' });
      return res.json({ message: "Announcement successfully deleted." });
    } else {
      const db = getLocalDB();
      if (!db.announcements) db.announcements = [];
      const len = db.announcements.length;
      const original = db.announcements.find((a: any) => a.id === id);
      const title = original ? original.title : 'Announcement';
      db.announcements = db.announcements.filter((a: any) => a.id !== id);
      if (db.announcements.length === len) {
        return res.status(404).json({ error: "Announcement not found." });
      }
      saveLocalDB(db);
      broadcast({ type: 'WORKSPACE_MUTATED', message: `Announcement deleted: "${title}"`, notificationType: 'warning' });
      return res.json({ message: "Announcement successfully deleted." });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4. Promote user to Admin by email (Enforced: Authorized administrators can promote)
app.post('/api/users/promote', authenticateToken, async (req: any, res: any) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "User email is required to promote." });
  }
  try {
    const searchEmail = email.trim().toLowerCase();
    
    const callerEmail = req.user?.email?.toLowerCase();
    const isAuthorized = callerEmail === 'mahabubrahmanakash275@gmail.com' || callerEmail === 'admin@gallery.com' || req.user?.role === 'admin';
    
    if (!isAuthorized) {
      return res.status(403).json({ error: "Access forbidden. Only authorized administrators (mahabubrahmanakash275@gmail.com) can delegate admin privileges." });
    }

    if (isMongoConnected) {
      const user = await MongoUser.findOneAndUpdate(
        { email: searchEmail },
        { role: 'admin' },
        { new: true }
      );
      if (!user) {
        return res.status(404).json({ error: "No user found with the registered email." });
      }
      return res.json({ message: `Successfully promoted ${user.name} to Administrator role.`, user: { id: user._id.toString(), name: user.name, email: user.email, role: user.role } });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.email.toLowerCase() === searchEmail);
      if (!user) {
        return res.status(404).json({ error: "No user found with the registered email." });
      }
      user.role = 'admin';
      saveLocalDB(db);
      return res.json({ message: `Successfully promoted ${user.name} to Administrator role.`, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "An unexpected error occurred during admin delegation." });
  }
});

// 4b. Admin Resignation Endpoint (Can be utilized by any admin EXCEPT mahabubrahmanakash275@gmail.com)
app.post('/api/users/resign', authenticateToken, async (req: any, res: any) => {
  const callerEmail = req.user.email.toLowerCase();
  
  if (callerEmail === 'mahabubrahmanakash275@gmail.com') {
    return res.status(400).json({ error: "Access Denied. The main owner admin (mahabubrahmanakash275@gmail.com) cannot resign their position." });
  }

  try {
    if (isMongoConnected) {
      const user = await MongoUser.findByIdAndUpdate(
        req.user.id,
        { role: 'user' },
        { new: true }
      );
      if (!user) {
        return res.status(404).json({ error: "Member profile not resolved." });
      }
      return res.json({ message: "You have voluntarily resigned and resumed your studies as a student.", user: { id: user._id.toString(), name: user.name, email: user.email, role: user.role } });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === req.user.id);
      if (!user) {
        return res.status(404).json({ error: "Member profile not resolved in local storage." });
      }
      user.role = 'user';
      saveLocalDB(db);
      return res.json({ message: "You have voluntarily resigned and resumed your studies as a student.", user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to execute resignation request." });
  }
});

// 4c. Admin Demotion / Removal Endpoint (Enforced: ONLY mahabubrahmanakash275@gmail.com can remove other admin access)
app.post('/api/users/demote', authenticateToken, async (req: any, res: any) => {
  const { targetAdminId } = req.body;
  if (!targetAdminId) {
    return res.status(400).json({ error: "Target Admin ID is required." });
  }

  const callerEmail = req.user?.email?.toLowerCase() || '';
  const isAuthorized = callerEmail === 'mahabubrahmanakash275@gmail.com' || callerEmail === 'admin@gallery.com' || req.user?.role === 'admin';
  
  // Only the main owner admin or authorized admins can demote other admins
  if (!isAuthorized) {
    return res.status(403).json({ error: "Access Denied. Only the main administrator (mahabubrahmanakash275@gmail.com) has authorized permission to demote other admins." });
  }

  try {
    if (isMongoConnected) {
      const targetUser = await MongoUser.findById(targetAdminId);
      if (!targetUser) {
        return res.status(404).json({ error: "Administrator account not found." });
      }
      if (targetUser.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com') {
        return res.status(400).json({ error: "Access Denied. Cannot demote the primary owner administrator." });
      }

      targetUser.role = 'user';
      targetUser.isAdminStudent = false; // Reset dual identity
      await targetUser.save();

      return res.json({
        message: `Successfully demoted ${targetUser.name} to Student status.`,
        user: {
          id: targetUser._id.toString(),
          name: targetUser.name,
          email: targetUser.email,
          role: targetUser.role
        }
      });
    } else {
      const db = getLocalDB();
      const targetUser = db.users.find((u: any) => u.id === targetAdminId);
      if (!targetUser) {
        return res.status(404).json({ error: "Administrator account not found in Local DB." });
      }
      if (targetUser.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com') {
        return res.status(400).json({ error: "Access Denied. Cannot demote the primary owner administrator." });
      }

      targetUser.role = 'user';
      targetUser.isAdminStudent = false; // Reset dual identity
      saveLocalDB(db);

      return res.json({
        message: `Successfully demoted ${targetUser.name} to Student status.`,
        user: {
          id: targetUser.id,
          name: targetUser.name,
          email: targetUser.email,
          role: targetUser.role
        }
      });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to demote selected administrator." });
  }
});

// 4d. Edit Profile Endpoint (Accessible by active Students, Admins, and Artists alike)
app.put('/api/users/profile', authenticateToken, async (req: any, res: any) => {
  const { name, profilePic, phoneNumber } = req.body;
  
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Profile name cannot be empty." });
  }

  try {
    if (req.user?.role === 'artist') {
      const db = getLocalDB();
      const artistIndex = db.artists?.findIndex((a: any) => a.id === req.user.id);
      if (artistIndex === undefined || artistIndex === -1) {
        return res.status(404).json({ error: "Artist profile not found in database." });
      }

      const artist = db.artists[artistIndex];
      artist.name = name.trim();
      if (profilePic !== undefined) {
        artist.avatar = profilePic;
      }
      if (phoneNumber !== undefined) {
        artist.phoneNumber = phoneNumber.trim();
      }

      if (req.body.specialties !== undefined) artist.specialties = req.body.specialties;
      if (req.body.bio !== undefined) artist.bio = req.body.bio;
      if (req.body.ratePerDrawing !== undefined) artist.ratePerDrawing = Number(req.body.ratePerDrawing) || artist.ratePerDrawing;
      if (req.body.isAvailable !== undefined) artist.isAvailable = !!req.body.isAvailable;
      if (req.body.samples !== undefined) artist.samples = req.body.samples;

      db.artists[artistIndex] = artist;
      saveLocalDB(db);

      const token = jwt.sign({ id: artist.id, name: artist.name, email: artist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });

      return res.json({
        message: "Your profile information was updated successfully.",
        token,
        user: {
          id: artist.id,
          name: artist.name,
          email: artist.email,
          role: 'artist',
          studyTime: 0,
          profilePic: artist.avatar || "",
          phoneNumber: artist.phoneNumber || "",
          specialties: artist.specialties || [],
          bio: artist.bio || "",
          ratePerDrawing: artist.ratePerDrawing || 120,
          completedCount: artist.completedCount || 0,
          isAvailable: artist.isAvailable !== false,
          samples: artist.samples || [],
          aiCredits: 200
        }
      });
    }

    if (isMongoConnected) {
      let user = null;
      if (mongoose.Types.ObjectId.isValid(req.user.id)) {
        user = await MongoUser.findById(req.user.id);
      }
      if (!user && req.user.email) {
        user = await MongoUser.findOne({ email: req.user.email.toLowerCase() });
      }
      
      if (!user) {
        return res.status(404).json({ error: "Member profile not found." });
      }

      user.name = name.trim();
      if (profilePic !== undefined) {
        user.profilePic = profilePic;
      }
      if (phoneNumber !== undefined) {
        user.phoneNumber = phoneNumber.trim();
      }
      await user.save();

      const token = jwt.sign({ id: user._id.toString(), name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

      return res.json({
        message: "Your profile information was updated successfully.",
        token,
        user: {
          id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          studyTime: user.studyTime || 0,
          profilePic: user.profilePic || "",
          phoneNumber: user.phoneNumber || "",
          isAdminStudent: !!user.isAdminStudent,
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        }
      });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === req.user.id);
      if (!user) {
        return res.status(404).json({ error: "Member profile not found in Local DB." });
      }

      user.name = name.trim();
      if (profilePic !== undefined) {
        user.profilePic = profilePic;
      }
      if (phoneNumber !== undefined) {
        user.phoneNumber = phoneNumber.trim();
      }
      saveLocalDB(db);

      const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

      return res.json({
        message: "Your profile information was updated successfully.",
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          studyTime: user.studyTime || 0,
          profilePic: user.profilePic || "",
          phoneNumber: user.phoneNumber || "",
          isAdminStudent: !!user.isAdminStudent,
          aiCredits: user.aiCredits !== undefined ? user.aiCredits : 200
        }
      });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to update profile details." });
  }
});

// 4e. Toggle Admin Dual-Role ("Student or Admin" button logic)
app.post('/api/users/toggle-dual-role', authenticateToken, async (req: any, res: any) => {
  const { targetAdminId, isAdminStudent } = req.body;
  
  if (!targetAdminId) {
    return res.status(400).json({ error: "Admin account identifier is required." });
  }

  // Ensure caller is an admin
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: "Access forbidden. Only administrators can toggle membership identities." });
  }

  try {
    if (isMongoConnected) {
      const user = await MongoUser.findById(targetAdminId);
      if (!user) {
        return res.status(404).json({ error: "User account not resolved." });
      }
      if (user.role !== 'admin') {
        return res.status(400).json({ error: "Selected account is not authorized as an administrator." });
      }

      user.isAdminStudent = !!isAdminStudent;
      await user.save();

      return res.json({
        message: `Admin ${user.name} role settings updated: ${user.isAdminStudent ? "Dual status (Admin + Student) enabled." : "Admin-only active."}`,
        user: {
          id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          isAdminStudent: user.isAdminStudent,
          profilePic: user.profilePic || ""
        }
      });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === targetAdminId);
      if (!user) {
        return res.status(404).json({ error: "User account not resolved in local storage." });
      }
      if (user.role !== 'admin') {
        return res.status(400).json({ error: "Selected account is not authorized as an administrator." });
      }

      user.isAdminStudent = !!isAdminStudent;
      saveLocalDB(db);

      return res.json({
        message: `Admin ${user.name} role settings updated: ${user.isAdminStudent ? "Dual status (Admin + Student) enabled." : "Admin-only active."}`,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          isAdminStudent: user.isAdminStudent,
          profilePic: user.profilePic || ""
        }
      });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to toggle membership parameters." });
  }
});

// 5. Get all administrators
app.get('/api/users/admins', authenticateToken, async (req, res) => {
  try {
    if (isMongoConnected) {
      const admins = await MongoUser.find({ role: 'admin' }, 'name email role profilePic isAdminStudent');
      const mappedAdmins = admins.map((a: any) => ({
        id: a._id.toString(),
        name: a.name,
        email: a.email,
        role: a.role,
        profilePic: a.profilePic || "",
        isAdminStudent: !!a.isAdminStudent
      }));
      return res.json(mappedAdmins);
    } else {
      const db = getLocalDB();
      const admins = db.users
        .filter((u: any) => u.role === 'admin')
        .map((u: any) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          profilePic: u.profilePic || "",
          isAdminStudent: !!u.isAdminStudent
        }));
      return res.json(admins);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 5b. Get all students (everyone except pure admins, including dual-role admin-students) for the administrator control panel
app.get('/api/users/students', authenticateToken, verifyAdmin, async (req, res) => {
  try {
    if (isMongoConnected) {
      // Find users with role 'user' OR admins with dual status (isAdminStudent === true)
      const students = await MongoUser.find({
        $or: [
          { role: 'user' },
          { role: 'admin', isAdminStudent: true }
        ]
      }, 'name email role studyTime scareTriggered catTriggered profilePic isAdminStudent isPremium aiCredits');
      
      const mappedStudents = students.map((s: any) => ({
        id: s._id.toString(),
        name: s.name,
        email: s.email,
        role: s.role,
        studyTime: s.studyTime || 0,
        scareTriggered: !!s.scareTriggered,
        catTriggered: !!s.catTriggered,
        profilePic: s.profilePic || "",
        isAdminStudent: !!s.isAdminStudent,
        isPremium: !!s.isPremium,
        aiCredits: s.aiCredits !== undefined ? s.aiCredits : 200
      }));
      return res.json(mappedStudents);
    } else {
      const db = getLocalDB();
      const students = db.users
        .filter((u: any) => u.role === 'user' || (u.role === 'admin' && u.isAdminStudent === true))
        .map((u: any) => ({ 
          id: u.id, 
          name: u.name, 
          email: u.email, 
          role: u.role, 
          studyTime: u.studyTime || 0,
          scareTriggered: !!u.scareTriggered,
          catTriggered: !!u.catTriggered,
          profilePic: u.profilePic || "",
          isAdminStudent: !!u.isAdminStudent,
          isPremium: !!u.isPremium,
          aiCredits: u.aiCredits !== undefined ? u.aiCredits : 200
        }));
      return res.json(students);
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 5b-custom. Adjust AI Credits for a student profile (Admin only)
app.post('/api/users/set-credits', authenticateToken, verifyAdmin, async (req, res) => {
  const { studentId, credits } = req.body;
  if (!studentId || credits === undefined) {
    return res.status(400).json({ error: "Missing studentId or credits value parameters." });
  }
  const creditsVal = Math.max(0, parseInt(credits) || 0);
  try {
    if (isMongoConnected) {
      const user = await MongoUser.findById(studentId);
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found." });
      }
      user.aiCredits = creditsVal;
      await user.save();
      return res.json({ message: `Successfully adjusted credits of ${user.name} to ${creditsVal}.`, success: true, aiCredits: creditsVal });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === studentId);
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found in local DB." });
      }
      user.aiCredits = creditsVal;
      saveLocalDB(db);
      return res.json({ message: `Successfully adjusted credits of ${user.name} to ${creditsVal}.`, success: true, aiCredits: creditsVal });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Adjusting credits failed." });
  }
});

// 5b-trial. Recharge trial AI credits if they run low
app.post('/api/users/recharge-trial', authenticateToken, async (req: any, res: any) => {
  const userId = req.user.id;
  try {
    if (isMongoConnected) {
      const user = await MongoUser.findById(userId);
      if (!user) {
        return res.status(404).json({ error: "Student user not found." });
      }
      user.aiCredits = (user.aiCredits !== undefined ? user.aiCredits : 200) + 150;
      await user.save();
      return res.json({ message: "Successfully recharged 150 free Trial AI credits!", success: true, aiCredits: user.aiCredits });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === userId);
      if (!user) {
        return res.status(404).json({ error: "Student user not found in local records." });
      }
      user.aiCredits = (user.aiCredits !== undefined ? user.aiCredits : 200) + 150;
      saveLocalDB(db);
      return res.json({ message: "Successfully recharged 150 free Trial AI credits!", success: true, aiCredits: user.aiCredits });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Recharging credits failed." });
  }
});

// 5c. Post a scare order on a student by id (Admin only)
app.post('/api/users/scare', authenticateToken, verifyAdmin, async (req, res) => {
  const { studentId } = req.body;
  if (!studentId) {
    return res.status(400).json({ error: "Student ID parameter is required." });
  }
  try {
    if (isMongoConnected) {
      const user = await MongoUser.findByIdAndUpdate(studentId, { scareTriggered: true }, { new: true });
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found." });
      }
      broadcast({ type: 'SCARE_TRIGGERED', studentId });
      return res.json({ message: `SOUl TREMBLING scare trigger queued successfully on ${user.name}!`, success: true });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === studentId);
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found in local DB." });
      }
      user.scareTriggered = true;
      saveLocalDB(db);
      broadcast({ type: 'SCARE_TRIGGERED', studentId });
      return res.json({ message: `SOUL TREMBLING scare trigger queued successfully on ${user.name}!`, success: true });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 5ca. Post a walking cat order on a student by id (Admin only)
app.post('/api/users/cat-scare', authenticateToken, verifyAdmin, async (req, res) => {
  const { studentId } = req.body;
  if (!studentId) {
    return res.status(400).json({ error: "Student ID parameter is required." });
  }
  try {
    if (isMongoConnected) {
      const user = await MongoUser.findByIdAndUpdate(studentId, { catTriggered: true }, { new: true });
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found." });
      }
      broadcast({ type: 'CAT_SCARE_TRIGGERED', studentId });
      return res.json({ message: `Cute walking cat queued successfully on ${user.name}! 🐱`, success: true });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === studentId);
      if (!user) {
        return res.status(404).json({ error: "Selected student user not found in local DB." });
      }
      user.catTriggered = true;
      saveLocalDB(db);
      broadcast({ type: 'CAT_SCARE_TRIGGERED', studentId });
      return res.json({ message: `Cute walking cat queued successfully on ${user.name}! 🐱`, success: true });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 5d. Check my own scare/cat trigger status (Polled by logged-in users)
app.get('/api/users/scare-status', authenticateToken, async (req, res) => {
  try {
    const currentUserId = req.user.id;
    if (isMongoConnected) {
      const user = await MongoUser.findById(currentUserId, 'scareTriggered catTriggered');
      return res.json({ 
        scareTriggered: !!(user && user.scareTriggered),
        catTriggered: !!(user && user.catTriggered)
      });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === currentUserId);
      return res.json({ 
        scareTriggered: !!(user && user.scareTriggered),
        catTriggered: !!(user && user.catTriggered)
      });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 5e. Clear my active scare trigger flag
app.post('/api/users/clear-scare', authenticateToken, async (req, res) => {
  try {
    const currentUserId = req.user.id;
    if (isMongoConnected) {
      await MongoUser.findByIdAndUpdate(currentUserId, { scareTriggered: false });
      return res.json({ success: true });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === currentUserId);
      if (user) {
        user.scareTriggered = false;
        saveLocalDB(db);
      }
      return res.json({ success: true });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 5f. Clear my active cat walking trigger flag
app.post('/api/users/clear-cat', authenticateToken, async (req, res) => {
  try {
    const currentUserId = req.user.id;
    if (isMongoConnected) {
      await MongoUser.findByIdAndUpdate(currentUserId, { catTriggered: false });
      return res.json({ success: true });
    } else {
      const db = getLocalDB();
      const user = db.users.find((u: any) => u.id === currentUserId);
      if (user) {
        user.catTriggered = false;
        saveLocalDB(db);
      }
      return res.json({ success: true });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 🔑 DEV DEBUG: Credentials inspection endpoint
app.get('/api/credentials', async (req, res) => {
  try {
    if (isMongoConnected) {
      const users = await MongoUser.find({}, 'name email password rawPassword role isApproved paymentStatus createdAt').lean();
      const mapped = users.map((u: any) => {
        let plain = u.rawPassword;
        if (!plain) {
          if (u.email.toLowerCase() === 'admin@gallery.com') plain = 'admin123';
          else if (u.email.toLowerCase() === 'student@gallery.com') plain = 'user123';
          else if (u.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com') plain = 'admin123';
          else if (u.password && !u.password.startsWith('$')) plain = u.password;
          else plain = u.email.split('@')[0] + '123';
        }
        return {
          ...u,
          password: plain
        };
      });
      return res.json({ users: mapped });
    } else {
      const db = getLocalDB();
      const users = (db.users || []).map((u: any) => {
        let plain = u.rawPassword || u.plainPassword;
        if (!plain) {
          if (u.email.toLowerCase() === 'admin@gallery.com') plain = 'admin123';
          else if (u.email.toLowerCase() === 'student@gallery.com') plain = 'user123';
          else if (u.email.toLowerCase() === 'mahabubrahmanakash275@gmail.com') plain = 'admin123';
          else if (u.passwordHash && !u.passwordHash.startsWith('$')) plain = u.passwordHash;
          else plain = u.email.split('@')[0] + '123';
        }
        return {
          ...u,
          password: plain
        };
      });
      const artists = (db.artists || []).map((a: any) => ({
        id: a.id,
        name: a.name,
        email: a.email,
        password: a.rawPassword || 'user123',
        role: 'artist'
      }));
      return res.json({ users: [...users, ...artists] });
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});


// ========================
// 📊 DASHBOARD STATISTICS
// ========================

app.get('/api/stats', authenticateToken, async (req, res) => {
  try {
    let usersCount = 0;
    let subjectsCount = 0;
    let foldersCount = 0;
    let totalImages = 0;

    if (isMongoConnected) {
      usersCount = await MongoUser.countDocuments();
      subjectsCount = await MongoSubject.countDocuments();
      foldersCount = await MongoPractical.countDocuments();
      const allPracticals = await MongoPractical.find();
      totalImages = allPracticals.reduce((sum, f) => sum + (f.images ? f.images.length : 0), 0);
    } else {
      const db = getLocalDB();
      usersCount = db.users.length;
      subjectsCount = db.subjects.length;
      foldersCount = db.folders.length;
      totalImages = db.folders.reduce((sum: number, f: any) => sum + (f.images ? f.images.length : 0), 0);
    }

    return res.json({
      usersCount,
      subjectsCount,
      foldersCount,
      imagesCount: totalImages,
      databaseType: isMongoConnected ? "MongoDB Atlas" : "Local Flatfile JSON",
      uptime: process.uptime()
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ========================
// 💬 STUDENT MESSAGING SYSTEM (CLASSROOM HUB)
// ========================

// 1. Get messages (optionally filter by subjectId, default to 'general')
app.get('/api/messages', authenticateToken, async (req, res) => {
  try {
    const subjectId = (req.query.subjectId as string) || 'general';
    
    if (isMongoConnected) {
      const messages = await MongoMessage.find({ subjectId }).sort({ createdAt: 1 }).limit(100);
      
      // Look up user details associated with these messages
      const userIds = [...new Set(messages.map(m => m.userId))];
      const users = await MongoUser.find({ _id: { $in: userIds } }, 'name profilePic role');
      const userMap = new Map();
      users.forEach((u: any) => {
        userMap.set(u._id.toString(), {
          name: u.name,
          profilePic: u.profilePic || "",
          role: u.role
        });
      });

      const decorated = messages.map((m: any) => {
        const u = userMap.get(m.userId);
        return {
          ...m.toObject(),
          userName: u ? u.name : m.userName,
          userProfilePic: u ? u.profilePic : "",
          userRole: u ? u.role : m.userRole
        };
      });

      return res.json(decorated);
    } else {
      const db = getLocalDB();
      const messages = (db.messages || [])
        .filter((m: any) => m.subjectId === subjectId)
        .sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
        .slice(-100);

      const decorated = messages.map((m: any) => {
        const u = db.users.find((user: any) => user.id === m.userId);
        return {
          ...m,
          userName: u ? u.name : m.userName,
          userProfilePic: u ? u.profilePic : "",
          userRole: u ? u.role : m.userRole
        };
      });

      return res.json(decorated);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. Post a new message
app.post('/api/messages', authenticateToken, async (req, res) => {
  try {
    const { content, subjectId } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: "Message content cannot be empty." });
    }

    const payloadSubjectId = subjectId || 'general';
    
    const newMessageData = {
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      content: content.trim(),
      subjectId: payloadSubjectId,
      createdAt: new Date().toISOString()
    };

    if (isMongoConnected) {
      const createdMessage = await MongoMessage.create(newMessageData);
      broadcast({ type: 'CHAT_MESSAGE_MUTATED', subjectId: payloadSubjectId });
      const responseObj = {
        ...createdMessage.toObject(),
        userProfilePic: req.user.profilePic || ""
      };
      return res.status(201).json(responseObj);
    } else {
      const db = getLocalDB();
      if (!db.messages) {
        db.messages = [];
      }
      
      const uniqueId = 'msg-' + Date.now() + '-' + Math.round(Math.random() * 1000);
      const savedMessage = {
        id: uniqueId,
        ...newMessageData
      };
      
      db.messages.push(savedMessage);
      saveLocalDB(db as any);
      broadcast({ type: 'CHAT_MESSAGE_MUTATED', subjectId: payloadSubjectId });
      const responseObj = {
        ...savedMessage,
        userProfilePic: req.user.profilePic || ""
      };
      return res.status(201).json(responseObj);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. Delete a message (owner or admin only)
app.delete('/api/messages/:id', authenticateToken, async (req, res) => {
  try {
    const messageId = req.params.id;
    const { id: currentUserId, role: currentUserRole } = req.user;

    if (isMongoConnected) {
      const message = await MongoMessage.findById(messageId);
      if (!message) {
        return res.status(404).json({ error: "Message not found." });
      }

      // Check permissions
      if (message.userId !== currentUserId && currentUserRole !== 'admin') {
        return res.status(403).json({ error: "Unauthorized. You can only delete your own messages." });
      }

      const subjId = message.subjectId || 'general';
      await MongoMessage.findByIdAndDelete(messageId);
      broadcast({ type: 'CHAT_MESSAGE_MUTATED', subjectId: subjId });
      return res.json({ success: true, message: "Message deleted successfully." });
    } else {
      const db = getLocalDB();
      if (!db.messages) db.messages = [];
      
      const messageIndex = db.messages.findIndex((m: any) => m.id === messageId);
      if (messageIndex === -1) {
        return res.status(404).json({ error: "Message not found in local records." });
      }

      const messageObj = db.messages[messageIndex];
      // Check permissions
      if (messageObj.userId !== currentUserId && currentUserRole !== 'admin') {
        return res.status(403).json({ error: "Unauthorized. You can only delete your own messages." });
      }

      const subjId = messageObj.subjectId || 'general';
      db.messages.splice(messageIndex, 1);
      saveLocalDB(db as any);
      broadcast({ type: 'CHAT_MESSAGE_MUTATED', subjectId: subjId });
      return res.json({ success: true, message: "Local fallback message purged successfully." });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});


// ==========================================
// 🎓 AI VIVA-VOCE EXAM ROOMS & SMART EVAL DATASET & API
// ==========================================

const FALLBACK_VIVA_QUESTIONS: Record<string, Array<{id: number, question: string, subTopic: string, idealAnswerDescription: string}>> = {
  chemistry: [
    {
      id: 1,
      question: "Explain the color change mechanism of Phenolphthalein indicator during a strong acid-strong base titration.",
      subTopic: "Acid-Base Titration",
      idealAnswerDescription: "Phenolphthalein is a weak acid. In acidic media, it is colorless (in un-ionized form). In basic media, it loses protons to form pink resonance-stabilized anions."
    },
    {
      id: 2,
      question: "Why can you not prepare a standard solution of Sodium Hydroxide (NaOH) by direct weighing?",
      subTopic: "Standard Solutions",
      idealAnswerDescription: "NaOH is highly hygroscopic (absorbs moisture from air) and absorbs atmospheric carbon dioxide (CO2) forming Na2CO3, making its dry weight highly unstable and inaccurate."
    },
    {
      id: 3,
      question: "What is the role of adding boiling chips/pumice stones to a distillation flask before heating?",
      subTopic: "Laboratory Safety",
      idealAnswerDescription: "Boiling chips provide nucleation sites for bubbles to form, ensuring smooth, controlled distillation and preventing sudden, dangerous boiling eruptions (bumping)."
    },
    {
      id: 4,
      question: "In systematic salt analysis, what gas is evolved when adding dilute hydrochloric acid to carbonate salt, and how is it confirmed?",
      subTopic: "Qualitative Salt Analysis",
      idealAnswerDescription: "Carbon dioxide gas (CO2) is evolved with brisk effervescence. It is confirmed by passing the gas through lime water [Ca(OH)2], which turns milky due to insoluble calcium carbonate precipitate [CaCO3]."
    },
    {
      id: 5,
      question: "What is the primary difference between a molar and a molal solution?",
      subTopic: "Concentration Units",
      idealAnswerDescription: "Molarity is moles of solute dissolved per liter of overall solution. Molality is moles of solute per kilogram of pure solvent. Molality is temperature independent while molarity changes with temperature due to liquid thermal expansion."
    }
  ],
  physics: [
    {
      id: 1,
      question: "Why should the amplitude of simple pendulum oscillation be kept extremely small during experimental determination of acceleration due to gravity (g)?",
      subTopic: "Simple Pendulum",
      idealAnswerDescription: "The physical formula T = 2π√(L/g) is derived using the linear approximation sin(θ) ≈ θ (in radians), which holds true only for small angular displacements (typically less than 15 degrees)."
    },
    {
      id: 2,
      question: "How does the resistance of a metallic conductor change when its temperature increases, and what is the scientific reason?",
      subTopic: "Ohm's Law & Electricity",
      idealAnswerDescription: "Resistance increases with temperature. As temperature rises, atoms in the metallic lattice vibrate faster and with greater amplitude, increasing the scattering rate of conduction electrons and decreasing mean free time."
    },
    {
      id: 3,
      question: "State Snell's Law of refraction and define what is meant by absolute refractive index of a optical medium.",
      subTopic: "Light Refraction",
      idealAnswerDescription: "Snell's Law states sin(i)/sin(r) is constant (refractive index). Absolute refractive index of a medium is the ratio of speed of light in vacuum to its speed inside that particular medium (n = c / v)."
    },
    {
      id: 4,
      question: "What is a 'zero error' in micrometers or vernier caliper measuring instruments, and how do you calculate the actual physical thickness?",
      subTopic: "Metrology & Measurements",
      idealAnswerDescription: "Zero error occurs when measuring jaws are fully closed but the instrument scale shows a non-zero mark. Correct measurement is computed as: Observed Reading minus Zero Error (taking proper sign of error into account)."
    },
    {
      id: 5,
      question: "In a resonance column experiment, why is the first resonant air column length roughly one-third of the sound wavelength plus end correction?",
      subTopic: "Vibrations & Wave Acoustics",
      idealAnswerDescription: "The vibrating water boundary forms a node and the open pipe end forms a displacement antinode. The fundamental vibration represents a quarter wavelength (λ/4), with antinode slightly extending beyond pipe top (end correction d ≈ 0.6r)."
    }
  ],
  biology: [
    {
      id: 1,
      question: "Why do we use onion root tips to observe and capture mitosis cells under a high-power microscope?",
      subTopic: "Cell Division Cytology",
      idealAnswerDescription: "Onion root tips consist of actively dividing meristematic tissue, which has high metabolic rates and cells continuously passing through various sub-stages of mitosis (prophase, metaphase, anaphase, telophase)."
    },
    {
      id: 2,
      question: "What is plasmolysis and what happens to a plant cell placed in a strongly hypertonic salt solution?",
      subTopic: "Osmosis & Physiology",
      idealAnswerDescription: "Plasmolysis is the shrinking of the plant cell cytoplasm away from cell wall. Placing cell in hypertonic medium prompts exosmosis (water exits vacuole/cell), causing loss of turgor pressure and cell membrane contraction."
    },
    {
      id: 3,
      question: "What chemical indicators are used to test the presence of reducing sugars and proteins in sample solutions?",
      subTopic: "Biochemical Food Assays",
      idealAnswerDescription: "Benedict's reagent is used for reducing sugars (turns blue to brick-red precipitate on boiling). Biuret test is used for proteins (solution turns violet or purple due to copper coordination complex with peptide bonds)."
    },
    {
      id: 4,
      question: "Explain why we must stain microscopic slides of human cheek cells with methylene blue dye.",
      subTopic: "Microscopy Preparation",
      idealAnswerDescription: "Animal cells are nearly transparent and colorless. Methylene blue acts as basic dye which preferentially binds to acidic cellular components like DNA in the nucleus, providing visual contrast and structure."
    },
    {
      id: 5,
      question: "What is the primary function of stomata in plant leaves and how do guard cells open the stomatal aperture?",
      subTopic: "Plant Physiology",
      idealAnswerDescription: "Stomata regulate gas exchange (CO2/O2) and transpiration. When potassium ions active uptake occurs, water flows into guard cells via osmosis, making them turgid. Guard cell walls are thicker inside, bending outwards, opening pore."
    }
  ]
};

app.post('/api/viva/start', authenticateToken, async (req: any, res: any) => {
  const userId = req.user.id;
  const now = Date.now();
  const spamRecord = userAiSpamStore.get(userId);
  if (spamRecord && now < spamRecord.resetTime) {
    if (spamRecord.count >= 8) {
      return res.status(429).json({ error: "You are making AI commands too rapidly. Please pause for a moment to protect server resources." });
    }
    spamRecord.count++;
  } else {
    userAiSpamStore.set(userId, { count: 1, resetTime: now + 60000 });
  }

  const activeClient = getGenAIClient(req);

  // Deduct credits for oral Viva question generation
  const checkResult = await checkAndDeductAICredits(userId, 3, req);
  if (!checkResult.allowed) {
    return res.status(403).json({ error: checkResult.error });
  }

  try {
    const { subjectTitle, language = 'en' } = req.body;
    if (!subjectTitle) {
      return res.status(400).json({ error: "Missing subjectTitle parameter." });
    }

    const normalizedSubject = subjectTitle.toLowerCase();
    let defaultCategory = 'chemistry';
    if (normalizedSubject.includes('physic')) defaultCategory = 'physics';
    else if (normalizedSubject.includes('biolog')) defaultCategory = 'biology';
    else if (normalizedSubject.includes('math')) defaultCategory = 'chemistry';

    const fallbackQuestions = FALLBACK_VIVA_QUESTIONS[defaultCategory] || FALLBACK_VIVA_QUESTIONS.chemistry;

    if (!activeClient) {
      console.warn("GEMINI_API_KEY not configured. Falling back to default Viva prep questions.");
      return res.json({ questions: fallbackQuestions, method: "fallback", aiCredits: checkResult.remaining });
    }

    const response = await safeGenerateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          text: `You are a strict, highly supportive external academic laboratory examiner conduction an oral Viva-Voce test.
          Generate exactly 5 distinct, practical-oriented Oral Viva-Voce questions to test a university student's understanding of experiments in: ${subjectTitle}.
          Each question must be challenging, requiring understanding of chemical reactions, calculations, laboratory setups, precautions, or safety protocols.
          
          Respond strictly inside a JSON array that matches the schema of 5 objects containing standard fields.
          ${language === 'bn_book' ? 'CRITICAL LANGUAGE REQUIREMENT: Write the "question", "subTopic", and "idealAnswerDescription" entirely in standard academic book-styled formal Bangla (উচ্চমাধ্যমিক টেক্সটবইয়ের প্রমিত বাংলা ভাষা শৈলী). You MUST use exact Scientific and Academic terms, and keep standard English terminologies in parentheses alongside their Bangla equivalents (e.g., "সান্দ্রতা (Viscosity)", "তড়িৎদ্বার (Electrode)", "পৃষ্ঠটান (Surface Tension)"). Return all equations, formulas, and math symbols in standard LaTeX formatting.' : ''}`
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              question: { type: Type.STRING },
              subTopic: { type: Type.STRING, description: "Sub-topic of experiment, e.g. titration or refraction" },
              idealAnswerDescription: { type: Type.STRING, description: "Detailed key scientific concepts and keywords expected from the response" }
            },
            required: ["id", "question", "subTopic", "idealAnswerDescription"]
          }
        }
      }
    }, activeClient);

    if (response.text) {
      const parsed = JSON.parse(response.text.trim());
      if (Array.isArray(parsed) && parsed.length > 0) {
        return res.json({ questions: parsed, method: "gemini", aiCredits: checkResult.remaining });
      }
    }
    
    throw new Error("Returned content empty or invalid JSON array.");
  } catch (err) {
    console.error("AI Viva Question Generation failed:", err);
    // Determine category again for fallback
    const { subjectTitle } = req.body;
    const normalizedSubject = (subjectTitle || "").toLowerCase();
    let defaultCategory = 'chemistry';
    if (normalizedSubject.includes('physic')) defaultCategory = 'physics';
    else if (normalizedSubject.includes('biolog')) defaultCategory = 'biology';
    const fallbackQuestions = FALLBACK_VIVA_QUESTIONS[defaultCategory] || FALLBACK_VIVA_QUESTIONS.chemistry;
    return res.json({ questions: fallbackQuestions, method: "fallback-on-error", aiCredits: checkResult.remaining });
  }
});

app.post('/api/viva/evaluate', authenticateToken, async (req: any, res: any) => {
  const userId = req.user.id;
  const now = Date.now();
  const spamRecord = userAiSpamStore.get(userId);
  if (spamRecord && now < spamRecord.resetTime) {
    if (spamRecord.count >= 8) {
      return res.status(429).json({ error: "You are making AI commands too rapidly. Please pause for a moment to protect server resources." });
    }
    spamRecord.count++;
  } else {
    userAiSpamStore.set(userId, { count: 1, resetTime: now + 60000 });
  }

  const activeClient = getGenAIClient(req);

  // Check and deduct credits for Viva evaluation (2 credits cost)
  const checkResult = await checkAndDeductAICredits(userId, 2, req);
  if (!checkResult.allowed) {
    return res.status(403).json({ error: checkResult.error });
  }

  try {
    const { subjectTitle, question, idealCriteria, studentAnswer, language = 'en' } = req.body;
    
    if (!question || !idealCriteria) {
      return res.status(400).json({ error: "Missing required properties 'question' or 'idealCriteria'." });
    }

    const cleanStudentAnswer = (studentAnswer || "").trim();

    if (!cleanStudentAnswer) {
      return res.json({
        score: 0,
        critique: language === 'bn_book' 
          ? "কোনো উত্তর রেকর্ড করা হয়নি। মনে রাখবেন, বৈজ্ঞানিক মৌখিক পরীক্ষায় 'আমি জানি না' বলা সততার পরিচয় হলেও কোনো নম্বর অর্জিত হয় না।"
          : "No answer was recorded. Remember, in scientific oral defense, saying 'I do not know' is honest but earns no performance mark.",
        idealExplanation: idealCriteria,
        aiCredits: checkResult.remaining
      });
    }

    if (!activeClient) {
      // Direct heuristic keywords overlap
      const lowerAns = cleanStudentAnswer.toLowerCase();
      const keywords = idealCriteria.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3);
      let score = 2;
      let matchesCount = 0;
      
      keywords.forEach((word: string) => {
        const cleanW = word.replace(/[^a-z0-9]/gi, '');
        if (cleanW.length > 3 && lowerAns.includes(cleanW)) {
          matchesCount++;
        }
      });

      if (matchesCount > 4) score = 10;
      else if (matchesCount > 2) score = 9;
      else if (matchesCount > 1) score = 7;
      else if (matchesCount > 0) score = 5;
      else if (cleanStudentAnswer.length > 20) score = 4;

      return res.json({
        score,
        critique: language === 'bn_book'
          ? `[অফলাইন লোকাল মূল্যায়ন নোড] বৈজ্ঞানিক মূল তথ্য সমন্বয়ের উপর ভিত্তি করে মূল্যায়ন করা হয়েছে। ৩টি ধারণার মধ্যে ${matchesCount}টি সনাক্ত হয়েছে।`
          : `[Offline Local Evaluator Node] Evaluated offline based on scientific keyword matching. Detected ${matchesCount} key concepts. Your response is noted in files.`,
        aiCredits: checkResult.remaining
      });
    }
  } catch (err) {
    console.error("AI Viva grading failed:", err);
    const { idealCriteria } = req.body;
    return res.json({
      score: 7,
      critique: "Grading system ran offline temporarily due to socket rate. Credit evaluated for effort.",
      idealExplanation: idealCriteria || "Verify scientific principles related to this experiment.",
      aiCredits: checkResult.remaining
    });
  }
});


app.post('/api/academy/learn', authenticateToken, async (req: any, res: any) => {
  const userId = req.user.id;
  const now = Date.now();
  const spamRecord = userAiSpamStore.get(userId);
  if (spamRecord && now < spamRecord.resetTime) {
    if (spamRecord.count >= 8) {
      return res.status(429).json({ error: "You are making AI commands too rapidly. Please pause for a moment to protect server resources." });
    }
    spamRecord.count++;
  } else {
    userAiSpamStore.set(userId, { count: 1, resetTime: now + 60000 });
  }

  const activeClient = getGenAIClient(req);

  // Check and deduct credits if Gemini is integrated
  const checkResult = await checkAndDeductAICredits(userId, 3, req);
  if (!checkResult.allowed) {
    return res.status(403).json({ error: checkResult.error });
  }

  const { subject, paper, level, depth, topic, mode = 'concept', question = '', chatHistory = [], language = 'en' } = req.body;

  try {
    if (!subject) {
      return res.status(400).json({ error: "Missing required parameter 'subject'." });
    }

    if (!activeClient) {
      // Return a very rich fallback so that the applet functions offline as well
      if (language === 'bn_book') {
        const fallbackTitle = `অফলাইন মৌলিক থেকে উন্নত গাইড: ${subject} ${paper ? `(${paper})` : ''} (${level})`;
        const fallbackText = `# ${fallbackTitle}

## ১. মূল নীতিসমূহ (Core Principles)
এটি **${subject} ${paper ? `(${paper})` : ''}** বিষয়ের **${level}** বোর্ড ফরম্যাটের অধীনে **${depth}** স্তরের একটি অফলাইন ইন্টারেক্টিভ সিলেবাস ওভারভিউ।

- **মৌলিক ধারণা (Fundamental Concept)**: প্রতিটি পদার্থবিদ্যা/রসায়ন/জীববিজ্ঞান/গণিত ব্যবস্থা সুনির্দিষ্ট নিয়ম অনুসরণ করে যা এর আচরণ নির্ধারণ করে। উদাহরণস্বরূপ, আমরা পরিচালনা সংক্রান্ত সূত্র, তাত্ত্বিক প্রমাণ এবং ব্যবহারিক হিসাবসমূহ বিশ্লেষণ করি।

## ২. বাস্তবমুখী এবং তাত্ত্বিক প্রয়োগ (Practical & Theoretical Application)
- এনসিটিবি (NCTB) বোর্ড বা আন্তর্জাতিক সিলেবাসের অধীনে: সুনির্দিষ্ট সমতাযুক্ত সমীকরণ, টাইট্রেশনের শেষ বিন্দু (Titration Endpoints), অপটিক্যাল স্লাইড ও পরিমাপের ত্রুটি সংশোধন অত্যন্ত গুরুত্বপূর্ণ।
- **সিলেবাসের সামঞ্জস্য**: NCTB বাংলাদেশের বোর্ড মানদণ্ড অনুসরণ করে, এবং আন্তর্জাতিক স্ট্যান্ডার্ড এ-লেভেল (A-Levels), এপি (AP), বা ও-লেভেল মানদণ্ড মেনে চলে।
- **ত্রুটি প্রতিরোধ (Error Prevention)**: যন্ত্রের শূন্য ত্রুটি (Zero Error), মেনিসকাস স্তরবিন্যাস (Meniscus Alignments) এবং গণনার সীমা সর্বদা দুবার যাচাই করুন।

## ৩. বোর্ড বহুনির্বাচনী প্রশ্ন (Top Board MCQs)
১. এই সুনির্দিষ্ট অধ্যায়ের প্রধান ধ্রুবক/নীতি কোনটি?
   * মোলার আয়তন (Molar Volume), কেপলারের ধ্রুবক বা বুলিয়ান সত্যক সারণি।
২. পরিমাপের হিসাবের ত্রুটি সংশোধন কীভাবে করা হয়?
   * সমীকরণ: আদর্শ বিচ্যুতি (Standard Deviation) বা ত্রুটির শতকরা অনুপাত।

*দ্রষ্টব্য: রিয়েল-টাইম কাস্টমাইজড এআই উত্তর এবং চমৎকার গাণিতিক ব্যাখ্যা পেতে অনুগ্রহ করে আপনার GEMINI_API_KEY কনফিগার করুন।*`;
        return res.json({ response: fallbackText, mode: "fallback" });
      } else {
        const fallbackTitle = `Offline Basic to Advanced Guide: ${subject} ${paper ? `(${paper})` : ''} (${level})`;
        const fallbackText = `# ${fallbackTitle}

## 1. Core Principles
This is an offline interactive syllabus overview for **${subject} ${paper ? `(${paper})` : ''}** under the **${level}** board format at the **${depth}** level.

- **Fundamental Concept**: Every physical/chemical/biological/mathematical system follows a series of structured rules that define its behavior. For example, in ${subject} ${paper ? `(${paper})` : ''}, we look at governing laws, theoretical proofs, and experimental calculations.

## 2. Practical & Theoretical Application
- When doing this under the NCTB board or International syllabus: exact balanced equations, titration endpoints, biological specimen slides, mathematical derivatives, and computing truth tables are crucial.
- **Syllabus alignment**: NCTB aligns with Bangladesh Board standards, while International aligns with A-Levels/AP/IB standards.
- **Error prevention**: Double check instrumental zero errors, meniscus alignments, code indentation, and value calculation limits.

## 3. Top Board MCQ Questions & Key Answers
1. What is the fundamental constant/principle in this section?
   *Detailed concept*: Molar volumes, Kepler's constants, or boolean truth tables depending on topic.
2. How is calculation correction formatted?
   *Key equation*: Standard deviations or percentage of error.

*Note: To receive full real-time customized AI answers with interactive MCQs and deep derivations, please provide a valid GEMINI_API_KEY.*`;
        return res.json({ response: fallbackText, mode: "fallback" });
      }
    }

    // Prepare system/user instructions for Gemini depending on mode
    let prompt = "";
    if (mode === 'concept') {
      prompt = `You are a world-class academic tutor specializing in teaching HSC Science and International curriculum (including AP, A-Levels, IB).
      Create a highly structured, comprehensive, and engaging lesson on the following topic:
      - Subject: ${subject} ${paper ? `(${paper})` : ''}
      - Level/Curriculum: ${level} (if NCTB, mention Bangladesh Board specific standards and NCTB Textbook style; if International, align with A-Levels/AP/IB standards)
      - Depth/Difficulty: ${depth} (Basic covers introduction and key definitions; Intermediate covers core formulas and detailed examples; Advanced covers mathematical derivations, proofs, and complex international/board problems)
      - Specific Topic: ${topic || 'General Overview of Core Concepts'}

      Structure your response beautifully using markdown:
      1. Start with a main title: '# Subject: Topic name'
      2. Group sections using '## ' or '### ' as appropriate.
      3. Render mathematical formulas in clear text style or LaTeX style wrapped in '$$' markers on their own line (e.g. '$$E = mc^2$$').
      4. Use standard bullet points ('- ') for listing, and bold key terms using '**term**'.
      5. Include a specific 'Real-world Practical/Lab Connection' section since this is a practical-heavy portal.
      6. Provide 3 high-yield Practice Board Questions with detailed answers at the bottom.`;
    } else if (mode === 'mcq') {
      prompt = `You are a professional board examiner generating interactive Multiple Choice Questions (MCQs) for practice.
      Generate 3 challenging and high-yield MCQs for study review:
      - Subject: ${subject} ${paper ? `(${paper})` : ''}
      - Level/Curriculum: ${level}
      - Depth/Difficulty: ${depth}
      - Specific Topic: ${topic || 'General Syllabus'}

      For each MCQ question, provide:
      - The stem of the question.
      - Option A, B, C, D.
      - The correct option.
      - A comprehensive scientific explanation explaining why it is correct and why other options are incorrect.
      
      Format using markdown:
      - Start with '# Interactive MCQs: ${subject} ${paper ? `(${paper})` : ''}'
      - Use '## ' for Question numbers.
      - Use clean bullet points for Options.
      - Clearly flag '**Correct Option**: [Letter]' and define the explanation under '**Detailed Scientific Rationale**:'.`;
    } else if (mode === 'creative_question') {
      prompt = `You are an expert specialist in NCTB Creative Questions (CQ - Stimulus, Ka, Kha, Ga, Gha) and International Board Free-Response Questions (FRQ / Structured Questions).
      Generate a realistic, exam-standard complex question based on the topic:
      - Subject: ${subject} ${paper ? `(${paper})` : ''}
      - Level/Curriculum: ${level}
      - Depth/Difficulty: ${depth}
      - Specific Topic: ${topic || 'General Syllabus'}

      Provide:
      1. **A Stimulus / Scenario**: (Can be a mock lab experiment description, a data table, physical system setup, or a code block for ICT)
      2. **Sub-questions**:
         - For NCTB: (a) Knowledge-based (1 mark), (b) Comprehension-based (2 marks), (c) Application-based (3 marks), (d) Higher Ability-based (4 marks).
         - For International level (AP/A-Level): Parts (i), (ii), (iii), (iv) with marks distribution.
      3. **Ideal Marking Rubric & Detailed Answers** for each sub-question, specifying what words or formulas are needed to secure full marks.
      
      Ensure beautiful markdown layout with '$$' wrapped equations.`;
    } else {
      // Mode is 'ask_ai' (Chat discussion mode)
      const historyText = chatHistory.map((m: any) => `${m.sender === 'student' ? 'Student' : 'Tutor'}: ${m.text}`).join('\n');
      prompt = `You are a highly supportive and expert academic professor guiding a student studying:
      - Subject: ${subject} ${paper ? `(${paper})` : ''}
      - Level/Curriculum: ${level}
      - Depth/Difficulty: ${depth}
      - Current Topic of Study: ${topic || 'General'}
      
      Here is the conversation history so far:
      ${historyText}

      The student asks: "${question}"

      Please provide a highly educational, accurate, encouraging, and detailed response.
      Explain the mathematical derivations, chemical balances, biological terminologies, or code structures clearly. Use markdown headers, bold words, and '$$' wrapped formula blocks for elegant rendering.`;
    }

    if (language === 'bn_book') {
      prompt += `\n\nCRITICAL LANGUAGE REQUIREMENT: Write your entire generated content (lessons, MCQs, or chat answers) in very easy, accessible, and approachable Bangla. It MUST align perfectly with the NCTB syllabus but use simplified, highly communicative language so high school students can understand it single-handedly. Avoid dry, high-flown, or overly complex academic jargon. Instead, explain concepts with intuitive step-by-step breakdowns and relatable real-life examples. ALWAYS keep exact scientific/technical terms in their standard Bangla forms, with their standard English equivalents in parentheses next to them [for example: "বল (Force)", "ত্বরণ (Acceleration)", "পর্যায়কাল (Time Period)", "সান্দ্রতা (Viscosity)", "যোজ্যতা (Valency)"]. Maintain LaTeX formatting for math formulation. Keep the tone warm, welcoming, and easy to read.`;
    }

    // Dynamic Diagram/Graph Generation Injection
    prompt += `\n\nCRITICAL VISUAL GRAPH/IMAGE REQUIREMENT: You have the ability to generate live, illustrative graphs, schemas, and diagrams in your markdown! Where a concept is easier to understand with a helper graph or illustration (e.g., velocity-time charts, ray optics, molecular setups, or wave forms), you MUST include a markdown image tag.
Use exactly this format:
![Detailed Name of Diagram](https://image.pollinations.ai/p/[encoded_prompt]?width=600&height=400&nologo=true)
Replace '[encoded_prompt]' with a highly specific, descriptive, fully URL-encoded prompt of the diagram you want (e.g. use %20 or + for spaces, details like whiteboard%20sketch, labeled%20axes, pristine%20physics%20diagram).
Example:
![Velocities vs Timings Graph](https://image.pollinations.ai/p/velocity%20vs%20time%20graph%20showing%2520acceleration,%2520physics,%2520whiteboard%2520notations?width=600&height=400&nologo=true)
Make sure you include at least one beautiful explanatory image or graph tag when explaining concepts or solving creative questions.`;

    // CRITICAL MATH FORMULATION REQUIREMENT
    prompt += `\n\nCRITICAL MATH & SCIENTIFIC FORMULA FORMATTING REQUIREMENT (LaTeX syntax):
You MUST format all mathematical expressions, derivations, equations, variables, Greek symbols, and steps using precise LaTeX notation. NEVER use raw plain-text representations or slurred notations like "R^2 = A^2 + B^2 + 2AB cos(θ)" or "cos(θ) = -1/2 => θ = 120°".
Adhere strictly to the following formatting standards:
1. Wrap standalone, multi-step, or key equations in block math style using double dollars '$$'. Examples:
$$ R^2 = A^2 + B^2 + 2AB \\cos(\\theta) $$
$$ F^2 = 2F^2 + 2F^2 \\cos(\\theta) $$
$$ \\cos(\\theta) = -\\frac{1}{2} \\implies \\theta = 120^\\circ $$
2. For inline terms, individual variables, constants, angles, and short equations, wrap them in single dollars '$'. Examples:
- Use '$R$', '$A$', '$B$', '$F$', and '$\\theta$' in sentences instead of raw text.
- Use '$R = A = B = F$' in descriptions instead of inline text.
3. Use proper LaTeX math commands rather than plain text descriptors, e.g., '$\\theta$' instead of 'θ', '$\\cos$' instead of 'cos', '$\\implies$' instead of '=>', '$-1/2$' or '$-\\frac{1}{2}$' instead of '-1/2', and '$120^\\circ$' or '$120^\\circ$' instead of '120°'.
4. Do not combine raw text symbols inside mathematical statements. Standard equations must be pristine and render beautifully.`;

    const response = await safeGenerateContent({
      model: "gemini-3.5-flash",
      contents: [{ text: prompt }]
    }, activeClient);

    if (response.text) {
      return res.json({ response: response.text, aiCredits: checkResult.remaining });
    }
    throw new Error("No response content generated from Gemini model.");
  } catch (err: any) {
    console.error("Aura Intellect Academy error:", err);
    // Return elegant offline fallback so student flow/lesson review is uninterrupted
    const fallbackTitle = `Current Topic Study Guide: ${topic || 'General Science Overview'}`;
    const fallbackText = `# ⚠️ Live AI Service Busy: ${fallbackTitle}
 
Our servers are currently experiencing exceptional volume. To ensure your learning/review session continues seamlessly, here is a professional, high-yield curriculum review lesson compiled for your subject and topic settings:
 
## 💡 Core Study Foundations
This lesson/study resource is set for the student level **${level || 'HSC'}** at the **${depth || 'Intermediate'}** depth:
 
- **Fundamental Concept**: Every scientific study hinges on robust physical laws, chemical stoichiometry, or biological structures.
- **Error Calculation**: Remember that percentage error in laboratory measurements is defined as:
  $$\\text{Error} = \\left| \\frac{\\text{Theoretical} - \\text{Experimental}}{\\text{Theoretical}} \\right| \\times 100\\%$$
- **Safety Safeguards**: Always wear protective lab gear, rinse burettes/pipettes with solution before taking readings, and eliminate meniscus parallax errors.
 
## 🛠️ Step-by-Step Lab Process
For standard practical assessments, make sure to structure your steps clearly:
1. **Apparatus Calibration**: Ensure you read the least count (vernier constant) of your instruments perfectly before recording experimental data.
2. **Replicate Readings**: Take at least 3 replicate values to minimize random experimental errors.
3. **Graphing Rules**: Always plot the independent variable on the X-axis and dependent variables on the Y-axis. Draw a line of best fit.
 
## 🔑 High-Yield Board Viva Practice
1. **What is the significance of standard temperature and pressure (STP)?** Standard reference conditions of 0°C (273.15 K) and 1 bar or atm to compare physical metrics of gases ($22.4 \\text{ L}/\\text{mol}$).
2. **State Hooke's Law**: The restorative force $F$ exerted by a spring scales linearly with the extension or compression distance $x$, mapped as $F = -kx$.
 
_Note: Please feel free to retry asking a specific follow-up or changing study tabs in a few moments once the server load stabilizes._`;
    return res.json({ response: fallbackText, mode: "fallback", aiCredits: checkResult.remaining });
  }
});
  /*
  } catch (err: any) {
    console.error("AI Scholar Academy error:", err);
    // Return elegant offline fallback so student flow/lesson review is uninterrupted
    const fallbackTitle = `Current Topic Study Guide: ${topic || 'General Science Overview'}`;
    const fallbackText = `# ⚠️ Live AI Service Busy: ${fallbackTitle}

Our servers are currently experiencing exceptional volume. To ensure your learning/review session continues seamlessly, here is a professional, high-yield curriculum review lesson compiled for your subject and topic settings:

## 💡 Core Study Foundations
This lesson/study resource is set for the student level **${level || 'HSC'}** at the **${depth || 'Intermediate'}** depth:

- **Fundamental Concept**: Every scientific study hinges on robust physical laws, chemical stoichiometry, or biological structures.
- **Error Calculation**: Remember that percentage error in laboratory measurements is defined as:
  $$\\text{Error} = \\left| \\frac{\\text{Theoretical} - \\text{Experimental}}{\\text{Theoretical}} \\right| \\times 100\\%$$
- **Safety Safeguards**: Always wear protective lab gear, rinse burettes/pipettes with solution before taking readings, and eliminate meniscus parallax errors.

## 🛠️ Step-by-Step Lab Process
For standard practical assessments, make sure to structure your steps clearly:
1. **Apparatus Calibration**: Ensure you read the least count (vernier constant) of your instruments perfectly before recording experimental data.
2. **Replicate Readings**: Take at least 3 replicate values to minimize random experimental errors.
3. **Graphing Rules**: Always plot the independent variable on the X-axis and dependent variables on the Y-axis. Draw a line of best fit.

## 🔑 High-Yield Board Viva Practice
1. **What is the significance of standard temperature and pressure (STP)?** Standard reference conditions of 0°C (273.15 K) and 1 bar or atm to compare physical metrics of gases ($22.4 \\text{ L}/\\text{mol}$).
2. **State Hooke's Law**: The restorative force $F$ exerted by a spring scales linearly with the extension or compression distance $x$, mapped as $F = -kx$.

_Note: Please feel free to retry asking a specific follow-up or changing study tabs in a few moments once the server load stabilizes._`;
    return res.json({ response: fallbackText, mode: "fallback" });
  }
});
*/

// ========================
// ⚙️ NODE DEV EXPORT HELPERS (STANDALONE MERN EXPORT)
// ========================

// Download ZIP creator instructions or source structures for VS Code
app.get('/api/export-structure', (req, res) => {
  res.json({
    message: "To run Practical Notebook Gallery in VS Code locally, follow the step-by-step instructions in the EXPORT_README.md in your exported folder.",
    installationSteps: [
      "1. Extract ZIP source code",
      "2. Run 'npm install' in both /frontend and /backend folders",
      "3. Start local MongoDB instance or provision MongoDB Atlas connection settings",
      "4. Set up backend/.env with JWT_SECRET, MONGO_URI, and desired PORT",
      "5. Spin up the backend via 'npm start' or 'node server.js'",
      "6. Spin up the frontend react development node via 'npm run dev' or serve static build."
    ]
  });
});


// ==============================================
// 🎨 SCIENCE DRAW PRACTICAL ARTISTS PORTAL API
// ==============================================

// 1. Get all registered artists
app.get('/api/artists', async (req, res) => {
  try {
    const db = getLocalDB();
    const sanitisedArtists = (db.artists || []).map((art: any) => {
      const { passwordHash, ...rest } = art;
      return rest;
    });
    return res.json(sanitisedArtists);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to retrieve artists." });
  }
});

// 2. Register artist
app.post('/api/artists/register', async (req, res) => {
  const { name, email, password, specialties, bio, ratePerDrawing, avatar, phoneNumber } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Name, email, and password are required to register as an artist." });
  }

  try {
    const db = getLocalDB();
    const existingUser = db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
    const existingArtist = db.artists?.find((a: any) => a.email.toLowerCase() === email.toLowerCase());

    if (existingUser || existingArtist) {
      return res.status(400).json({ error: "Email already registered in the academy system." });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const defaultAvatars = [
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150",
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150"
    ];

    const newArtist = {
      id: "art-" + Date.now(),
      name,
      email,
      passwordHash: hashedPassword,
      role: 'artist',
      phoneNumber: phoneNumber || "",
      specialties: Array.isArray(specialties) ? specialties : ["General Science Diagrams"],
      bio: bio || "Professional science diagram designer. Dedicated to clean hand-shading and accurate metrics.",
      ratePerDrawing: Number(ratePerDrawing) || 120,
      rating: 5.0,
      completedCount: 0,
      isAvailable: true,
      avatar: avatar || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)],
      samples: [
        "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&q=80&w=600",
        "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&q=80&w=600"
      ]
    };

    if (!db.artists) db.artists = [];
    db.artists.push(newArtist);
    saveLocalDB(db);

    const token = jwt.sign({ id: newArtist.id, name: newArtist.name, email: newArtist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });
    const { passwordHash, ...sanitizedArtist } = newArtist;
    sendSimulatedWelcomeNotification(name, email, phoneNumber, 'artist');
    return res.status(201).json({ token, user: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to register artist." });
  }
});

// 3. Login artist
app.post('/api/artists/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  try {
    const db = getLocalDB();
    const artist = db.artists?.find((a: any) => a.email.toLowerCase() === email.toLowerCase());

    if (!artist) {
      return res.status(401).json({ error: "Invalid artist credentials." });
    }

    const isValid = await bcrypt.compare(password, artist.passwordHash);
    if (!isValid) {
      return res.status(401).json({ error: "Invalid artist secret phrase." });
    }

    const token = jwt.sign({ id: artist.id, name: artist.name, email: artist.email, role: 'artist' }, JWT_SECRET, { expiresIn: '7d' });
    const { passwordHash, ...sanitizedArtist } = artist;
    return res.json({ token, user: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "An error occurred during artist sign-in." });
  }
});

// 4. Update artist profile details
app.put('/api/artists/profile', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'artist') {
    return res.status(403).json({ error: "Access denied. Only registered artists can modify their setup details." });
  }

  const { specialties, bio, ratePerDrawing, isAvailable, samples, avatar } = req.body;

  try {
    const db = getLocalDB();
    const artistIndex = db.artists?.findIndex((a: any) => a.id === req.user.id);

    if (artistIndex === undefined || artistIndex === -1) {
      return res.status(404).json({ error: "Artist identity could not be verified." });
    }

    const artist = db.artists[artistIndex];
    if (specialties !== undefined) artist.specialties = specialties;
    if (bio !== undefined) artist.bio = bio;
    if (ratePerDrawing !== undefined) artist.ratePerDrawing = Number(ratePerDrawing) || artist.ratePerDrawing;
    if (isAvailable !== undefined) artist.isAvailable = !!isAvailable;
    if (samples !== undefined) artist.samples = samples;
    if (avatar !== undefined) artist.avatar = avatar;

    db.artists[artistIndex] = artist;
    saveLocalDB(db);

    const { passwordHash, ...sanitizedArtist } = artist;
    return res.json({ message: "Artist settings updated successfully.", user: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to update profile." });
  }
});

// 4.1 Admin operations on practical sketch portal artists (Add, Remove, Adjust rates)
app.post('/api/admin/artists', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied. Only system administrators can add artists." });
  }

  const { name, email, password, specialties, bio, ratePerDrawing, avatar } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Artist name, email, and password phrase are required." });
  }

  try {
    const db = getLocalDB();
    if (!db.artists) db.artists = [];

    const existingUser = db.users?.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
    const existingArtist = db.artists?.find((a: any) => a.email.toLowerCase() === email.toLowerCase());

    if (existingUser || existingArtist) {
      return res.status(400).json({ error: "This email address is already registered in the system." });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const defaultAvatars = [
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150",
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150"
    ];

    const newArtist = {
      id: "art-" + Date.now(),
      name,
      email,
      passwordHash: hashedPassword,
      role: 'artist',
      specialties: Array.isArray(specialties) ? specialties : ["General Science Diagrams"],
      bio: bio || "Professional science diagram designer. Dedicated to clean hand-shading and accurate metrics.",
      ratePerDrawing: Number(ratePerDrawing) || 120,
      rating: 5.0,
      completedCount: 0,
      isAvailable: true,
      avatar: avatar || defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)],
      samples: [
        "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&q=80&w=600",
        "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&q=80&w=600"
      ]
    };

    db.artists.push(newArtist);
    saveLocalDB(db);

    const { passwordHash, ...sanitizedArtist } = newArtist;
    return res.status(201).json({ message: "Artist added successfully by Administrator.", artist: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to add artist." });
  }
});

app.delete('/api/admin/artists/:id', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied. Only system administrators can remove artists." });
  }

  const { id } = req.params;

  try {
    const db = getLocalDB();
    if (!db.artists) db.artists = [];

    const initialLength = db.artists.length;
    db.artists = db.artists.filter((a: any) => a.id !== id);

    if (db.artists.length === initialLength) {
      return res.status(404).json({ error: "Artist not found." });
    }

    saveLocalDB(db);
    return res.json({ message: "Artist removed from system successfully by Administrator." });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to remove artist." });
  }
});

app.put('/api/admin/artists/:id/rate', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied. Only system administrators can modify pricing." });
  }

  const { id } = req.params;
  const { ratePerDrawing } = req.body;

  if (ratePerDrawing === undefined || isNaN(Number(ratePerDrawing))) {
    return res.status(400).json({ error: "A valid numerical rate per drawing is required." });
  }

  try {
    const db = getLocalDB();
    if (!db.artists) db.artists = [];

    const artistIndex = db.artists.findIndex((a: any) => a.id === id);
    if (artistIndex === -1) {
      return res.status(404).json({ error: "Artist not found." });
    }

    db.artists[artistIndex].ratePerDrawing = Number(ratePerDrawing);
    saveLocalDB(db);

    const { passwordHash, ...sanitizedArtist } = db.artists[artistIndex];
    return res.json({ message: "Artist rate adjusted successfully by Administrator.", artist: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to modify artist rate." });
  }
});

app.put('/api/admin/artists/:id/samples', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied. Only system administrators can modify artist portfolio samples." });
  }

  const { id } = req.params;
  const { samples } = req.body;

  if (samples === undefined || !Array.isArray(samples)) {
    return res.status(400).json({ error: "An array of samples is required." });
  }

  try {
    const db = getLocalDB();
    if (!db.artists) db.artists = [];

    const artistIndex = db.artists.findIndex((a: any) => a.id === id);
    if (artistIndex === -1) {
      return res.status(404).json({ error: "Artist not found." });
    }

    db.artists[artistIndex].samples = samples;
    saveLocalDB(db);

    const { passwordHash, ...sanitizedArtist } = db.artists[artistIndex];
    return res.json({ message: "Artist portfolio samples updated successfully by Administrator.", artist: sanitizedArtist });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to modify artist portfolio samples." });
  }
});

// 5. Place order to hire artist
app.post('/api/artists/hire', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role === 'artist') {
    return res.status(403).json({ error: "Artists cannot place hire requests." });
  }

  const { artistId, practicalTitle, subject, notes, price, studentPhone, notebookProvider } = req.body;
  
  if (!studentPhone || !studentPhone.trim()) {
    return res.status(400).json({ error: "A valid mobile phone number is strictly mandatory to hire a drawing artist." });
  }

  if (!artistId || !practicalTitle || !subject) {
    return res.status(400).json({ error: "Artist ID, practical sheet title, and subject are required to hire." });
  }

  try {
    const db = getLocalDB();
    const artist = db.artists?.find((a: any) => a.id === artistId);

    if (!artist) {
      return res.status(404).json({ error: "Target drawing specialist could not be resolved." });
    }

    const uniqueInvoiceNo = "INV-" + Date.now() + "-" + Math.floor(1000 + Math.random() * 9000);

    const nBooking = {
      id: "book-" + Date.now(),
      artistId: artist.id,
      artistName: artist.name,
      studentId: req.user.id,
      studentName: req.user.name,
      studentEmail: req.user.email,
      studentPhone: studentPhone.trim(),
      invoiceId: uniqueInvoiceNo,
      practicalTitle,
      subject,
      notebookProvider: notebookProvider || "student", // 'artist' or 'student'
      notes: notes || "No specific instructions added.",
      price: Number(price) || artist.ratePerDrawing,
      status: "pending",
      paymentStatus: "pending",
      markPaidByAdmin: false,
      createdAt: new Date().toISOString()
    };

    if (!db.bookings) db.bookings = [];
    db.bookings.push(nBooking);
    saveLocalDB(db);

    // Broadcast update via WebSocket if relevant
    try {
      broadcast({
        type: 'HIRE_SUBMITTED',
        booking: nBooking
      });
    } catch (_) {}

    return res.status(201).json({ 
      message: `Successfully commissioned ${artist.name}! Cash escrow transaction initialized details recorded under voucher #${uniqueInvoiceNo}.`, 
      booking: nBooking 
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to process booking." });
  }
});

// 5.5. Get public list of all bookings (Who hired whom history)
app.get('/api/artists/bookings-public', authenticateToken, async (req: any, res: any) => {
  try {
    const db = getLocalDB();
    const bookings = db.bookings || [];
    // Sanitize sensitive email or exact phone number to defend student privacy while keeping hiring ledger fully auditable
    const publicData = bookings.map((b: any) => ({
      id: b.id,
      studentName: b.studentName || "Anonymous Scholar",
      artistName: b.artistName,
      invoiceId: b.invoiceId,
      practicalTitle: b.practicalTitle,
      subject: b.subject,
      notebookProvider: b.notebookProvider || "student",
      price: b.price,
      status: b.status,
      paymentStatus: b.paymentStatus,
      markPaidByAdmin: b.markPaidByAdmin || false,
      createdAt: b.createdAt
    }));
    return res.json(publicData);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to retrieve public hiring records." });
  }
});

// 6. Get list of bookings
app.get('/api/artists/bookings', authenticateToken, async (req: any, res: any) => {
  try {
    const db = getLocalDB();
    const bookings = db.bookings || [];

    let filtered = [];
    if (req.user.role === 'artist') {
      filtered = bookings.filter((b: any) => b.artistId === req.user.id);
    } else if (req.user.role === 'admin') {
      filtered = bookings; // Admins see everything
    } else {
      filtered = bookings.filter((b: any) => b.studentId === req.user.id);
    }

    return res.json(filtered);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to retrieve bookings." });
  }
});

// 7. Update booking status (Pending -> In Progress -> Completed -> Delivered)
app.post('/api/artists/bookings/:id/status', authenticateToken, async (req: any, res: any) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ error: "Status code parameter is required." });
  }

  try {
    const db = getLocalDB();
    const bIndex = db.bookings?.findIndex((b: any) => b.id === id);

    if (bIndex === undefined || bIndex === -1) {
      return res.status(404).json({ error: "Booking order not resolved." });
    }

    const booking = db.bookings[bIndex];

    // Authorize: only assigned artist, admin, or student (if pending and cancelling) can modify
    const isArtist = req.user.id === booking.artistId && req.user.role === 'artist';
    const isAdmin = req.user.role === 'admin';
    const isStudent = req.user.id === booking.studentId;

    if (!isArtist && !isAdmin && !(isStudent && status === 'cancelled' && booking.status === 'pending') && !(isStudent && status === 'completed' && booking.status === 'delivered')) {
      return res.status(403).json({ error: "You are not authorized to alter this project status." });
    }

    booking.status = status;

    // If completed/delivered, increment completing score of artist
    if (status === 'completed' || status === 'delivered') {
      const artObj = db.artists?.find((a: any) => a.id === booking.artistId);
      if (artObj) {
        artObj.completedCount = (artObj.completedCount || 0) + 1;
      }
    }

    db.bookings[bIndex] = booking;
    saveLocalDB(db);

    try {
      broadcast({
        type: 'HIRE_UPDATED',
        booking
      });
    } catch (_) {}

    return res.json({ message: `Successfully updated order status to ${status.toUpperCase()}.`, booking });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to update status." });
  }
});

// 7b. Admin marks booking payment as paid (Manual cash escrow middleman consent)
app.post('/api/artists/bookings/:id/pay', authenticateToken, async (req: any, res: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied. Only system administrators can authorize manual cash payments." });
  }
  const { id } = req.params;
  const { paymentStatus } = req.body;
  try {
    const db = getLocalDB();
    if (!db.bookings) db.bookings = [];
    const bIndex = db.bookings.findIndex((b: any) => b.id === id);
    if (bIndex === -1) {
      return res.status(404).json({ error: "Hiring order record not found." });
    }
    const booking = db.bookings[bIndex];
    
    if (paymentStatus !== undefined) {
      booking.paymentStatus = paymentStatus;
      booking.markPaidByAdmin = (paymentStatus === 'paid');
      if (booking.markPaidByAdmin) {
        booking.paymentApprovedAt = new Date().toISOString();
      } else {
        booking.paymentApprovedAt = null;
      }
    } else {
      // Toggle default behavior
      if (booking.paymentStatus === 'paid') {
        booking.paymentStatus = 'pending';
        booking.markPaidByAdmin = false;
        booking.paymentApprovedAt = null;
      } else {
        booking.paymentStatus = 'paid';
        booking.markPaidByAdmin = true;
        booking.paymentApprovedAt = new Date().toISOString();
      }
    }
    
    db.bookings[bIndex] = booking;
    saveLocalDB(db);

    try {
      broadcast({
        type: 'HIRE_UPDATED',
        booking
      });
    } catch (_) {}

    return res.json({ message: `Order payment status marked as ${booking.paymentStatus.toUpperCase()} by Administrator.`, booking });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to mark booking payment state." });
  }
});


// 7c. Post Review & Professional Rating for completed order (Fiverr-like marketplace feedback)
app.post('/api/artists/bookings/:id/review', authenticateToken, async (req: any, res: any) => {
  const { id } = req.params;
  const { rating, comment } = req.body;

  if (!rating || isNaN(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) {
    return res.status(400).json({ error: "A valid numerical rating between 1 and 5 is required." });
  }

  try {
    const db = getLocalDB();
    if (!db.bookings) db.bookings = [];
    const bIndex = db.bookings.findIndex((b: any) => b.id === id);
    if (bIndex === -1) {
      return res.status(404).json({ error: "Booking order record not found." });
    }

    const booking = db.bookings[bIndex];
    if (booking.studentId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Only the student who placed this order can rate it." });
    }

    if (booking.status !== 'completed') {
      return res.status(400).json({ error: "You can only rate an order after it has been fully completed." });
    }

    booking.review = {
      rating: Number(rating),
      comment: comment || '',
      createdAt: new Date().toISOString()
    };

    db.bookings[bIndex] = booking;

    // Recalculate artist's overall rating average
    const artistId = booking.artistId;
    const artistBookings = db.bookings.filter((b: any) => b.artistId === artistId && b.review);
    
    const dbArtists = db.artists || [];
    const artistIndex = dbArtists.findIndex((a: any) => a.id === artistId);
    if (artistIndex !== -1) {
      const sum = artistBookings.reduce((acc: number, b: any) => acc + b.review.rating, 0);
      const avg = artistBookings.length > 0 ? sum / artistBookings.length : 5.0;
      dbArtists[artistIndex].rating = avg;
      dbArtists[artistIndex].reviewCount = artistBookings.length;
    }

    saveLocalDB(db);

    try {
      broadcast({
        type: 'HIRE_UPDATED',
        booking
      });
    } catch (_) {}

    return res.json({ message: "Thank you! Your professional feedback has been recorded on our ledger.", booking });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to save review." });
  }
});


// 8. Chat and Communication for Booking Contracts (Student <-> Sketch Artist / Admin)
app.get('/api/artists/bookings/:id/messages', authenticateToken, async (req: any, res: any) => {
  const { id } = req.params;
  try {
    const db = getLocalDB();
    const booking = db.bookings?.find((b: any) => b.id === id);
    if (!booking) {
      return res.status(404).json({ error: "Booking order not resolved." });
    }
    if (req.user.id !== booking.studentId && req.user.id !== booking.artistId && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Unauthorized access to this booking chat." });
    }
    return res.json({ messages: booking.messages || [] });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Failed to retrieve booking chats." });
  }
});

app.post('/api/artists/bookings/:id/messages', authenticateToken, async (req: any, res: any) => {
  const { id } = req.params;
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "Message content is required." });
  }
  try {
    const db = getLocalDB();
    const bIndex = db.bookings?.findIndex((b: any) => b.id === id);
    if (bIndex === undefined || bIndex === -1) {
      return res.status(404).json({ error: "Booking order not resolved." });
    }
    const booking = db.bookings[bIndex];
    if (req.user.id !== booking.studentId && req.user.id !== booking.artistId && req.user.role !== 'admin') {
      return res.status(403).json({ error: "You are not authorized to post messages to this contract." });
    }
    if (!booking.messages) {
      booking.messages = [];
    }
    const newMessage = {
      id: 'bmsg-' + Math.random().toString(36).substring(2, 9),
      senderId: req.user.id,
      senderName: req.user.name || req.user.email,
      senderRole: req.user.role,
      text: text.trim(),
      createdAt: new Date().toISOString()
    };
    booking.messages.push(newMessage);
    db.bookings[bIndex] = booking;
    saveLocalDB(db);

    try {
      broadcast({
        type: 'HIRE_UPDATED',
        booking
      });
    } catch (_) {}

    return res.json({ message: "Message sent successfully.", newMessage });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Failed to send message." });
  }
});



// ==========================================
// 🔑 REAL GOOGLE OAUTH 2.0 FLOW ENDPOINTS
// ==========================================

app.get('/api/auth/google/url', (req, res) => {
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const appUrl = process.env.APP_URL || `${protocol}://${host}`;
  const redirectUri = `${appUrl}/auth/callback`;

  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.VITE_GOOGLE_CLIENT_ID;
  if (!clientId) {
    return res.status(400).json({ 
      error: "GOOGLE_CLIENT_ID is not configured in backend environment variables.",
      redirectUri
    });
  }

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid',
    access_type: 'offline',
    prompt: 'select_account'
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
  res.json({ url: authUrl, redirectUri });
});

app.get(['/auth/callback', '/auth/callback/'], async (req: any, res: any) => {
  const { code, error } = req.query;
  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.VITE_GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET;

  if (error) {
    return res.send(`
      <html>
        <body style="background:#090d16;color:#fff;font-family:sans-serif;padding:2rem;text-align:center;">
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'GOOGLE_AUTH_ERROR', error: ${JSON.stringify(String(error))} }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <h2>Google Authorization Error</h2>
          <p>${error}</p>
        </body>
      </html>
    `);
  }

  if (!code || typeof code !== 'string') {
    return res.status(400).send(`
      <html>
        <body style="background:#090d16;color:#fff;font-family:sans-serif;padding:2rem;text-align:center;">
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'GOOGLE_AUTH_ERROR', error: 'No authorization code provided' }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <p>Authentication failed: No code provided.</p>
        </body>
      </html>
    `);
  }

  try {
    const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const appUrl = process.env.APP_URL || `${protocol}://${host}`;
    const redirectUri = `${appUrl}/auth/callback`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId || '',
        client_secret: clientSecret || '',
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      })
    });

    const tokenData = await tokenRes.json();
    let email = '';
    let name = '';
    let picture = '';

    if (tokenData.access_token) {
      const userRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      if (userRes.ok) {
        const userInfo = await userRes.json();
        email = userInfo.email || '';
        name = userInfo.name || userInfo.given_name || '';
        picture = userInfo.picture || '';
      }
    } else if (tokenData.id_token) {
      const parts = tokenData.id_token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        email = payload.email || '';
        name = payload.name || payload.given_name || '';
        picture = payload.picture || '';
      }
    }

    if (!email) {
      throw new Error(tokenData.error_description || tokenData.error || 'Failed to exchange Google OAuth authorization code.');
    }

    const payloadJson = JSON.stringify({ email, name, picture });

    res.send(`
      <html>
        <body style="background:#090d16;color:#e2e8f0;font-family:sans-serif;padding:2rem;text-align:center;">
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'GOOGLE_AUTH_SUCCESS', payload: ${payloadJson} }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <div style="max-width:400px;margin:0 auto;background:#111827;padding:24px;border-radius:16px;border:1px solid #374151;">
            <h2 style="color:#10b981;margin-top:0;">✓ Authentication Successful</h2>
            <p style="font-size:14px;color:#9ca3af;">Connected as <strong>${email}</strong>.</p>
            <p style="font-size:12px;color:#6b7280;">This window will close automatically...</p>
          </div>
        </body>
      </html>
    `);
  } catch (err: any) {
    res.send(`
      <html>
        <body style="background:#090d16;color:#fff;font-family:sans-serif;padding:2rem;text-align:center;">
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'GOOGLE_AUTH_ERROR', error: ${JSON.stringify(err.message || 'OAuth Exchange failed')} }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <h2>Authentication Error</h2>
          <p style="color:#f87171;">${err.message || 'OAuth failed'}</p>
        </body>
      </html>
    `);
  }
});

// ========================
// 📦 VITE AS AN EXPRESS MIDDLEWARE (DURABLE CLOUD INTEGRATION)
// ========================

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      root: path.resolve('fullstack/frontend'),
      configFile: path.resolve('fullstack/frontend/vite.config.ts'),
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  }

  const server = app.listen(PLATFORM_PORT, '0.0.0.0', () => {
    console.log(`🚀 Modern Practical Notebook Gallery API and UI running at http://localhost:${PLATFORM_PORT}`);
  });
  initWebSocket(server);
}

start().catch((err) => {
  console.error("Express App bootstrapper encountered a fatal startup compile error:", err);
});
