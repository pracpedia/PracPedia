import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';

interface ActiveUser {
  id: string;
  name: string;
  profilePic?: string;
  role: 'user' | 'admin';
}

let wss: WebSocketServer | null = null;
const clients = new Set<WebSocket>();
const clientUsers = new Map<WebSocket, ActiveUser>();

export function initWebSocket(server: Server) {
  wss = new WebSocketServer({ noServer: true });
  
  server.on('upgrade', (request, socket, head) => {
    try {
      const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
      if (url.pathname === '/ws' || url.pathname === '/api/ws') {
        wss?.handleUpgrade(request, socket, head, (ws) => {
          wss?.emit('connection', ws, request);
        });
      }
    } catch (err) {
      // Ignore URL parsing errors
    }
  });

  wss.on('connection', (ws: WebSocket) => {
    clients.add(ws);
    
    // Heartbeat to keep connection alive
    let isAlive = true;
    ws.on('pong', () => {
      isAlive = true;
    });
    
    const interval = setInterval(() => {
      if (ws.readyState !== WebSocket.OPEN) {
        clearInterval(interval);
        clients.delete(ws);
        clientUsers.delete(ws);
        broadcastActiveUsers();
        return;
      }
      if (isAlive === false) {
        ws.terminate();
        return;
      }
      isAlive = false;
      ws.ping();
    }, 30000);

    ws.on('message', (messageData: string) => {
      try {
        const payload = JSON.parse(messageData);
        if (payload.type === 'IDENTIFY' && payload.user) {
          const user = payload.user;
          if (user.id) {
            clientUsers.set(ws, {
              id: user.id,
              name: user.name,
              profilePic: user.profilePic || "",
              role: user.role || "user"
            });
            broadcastActiveUsers();
          }
        }
      } catch (err) {
        console.error("Error parsing WebSocket message data:", err);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      clientUsers.delete(ws);
      clearInterval(interval);
      broadcastActiveUsers();
    });

    ws.on('error', () => {
      clients.delete(ws);
      clientUsers.delete(ws);
      clearInterval(interval);
      broadcastActiveUsers();
    });
  });

  console.log("⚡ WebSocket Server Initialized with Presence Tracking.");
}

export function broadcastActiveUsers() {
  const activeUsers: ActiveUser[] = [];
  const seenIds = new Set<string>();
  
  for (const [ws, user] of clientUsers.entries()) {
    if (ws.readyState === WebSocket.OPEN && !seenIds.has(user.id)) {
      seenIds.add(user.id);
      activeUsers.push(user);
    }
  }
  
  broadcast({
    type: 'PRESENCE_MUTATED',
    data: activeUsers
  });
}

export function broadcast(payload: { type: string; data?: any; [key: string]: any }) {
  const messageStr = JSON.stringify(payload);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(messageStr);
      } catch (e) {
        console.error("Error sending socket payload:", e);
      }
    }
  }
}
