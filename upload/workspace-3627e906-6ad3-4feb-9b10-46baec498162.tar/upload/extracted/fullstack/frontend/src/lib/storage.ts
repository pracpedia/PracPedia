const inMemoryStorage: Record<string, string> = {};

let canUseLocalStorage = false;
try {
  const testKey = '__storage_test__';
  window.localStorage.setItem(testKey, testKey);
  window.localStorage.removeItem(testKey);
  canUseLocalStorage = true;
} catch (e) {
  canUseLocalStorage = false;
}

export const safeLocalStorage = {
  getItem(key: string): string | null {
    if (canUseLocalStorage) {
      try {
        return window.localStorage.getItem(key);
      } catch (e) {
        // Fallback to in-memory
      }
    }
    return inMemoryStorage[key] !== undefined ? inMemoryStorage[key] : null;
  },

  setItem(key: string, value: string): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch (e) {
        // Fallback to in-memory
      }
    }
    inMemoryStorage[key] = String(value);
  },

  removeItem(key: string): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.removeItem(key);
        return;
      } catch (e) {
        // Fallback to in-memory
      }
    }
    delete inMemoryStorage[key];
  },

  clear(): void {
    if (canUseLocalStorage) {
      try {
        window.localStorage.clear();
        return;
      } catch (e) {
        // Fallback to in-memory
      }
    }
    for (const key in inMemoryStorage) {
      delete inMemoryStorage[key];
    }
  }
};
