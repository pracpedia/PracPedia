import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { 
  Palette, 
  Brush, 
  User, 
  Mail, 
  Lock, 
  Star, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  AlertCircle, 
  Plus, 
  Check, 
  ArrowRight, 
  LogOut, 
  Eye, 
  DollarSign, 
  BookOpen, 
  RefreshCw,
  Sliders,
  CheckCircle,
  X,
  FileText,
  Printer,
  Badge,
  UserCheck,
  Briefcase,
  ToggleLeft,
  Image as ImageIcon,
  Trash2,
  ChevronRight,
  Flame,
  Layers,
  HelpCircle,
  Loader2,
  Upload,
  MessageSquare
} from 'lucide-react';

interface Artist {
  id: string;
  name: string;
  email: string;
  role: 'artist';
  specialties: string[];
  bio: string;
  ratePerDrawing: number;
  rating: number;
  completedCount: number;
  isAvailable: boolean;
  avatar: string;
  samples: string[];
}

interface Booking {
  id: string;
  artistId: string;
  artistName: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentPhone?: string;
  invoiceId?: string;
  practicalTitle: string;
  notebookProvider?: 'artist' | 'student';
  subject: string;
  notes: string;
  price: number;
  status: 'pending' | 'in_progress' | 'sketching' | 'delivered' | 'completed' | 'cancelled';
  paymentStatus?: 'pending' | 'paid';
  paymentApprovedAt?: string;
  messages?: any[];
  markPaidByAdmin?: boolean;
  createdAt: string;
  review?: {
    rating: number;
    comment: string;
    createdAt: string;
  };
}

const ReviewForm: React.FC<{ 
  bookingId: string; 
  onSubmitReview: (bookingId: string, rating: number, comment: string) => Promise<void>; 
}> = ({ bookingId, onSubmitReview }) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [comment, setComment] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  return (
    <div className="bg-slate-900/40 border border-white/[0.04] p-3.5 rounded-2xl space-y-3 mt-2.5 animate-in fade-in duration-350">
      <div className="flex flex-col gap-1">
        <span className="text-[9px] font-mono text-slate-400 font-extrabold uppercase tracking-widest block">
          Rate Sketch Quality (Fiverr Marketplace System)
        </span>
        <div className="flex items-center gap-1 mt-0.5">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(null)}
              className="p-1 cursor-pointer transition-transform hover:scale-110"
            >
              <Star 
                className={`w-5 h-5 transition-all ${
                  star <= (hoverRating ?? rating) 
                    ? 'text-yellow-450 fill-yellow-450 filter drop-shadow-[0_0_4px_rgba(250,204,21,0.25)]' 
                    : 'text-slate-700'
                }`} 
              />
            </button>
          ))}
          <span className="text-xs font-mono font-bold text-amber-400 ml-2">{rating}.0 / 5.0</span>
        </div>
      </div>

      <div className="space-y-1.5">
        <input
          type="text"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="e.g. Beautiful curves, premium layout and direct grading! (Optional)"
          className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500/40 font-sans"
        />
        <button
          onClick={async () => {
            setSubmitting(true);
            await onSubmitReview(bookingId, rating, comment);
            setSubmitting(false);
          }}
          disabled={submitting}
          className="w-full sm:w-auto px-4 py-2 bg-indigo-650 hover:bg-indigo-600 text-white text-[10px] font-black uppercase font-mono rounded-xl cursor-pointer transition-all disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/10"
        >
          {submitting ? 'Submitting review...' : 'Submit Certified Review ★'}
        </button>
      </div>
    </div>
  );
};

const gaziBiologyPracticals = [
  // --- 1st Paper (Botany) ---
  {
    id: "bot_1",
    paper: "1st Paper (Botany)",
    title: "অণুবীক্ষণ যন্ত্রের পরিচিতি ও ব্যবহার বিধি এবং উদ্ভিদ কোষ (পেঁয়াজের ত্বক কোষ) পর্যবেক্ষণ",
    engTitle: "Introduction to microscope & Microscopic plant cell observation (Onion epidermal cell)"
  },
  {
    id: "bot_2",
    paper: "1st Paper (Botany)",
    title: "কোষ বিভাজন: পেঁয়াজের মূলের মাইটোসিস কোষ বিভাজনের বিভিন্ন ধাপ পর্যবেক্ষণ",
    engTitle: "Observation of Mitosis Cell Division phases under microscope (Onion root tip)"
  },
  {
    id: "bot_3",
    paper: "1st Paper (Botany)",
    title: "একবীজপত্রী উদ্ভিদের কাণ্ডের প্রস্থচ্ছেদ (T.S.) প্রস্তুতকরণ, পর্যবেক্ষণ ও চিহ্নিতকরণ",
    engTitle: "Preparation, observation & identification of Monocot Stem T.S."
  },
  {
    id: "bot_4",
    paper: "1st Paper (Botany)",
    title: "একবীজপত্রী উদ্ভিদের মূলের প্রস্থচ্ছেদ (T.S.) প্রস্তুতকরণ, পর্যবেক্ষণ ও চিহ্নিতকরণ",
    engTitle: "Preparation, observation & identification of Monocot Root T.S."
  },
  {
    id: "bot_5",
    paper: "1st Paper (Botany)",
    title: "মালভেসি (Malvaceae) গোত্র (জবা ফুল) পর্যবেক্ষণ, পুষ্পপ্রতীক ও পুষ্পসংকেত নির্ণয়",
    engTitle: "Taxonomic study of Malvaceae: Floral morphology, diagram, and floral formula of Hibiscus"
  },
  {
    id: "bot_6",
    paper: "1st Paper (Botany)",
    title: "পয়েসি (Poaceae) গোত্রের শনাক্তকরণ ও পুষ্পপ্রতীক নির্ণয়",
    engTitle: "Taxonomic study of Poaceae: Floral characteristics and floral diagram of grass/rice flower"
  },
  {
    id: "bot_7",
    paper: "1st Paper (Botany)",
    title: "টেরিস (Pteris) উদ্ভিদের স্পোরোফাইট ও স্পোরাঞ্জিয়া পর্যবেক্ষণ",
    engTitle: "Morphological details & microscopic study of Fern (Pteris) sporophytic structures"
  },
  {
    id: "bot_8",
    paper: "1st Paper (Botany)",
    title: "কোবাল্ট ক্লোরাইড (CoCl2) পত্রের সাহায্যে পাতার প্রস্বেদন (Transpiration) হার পরীক্ষা ও তুলনামূলক জলীয় বাষ্প নির্গমন পরিমাপ",
    engTitle: "CoCl2 paper experiment for measuring transpiration rate in plant leaves"
  },
  {
    id: "bot_9",
    paper: "1st Paper (Botany)",
    title: "উদ্ভিদ শারীরতত্ত্ব: সালোকসংশ্লেষণে আলোর অপরিহার্যতার পরীক্ষা",
    engTitle: "Light necessity in Photosynthesis process experiment"
  },
  {
    id: "bot_10",
    paper: "1st Paper (Botany)",
    title: "উদ্ভিদ শারীরতত্ত্ব: অবাত শ্বসন পরীক্ষা",
    engTitle: "Anaerobic respiration demonstration experiment"
  },
  {
    id: "bot_11",
    paper: "1st Paper (Botany)",
    title: "খাদ্য উপাদানের রাসায়নিক পরীক্ষা: স্টার্চ বা শ্বেতসার দানা এবং হ্রাসকরণ শর্করা (Reducing Sugar) শনাক্তকরণ",
    engTitle: "Qualitative biochemical test for Starch, Reducing Sugar, and Proteins"
  },

  // --- 2nd Paper (Zoology) ---
  {
    id: "zoo_1",
    paper: "2nd Paper (Zoology)",
    title: "অণুজীব পর্যবেক্ষণ: অ্যামিবার ক্ষুদ্রাতিক্ষুদ্র গঠন ও স্থায়ী স্লাইড বা মডেল পর্যবেক্ষণ",
    engTitle: "Structural examination & description of Amoeba permanent slides or models"
  },
  {
    id: "zoo_2",
    paper: "2nd Paper (Zoology)",
    title: "হাইড্রার (Hydra) বিভিন্ন স্থায়ী স্লাইড ও মুকুলোদগম (Budding) পর্যবেক্ষণ",
    engTitle: "Histological slide study of Hydra structure and budding stage"
  },
  {
    id: "zoo_3",
    paper: "2nd Paper (Zoology)",
    title: "পরজীবী কৃমি: যকৃৎ-কৃমি (Fasciola) ও গোলকৃমির (Ascaris) বাহ্যিক বৈশিষ্ট্য ও স্থায়ী স্লাইড পর্যবেক্ষণ",
    engTitle: "Identification of Helminth parasites (Liver fluke and Roundworm slides)"
  },
  {
    id: "zoo_4",
    paper: "2nd Paper (Zoology)",
    title: "ঘাসফড়িংয়ের (Grasshopper) মুখোপাঙ্গ (Mouthparts) বিচ্ছিন্নকরণ, পর্যবেক্ষণ ও চিহ্নিতকরণ",
    engTitle: "Dissection, separation, and identification of Grasshopper Mouthparts"
  },
  {
    id: "zoo_5",
    paper: "2nd Paper (Zoology)",
    title: "ঘাসফড়িং বা আরশোলার পরিপাকতন্ত্র ব্যবচ্ছেদ ও পর্যবেক্ষণ",
    engTitle: "Dissection of Cockroach/Grasshopper digestive system"
  },
  {
    id: "zoo_6",
    paper: "2nd Paper (Zoology)",
    title: "রুই মাছের বাহ্যিক অঙ্গসংস্থান ও পরিপাকতন্ত্র ব্যবচ্ছেদ",
    engTitle: "Rohu fish morphology and digestive tract"
  },
  {
    id: "zoo_7",
    paper: "2nd Paper (Zoology)",
    title: "রুই মাছের মস্তিষ্ক ও ধমনীতন্ত্র প্রদর্শন",
    engTitle: "Dissection of brain & arterial system of Rohu fish"
  },
  {
    id: "zoo_8",
    paper: "2nd Paper (Zoology)",
    title: "রুই মাছের করোটিক স্নায়ুসহ মস্তিষ্ক ব্যবচ্ছেদ ও প্রদর্শন",
    engTitle: "Surgical dissection and extraction of cranial nerves & brain of Rohu fish"
  },
  {
    id: "zoo_9",
    paper: "2nd Paper (Zoology)",
    title: "মানুষের অক্ষীয় কঙ্কালের অস্থি (সারভাইকাল, থোরাসিক ও লাম্বার কশেরুকা) পর্যবেক্ষণ ও শনাক্তকারী বৈশিষ্ট্য নিরূপণ",
    engTitle: "Skeletal system: Identification of cervical, thoracic and lumbar vertebrae"
  },
  {
    id: "zoo_10",
    paper: "2nd Paper (Zoology)",
    title: "মানুষের উপাঙ্গীয় কঙ্কালের প্রধান অস্থিসমূহ শনাক্তকরণ (হিউমেরাস, রেডিয়াস-আলনা, ফিমার, টিবিয়া-ফিবুলা, পেক্টোরাল ও পেলভিক গার্ডেল)",
    engTitle: "Appendicular skeletal bones: Humerus, radius-ulna, femur, tibia-fibula, pelvic girdle"
  },
  {
    id: "zoo_11",
    paper: "2nd Paper (Zoology)",
    title: "লালা গ্রন্থির অ্যামাইলেজ এনজাইমের কার্যকারিতার পরীক্ষা (স্টার্চ পরিপাক পর্যবেক্ষণ)",
    engTitle: "Investigating the enzyme action of Salivary Amylase on starch solution"
  },
  {
    id: "zoo_12",
    paper: "2nd Paper (Zoology)",
    title: "স্তন্যপায়ীর স্থায়ী টিস্যু স্লাইড পর্যবেক্ষণ (যকৃৎ, অগ্ন্যাশয়, ফুসফুস ও বৃক্কের টিস্যুর ক্ষুদ্রাতিক্ষুদ্র গঠন)",
    engTitle: "Microscopic study of mammalian permanent slides: Liver, Pancreas, Lung & Kidney"
  }
];

interface ArtistsPageProps {
  activeTheme?: string;
}

export const ArtistsPage: React.FC<ArtistsPageProps> = ({ activeTheme }) => {
  const { user, token, apiFetch, login, logout, language, updateSession } = useAuth();

  // Lists & data indicators
  const [artists, setArtists] = useState<Artist[]>([]);
  const [artistViewMode, setArtistViewMode] = useState<'workspace' | 'marketplace'>('workspace');

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Specialties graphical tab filter instead of raw browser options dropdown
  const [subjectFilter, setSubjectFilter] = useState<string>('All');

  // Hiring commission State
  const [selectedArtistToHire, setSelectedArtistToHire] = useState<Artist | null>(null);
  const [hirePracticalTitle, setHirePracticalTitle] = useState<string>('');
  const [hireSubject, setHireSubject] = useState<string>('Physics');
  const [hireNotes, setHireNotes] = useState<string>('');
  const [hireStudentPhone, setHireStudentPhone] = useState<string>('');
  const [hireNotebookProvider, setHireNotebookProvider] = useState<'artist' | 'student'>('student');

  useEffect(() => {
    if (selectedArtistToHire && user?.phoneNumber) {
      setHireStudentPhone(user.phoneNumber);
    }
  }, [selectedArtistToHire, user]);

  // Custom Biology Selection Helper States
  const [biologyPaperTab, setBiologyPaperTab] = useState<'1st' | '2nd'>('1st');

  // Selected artist portfolio lightbox State
  const [activePortfolioArtist, setActivePortfolioArtist] = useState<Artist | null>(null);
  const [activeSampleIndex, setActiveSampleIndex] = useState<number | null>(null);
  const [activeInvoiceBooking, setActiveInvoiceBooking] = useState<Booking | null>(null);

  // Artist self management form fields (for logged-in artists)
  const [artistBio, setArtistBio] = useState<string>('');
  const [artistRate, setArtistRate] = useState<number>(150);
  const [artistAvailable, setArtistAvailable] = useState<boolean>(true);
  const [artistSpecs, setArtistSpecs] = useState<string[]>([]);
  const [newSpecItem, setNewSpecItem] = useState<string>('');
  const [newSampleUrl, setNewSampleUrl] = useState<string>('');
  const [artistAvatar, setArtistAvatar] = useState<string>('');

  // Device file uploader state and references
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const sampleInputRef = useRef<HTMLInputElement>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState<boolean>(false);
  const [uploadingSample, setUploadingSample] = useState<boolean>(false);
  const [isRemoveMode, setIsRemoveMode] = useState<boolean>(false);

  // Admin panel states for sketch portal management
  const [adminNewArtistName, setAdminNewArtistName] = useState<string>('');
  const [adminNewArtistEmail, setAdminNewArtistEmail] = useState<string>('');
  const [adminNewArtistPassword, setAdminNewArtistPassword] = useState<string>('');
  const [adminNewArtistRate, setAdminNewArtistRate] = useState<number>(125);
  const [adminIsSubmitting, setAdminIsSubmitting] = useState<boolean>(false);
  const [adminActiveTab, setAdminActiveTab] = useState<'roster' | 'add'>('roster');

  // Synchronise artists list and student drawings
  const loadInitialData = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const artRes = await apiFetch('/api/artists');
      if (artRes.ok) {
        const artData = await artRes.json();
        setArtists(artData);
      }
      
      if (user) {
        const bookRes = await apiFetch('/api/artists/bookings');
        if (bookRes.ok) {
          const bookData = await bookRes.json();
          // Sort by date descending
          bookData.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setBookings(bookData);
        }
      }
    } catch (err) {
      console.error("Failed to fetch artist or booking info:", err);
    } finally {
      setLoading(false);
    }
  };

  // Autoselect subject based on chosen artist's main specialties (restricting strictly to Physics or Biology)
  useEffect(() => {
    if (selectedArtistToHire) {
      const specs = selectedArtistToHire.specialties || [];
      const hasBio = specs.some(s => s.toLowerCase().includes('bio') || s.toLowerCase().includes('jib') || s.toLowerCase().includes('anat'));

      if (hasBio) {
        setHireSubject('Biology');
      } else {
        setHireSubject('Physics');
      }
    }
  }, [selectedArtistToHire]);

  useEffect(() => {
    loadInitialData();
  }, [user]);

  useEffect(() => {
    const handleHireUpdateEvent = () => {
      loadInitialData();
    };
    window.addEventListener('hire-updated', handleHireUpdateEvent);
    return () => {
      window.removeEventListener('hire-updated', handleHireUpdateEvent);
    };
  }, [user]);

  // Sync state with artist user details if logged in as artist
  useEffect(() => {
    if (user && user.role === 'artist') {
      const art = user as any;
      setArtistBio(art.bio || '');
      setArtistRate(art.ratePerDrawing || 150);
      setArtistAvailable(art.isAvailable !== false);
      setArtistSpecs(art.specialties || []);
      setArtistAvatar(art.avatar || '');
    }
  }, [user]);

  const triggerAlert = (type: 'success' | 'error', msg: string) => {
    if (type === 'success') {
      setSuccessMsg(msg);
      setTimeout(() => setSuccessMsg(null), 5000);
    } else {
      setErrorMsg(msg);
      setTimeout(() => setErrorMsg(null), 5000);
    }
  };

  // Admin controls to create certified artists
  const handleAddArtistByAdmin = async () => {
    if (!adminNewArtistName.trim() || !adminNewArtistEmail.trim() || !adminNewArtistPassword.trim()) {
      triggerAlert('error', 'All fields (Name, Email, Password) are required to add a certified artist.');
      return;
    }
    setAdminIsSubmitting(true);
    try {
      const res = await apiFetch('/api/admin/artists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: adminNewArtistName.trim(),
          email: adminNewArtistEmail.trim(),
          password: adminNewArtistPassword,
          ratePerDrawing: adminNewArtistRate
        })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', data.message || 'Certified Illustrating Artist added to the portal directory.');
        setAdminNewArtistName('');
        setAdminNewArtistEmail('');
        setAdminNewArtistPassword('');
        setAdminNewArtistRate(125);
        loadInitialData();
      } else {
        triggerAlert('error', data.error || 'Failed to add artist profile.');
      }
    } catch (err) {
      console.error(err);
      triggerAlert('error', 'Network failure adding artist.');
    } finally {
      setAdminIsSubmitting(false);
    }
  };

  // Admin control to delete/remove an artist
  const handleDeleteArtist = async (artistId: string) => {
    if (!window.confirm('Are you sure you want to permanently remove this artist from the sketch portal?')) {
      return;
    }
    try {
      const res = await apiFetch(`/api/admin/artists/${artistId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', data.message || 'Artist profile successfully deleted.');
        loadInitialData();
      } else {
        triggerAlert('error', data.error || 'Failed to delete artist profile.');
      }
    } catch (err) {
      console.error(err);
      triggerAlert('error', 'Network error occurred during deletion.');
    }
  };

  // Admin control to modify artist standard rate per sheet
  const handleUpdateArtistRate = async (artistId: string, newRate: number) => {
    if (newRate < 10) {
      triggerAlert('error', 'Standard rate cannot fall below ৳10 BDT.');
      return;
    }
    try {
      const res = await apiFetch(`/api/admin/artists/${artistId}/rate`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ratePerDrawing: newRate })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', `Adjusted artist rate to ৳${newRate} BDT.`);
        loadInitialData();
      } else {
        triggerAlert('error', data.error || 'Failed to modify rate.');
      }
    } catch (err) {
      console.error(err);
      triggerAlert('error', 'Network error adjusting artist rate.');
    }
  };

  // Handle student hiring submission
  const handleHireSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedArtistToHire) return;
    if (!hirePracticalTitle) {
      triggerAlert('error', 'Please formulate a clear practical title so the illustrator knows what drawing to build.');
      return;
    }
    if (!hireStudentPhone || !hireStudentPhone.trim()) {
      triggerAlert('error', 'A valid mobile phone number is strictly mandatory to hire a drawing artist.');
      return;
    }

    try {
      const res = await apiFetch('/api/artists/hire', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          artistId: selectedArtistToHire.id,
          practicalTitle: hirePracticalTitle,
          subject: hireSubject,
          notes: hireNotes,
          price: selectedArtistToHire.ratePerDrawing,
          studentPhone: hireStudentPhone.trim(),
          notebookProvider: hireNotebookProvider
        })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', data.message || `Successfully commissioned ${selectedArtistToHire.name}! Monitor active development status below.`);
        setSelectedArtistToHire(null);
        setHirePracticalTitle('');
        setHireNotes('');
        setHireStudentPhone('');
        setHireNotebookProvider('student');
        loadInitialData();
      } else {
        triggerAlert('error', data.error || 'Hiring submission failed.');
      }
    } catch (err) {
      triggerAlert('error', 'Failed to reach API gateway.');
    }
  };

  const handleAvatarDeviceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      triggerAlert('error', 'Only image files are accepted.');
      return;
    }

    setUploadingAvatar(true);
    const formData = new FormData();
    formData.append('image', file);
    try {
      const res = await apiFetch('/api/images/upload-file', {
        method: 'POST',
        body: formData,
      });
      if (res.ok) {
        const data = await res.json();
        if (data.url) {
          setArtistAvatar(data.url);
          triggerAlert('success', `Avatar file '${file.name}' compiled successfully! Click save to apply.`);
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        triggerAlert('error', errData.error || 'Failed to upload photo.');
      }
    } catch (e: any) {
      triggerAlert('error', `Upload failed: ${e.message}`);
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSampleDeviceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      triggerAlert('error', 'Only image files are accepted.');
      return;
    }

    setUploadingSample(true);
    const formData = new FormData();
    formData.append('image', file);
    try {
      const res = await apiFetch('/api/images/upload-file', {
        method: 'POST',
        body: formData,
      });
      if (res.ok) {
        const data = await res.json();
        if (data.url) {
          const currentSamples = (user as any)?.samples || [];
          const updatedSamples = [...currentSamples, data.url];
          
          const saveRes = await apiFetch('/api/artists/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ samples: updatedSamples })
          });
          
          if (saveRes.ok) {
            const saveData = await saveRes.json();
            triggerAlert('success', `Drawing '${file.name}' successfully uploaded and published directly to your live portfolio!`);
            if (saveData.user) {
              updateSession(token || '', saveData.user);
            }
            loadInitialData();
          } else {
            triggerAlert('error', 'Failed to save updated portfolio on server.');
          }
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        triggerAlert('error', errData.error || 'Failed to upload photo.');
      }
    } catch (e: any) {
      triggerAlert('error', `Upload failed: ${e.message}`);
    } finally {
      setUploadingSample(false);
    }
  };

  // Artist self profile update handler
  const handleArtistUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiFetch('/api/artists/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bio: artistBio,
          ratePerDrawing: Number(artistRate) || 150,
          isAvailable: artistAvailable,
          specialties: artistSpecs,
          avatar: artistAvatar
        })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', 'Your professional drawing configuration has been updated.');
        if (data.user) {
          updateSession(token || '', data.user);
        }
        loadInitialData();
      } else {
        triggerAlert('error', data.error || 'Failed to update studio records.');
      }
    } catch (ex) {
      triggerAlert('error', 'Network error while attempting profile update.');
    }
  };

  // Dynamic quick toggle of availability on artist dashboard
  const handleToggleAvailability = async () => {
    const nextAvailability = !artistAvailable;
    setArtistAvailable(nextAvailability);
    try {
      const res = await apiFetch('/api/artists/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          isAvailable: nextAvailability
        })
      });
      if (res.ok) {
        triggerAlert('success', `Status changed: You are now ${nextAvailability ? 'AVAILABLE' : 'BUSY'}.`);
        loadInitialData();
      } else {
        setArtistAvailable(!nextAvailability); // revert
        triggerAlert('error', 'Failed to update availability on database.');
      }
    } catch (_) {
      setArtistAvailable(!nextAvailability); // revert
      triggerAlert('error', 'Network fault updating availability state.');
    }
  };

  // Add specialty tag
  const addArtistProfileSpec = () => {
    if (newSpecItem.trim() && !artistSpecs.includes(newSpecItem.trim())) {
      setArtistSpecs([...artistSpecs, newSpecItem.trim()]);
      setNewSpecItem('');
    }
  };

  // Add a sample URL to Creator portfolio
  const handleAddSampleUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSampleUrl.trim()) return;
    const currentSamples = (user as any)?.samples || [];
    const updatedSamples = [...currentSamples, newSampleUrl.trim()];
    
    try {
      const res = await apiFetch('/api/artists/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samples: updatedSamples })
      });
      if (res.ok) {
        const data = await res.json();
        triggerAlert('success', 'Added sample artwork to your visual portfolio successfully.');
        setNewSampleUrl('');
        if (data.user) {
          updateSession(token || '', data.user);
        }
        loadInitialData();
      } else {
        triggerAlert('error', 'Failed to upload portfolio sample.');
      }
    } catch (_) {
      triggerAlert('error', 'Network failure.');
    }
  };

  // Remove sample from portfolio
  const handleRemoveSampleUrl = async (idxToRemove: number) => {
    const currentSamples = (user as any)?.samples || [];
    const updatedSamples = currentSamples.filter((_: any, idx: number) => idx !== idxToRemove);
    
    try {
      const res = await apiFetch('/api/artists/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samples: updatedSamples })
      });
      if (res.ok) {
        const data = await res.json();
        triggerAlert('success', 'Sample artwork removed successfully from your live showcase.');
        if (data.user) {
          updateSession(token || '', data.user);
        }
        loadInitialData();
      } else {
        triggerAlert('error', 'Failed to update portfolio samples.');
      }
    } catch (_) {
      triggerAlert('error', 'Network failure.');
    }
  };

  // Update Booking Status Handler (Pending, In Progress, Completed, Delivered, Cancel)
  const handleUpdateBookingStatus = async (bookingId: string, textStatus: string) => {
    try {
      const res = await apiFetch(`/api/artists/bookings/${bookingId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: textStatus })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', `Job status updated to ${textStatus.toUpperCase()} successfully.`);
        loadInitialData(true);
      } else {
        triggerAlert('error', data.error || 'Failed to mutate project status.');
      }
    } catch (err) {
      triggerAlert('error', 'Network error modifying status key.');
    }
  };

  // Submit Star Rating & Review Feedback (Fiverr-like)
  const handleSubmitReview = async (bookingId: string, rating: number, comment: string) => {
    try {
      const res = await apiFetch(`/api/artists/bookings/${bookingId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, comment })
      });
      const data = await res.json();
      if (res.ok) {
        triggerAlert('success', "Thank you! Your professional feedback and rating has been submitted.");
        loadInitialData(true);
      } else {
        triggerAlert('error', data.error || 'Failed to submit feedback.');
      }
    } catch (err) {
      triggerAlert('error', 'Network error submitting feedback.');
    }
  };

  // Calculate earnings
  const artistJobs = bookings.filter(b => b.artistId === user?.id);
  const finishedJobs = artistJobs.filter(b => b.status === 'completed' || b.status === 'delivered');
  const totalEarnings = finishedJobs.reduce((sum, job) => sum + job.price, 0);

  // Filtered artists for student view (filtration removed per request; show all)
  const filteredArtists = artists;

  // Helper method to retrieve standard milestones for commission tracker
  const getCommissionPhase = (status: string): number => {
    switch(status) {
      case 'pending': return 1;
      case 'sketching':
      case 'in_progress': return 2;
      case 'delivered':
      case 'completed': return 3;
      default: return 1;
    }
  };

  // Nested helper to render booking/order messaging panel
  const BookingChatPanel = ({ booking }: { booking: any }) => {
    const [messages, setMessages] = useState<any[]>(booking.messages || []);
    const [text, setText] = useState('');
    const [sending, setSending] = useState(false);
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
      if (booking.messages) {
        setMessages(booking.messages);
      }
    }, [booking.messages]);

    const handleSend = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!text.trim()) return;
      setSending(true);
      try {
        const res = await apiFetch(`/api/artists/bookings/${booking.id}/messages`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text }),
        });
        const data = await res.json();
        if (res.ok) {
          setText('');
          setMessages(prev => [...prev, data.newMessage]);
          loadInitialData(true); // Silent refresh
        } else {
          triggerAlert('error', data.error || 'Failed to dispatch message.');
        }
      } catch (_) {
        triggerAlert('error', 'Network failure sending message.');
      } finally {
        setSending(false);
      }
    };

    return (
      <div className="mt-3 pt-2.5 border-t border-white/[0.03]">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="text-[9px] font-mono font-bold uppercase tracking-wider text-amber-500 hover:text-amber-450 flex items-center gap-1.5 cursor-pointer"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>{isOpen ? 'Close Live Chat' : `Chat with ${user?.role === 'artist' ? 'Student' : 'Artist'} (${messages.length})`}</span>
        </button>

        {isOpen && (
          <div className="mt-2.5 bg-slate-950/60 rounded-xl border border-white/[0.04] p-3.5 space-y-3 shadow-inner">
            {/* Scrollable messages container */}
            <div className="max-h-40 overflow-y-auto space-y-2.5 pr-1 flex flex-col">
              {messages.length === 0 ? (
                <p className="text-[9px] text-slate-550 italic text-center py-4">No communication logs recorded yet. Start the conversation!</p>
              ) : (
                messages.map((msg: any) => {
                  const isMe = msg.senderId === user?.id;
                  return (
                    <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-full`}>
                      <span className="text-[7.5px] font-mono text-slate-500 mb-0.5">
                        {msg.senderName} ({msg.senderRole === 'artist' ? 'Artist' : 'Student'})
                      </span>
                      <div className={`px-3 py-1.5 rounded-2xl text-[10px] max-w-[85%] leading-normal font-sans break-words ${
                        isMe 
                          ? 'bg-indigo-650 text-white' 
                          : 'bg-slate-900 border border-white/[0.05] text-slate-250'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Text Input & Submit */}
            <form onSubmit={handleSend} className="flex gap-2">
              <input
                type="text"
                required
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Formulate message description..."
                className="flex-1 bg-slate-900 border border-white/5 focus:border-amber-500/20 rounded-xl px-3 py-2 text-[10px] text-slate-100 placeholder:text-slate-700 focus:outline-none"
              />
              <button
                type="submit"
                disabled={sending || !text.trim()}
                className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-black text-[9px] font-mono uppercase tracking-wider rounded-xl transition-all cursor-pointer shrink-0"
              >
                {sending ? 'Sending...' : 'Send'}
              </button>
            </form>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen text-slate-100 pb-16 select-none relative overflow-hidden transition-all duration-300 ${
      activeTheme === 'peaceful-purple' ? 'theme-peaceful-purple' :
      activeTheme === 'deep-blue' ? 'theme-deep-blue' :
      activeTheme === 'cosmic-black' ? 'theme-cosmic-black' :
      activeTheme === 'mesh-aurora' ? 'theme-mesh-aurora' :
      activeTheme === 'emerald-green' ? 'theme-emerald-green' :
      'bg-[#04060b]'
    }`}>
      
      {/* Dynamic Ambient Background Glows */}
      <div className="absolute top-[3%] left-[12%] w-[45%] h-[25%] rounded-full bg-gradient-to-br from-indigo-500/10 to-transparent blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[8%] right-[15%] w-[40%] h-[30%] rounded-full bg-gradient-to-tr from-amber-500/5 to-transparent blur-[140px] pointer-events-none" />
      <div className="absolute top-[50%] left-[40%] w-[35%] h-[35%] rounded-full bg-gradient-to-tr from-indigo-650/5 to-transparent blur-[150px] pointer-events-none" />

      {/* SYSTEM SUCCESS & ERROR BANNER */}
      <AnimatePresence>
        {successMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-[2000] w-full max-w-lg px-4"
          >
            <div className="flex items-center gap-3 p-4 bg-emerald-500/15 border border-emerald-500/20 rounded-2xl text-emerald-300 text-xs font-semibold shadow-2xl backdrop-blur-md">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          </motion.div>
        )}
        {errorMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-[2000] w-full max-w-lg px-4"
          >
            <div className="flex items-center gap-3 p-4 bg-rose-500/15 border border-rose-500/25 rounded-2xl text-rose-300 text-xs font-semibold shadow-2xl backdrop-blur-md">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          CASE A: DEDICATED ARTIST WORKSPACE DASHBOARD (role === 'artist')
          ========================================================================= */}
      {user && user.role === 'artist' && artistViewMode === 'workspace' ? (
        <div className="max-w-6xl mx-auto px-6 pt-8 space-y-8 relative z-10 animate-in fade-in duration-300">
          
          {/* Work Mode Switcher for Artists */}
          <div className="flex flex-col sm:flex-row items-center justify-between bg-slate-900/40 p-3 rounded-2xl border border-amber-500/10 gap-3">
            <div className="flex items-center gap-2 pl-1.5 text-left">
              <span className="w-2 h-2 rounded-full bg-amber-450 animate-pulse shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wider font-extrabold block">Dual-Role Workspace Connected</span>
                <span className="text-[9px] text-amber-300 font-mono block">Switch below to view the public marketplace as an artist</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 self-stretch sm:self-auto">
              <button
                type="button"
                onClick={() => setArtistViewMode('workspace')}
                className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold font-sans transition-all bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/10 border border-white/10 cursor-pointer"
              >
                💼 My Studio Workspace
              </button>
              <button
                type="button"
                onClick={() => setArtistViewMode('marketplace')}
                className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-semibold font-sans transition-all text-slate-400 hover:text-white hover:bg-white/[0.02] cursor-pointer"
              >
                🏛️ View Student Marketplace
              </button>
            </div>
          </div>
          
          {/* Header row */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 bg-slate-900/30 p-6 rounded-3xl border border-white/[0.05] backdrop-blur-md">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-300 font-mono tracking-widest uppercase mb-2 font-bold">
                <Sparkles className="w-3 h-3 animate-pulse" /> Professional Creator Workspace
              </div>
              <h2 className="text-2xl md:text-3xl font-black text-white font-sans tracking-tight leading-none">
                Welcome back, {user.name}! 🎨
              </h2>
              <p className="text-xs text-slate-400 mt-1.5 max-w-2xl leading-normal">
                Manage your lab drawing queue, modify rates and showcase hand-shaded physical schematics for AI Academy students.
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Live interactive availability switch */}
              <button
                onClick={handleToggleAvailability}
                className={`px-4 py-2.5 rounded-xl border font-sans text-xs font-bold transition-all duration-300 cursor-pointer flex items-center gap-2 ${
                  artistAvailable
                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/25 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                    : 'bg-rose-500/10 border-rose-500/20 text-rose-450 hover:bg-rose-500/20'
                }`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${artistAvailable ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
                <span>{artistAvailable ? 'AVAILABLE FOR CONTRACTS' : 'GO INDISPOSED (TEMPORARILY BUSY)'}</span>
              </button>

              <button
                onClick={logout}
                className="p-3 rounded-xl border border-white/5 bg-slate-950 text-slate-400 hover:text-rose-400 transition-all cursor-pointer shadow-lg hover:border-rose-550/20"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Upgraded Metrics Row */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900/20 border border-white/[0.04] space-y-1 shadow-md">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Completed Tasks</span>
              <span className="text-2xl font-extrabold font-mono text-white block">
                {bookings.filter(b => b.artistId === user.id && b.status === 'completed').length} drawing sheets
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/20 border border-white/[0.04] space-y-1 shadow-md">
              <span className="text-[9px] font-mono text-slate-550 uppercase tracking-widest block font-bold">Active Queue</span>
              <span className="text-2xl font-extrabold font-mono text-amber-400 block animate-pulse">
                {bookings.filter(b => b.artistId === user.id && (b.status === 'pending' || b.status === 'sketching' || b.status === 'in_progress')).length} pending
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/20 border border-white/[0.04] space-y-1 shadow-md">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">My Base rate</span>
              <span className="text-2xl font-extrabold font-mono text-indigo-400 block">৳{artistRate} BDT</span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/20 border border-white/[0.04] space-y-1 shadow-md">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Accrued Revenue</span>
              <span className="text-xl font-extrabold font-mono text-emerald-400 block">৳{totalEarnings} BDT <span className="text-[10px] text-slate-500">Secured</span></span>
            </div>

            <div className="p-5 rounded-2xl col-span-2 md:col-span-1 bg-slate-900/20 border border-white/[0.04] space-y-1 shadow-md">
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Client review Average</span>
              <span className="text-xl font-extrabold font-mono text-yellow-400 block flex items-center gap-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 inline" />
                {((user as any).rating || 5.0).toFixed(1)} / 5.0
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left column configuration editors (Col Span 5) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Studio Config Form */}
              <div className="p-6 rounded-3xl bg-slate-900/20 border border-white/[0.04] space-y-5">
                <h3 className="text-xs font-black tracking-widest uppercase font-mono text-white flex items-center gap-2 border-b border-white/[0.04] pb-2">
                  <Sliders className="w-4 h-4 text-amber-500" /> CONFIGURE WORKSPACE IDENT
                </h3>

                <form onSubmit={handleArtistUpdateProfile} className="space-y-4">
                  {/* Artist Avatar Editor: Upload from device or URL from internet */}
                  <div className="space-y-3 p-4 rounded-xl bg-slate-950/40 border border-white/5">
                    <span className="block text-[9px] text-slate-450 uppercase font-mono font-bold tracking-wider">Professional Profile Picture / Avatar</span>
                    
                    <div className="flex items-center gap-4">
                      <img 
                        src={artistAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150'} 
                        alt="My Profile Portrait" 
                        className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-white/10"
                        referrerPolicy="no-referrer"
                      />
                      
                      <div className="flex-1 space-y-2">
                        {/* Device upload option */}
                        <div className="flex items-center gap-2">
                          <input 
                            type="file"
                            accept="image/*"
                            ref={avatarInputRef}
                            onChange={handleAvatarDeviceUpload}
                            className="hidden"
                          />
                          <button
                            type="button"
                            disabled={uploadingAvatar}
                            onClick={() => avatarInputRef.current?.click()}
                            className="px-3 py-1.5 border border-white/10 hover:border-white/20 bg-slate-950 hover:bg-slate-900 text-white font-sans text-[10px] rounded-lg font-bold flex items-center gap-1 cursor-pointer transition-all disabled:opacity-40 select-none"
                          >
                            {uploadingAvatar ? 'Uploading...' : 'Upload from Device'}
                          </button>
                          
                          {artistAvatar && artistAvatar.startsWith('/uploads/') && (
                            <span className="text-[8px] text-emerald-400 font-mono tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 uppercase font-bold">DEVICE FILE READY</span>
                          )}
                        </div>

                        {/* Direct URL entry */}
                        <input
                          type="url"
                          placeholder="Or paste direct internet avatar URL"
                          value={artistAvatar}
                          onChange={(e) => setArtistAvatar(e.target.value)}
                          className="w-full text-[10px] px-3 py-2 rounded-lg bg-slate-950 border border-white/10 text-slate-200 focus:outline-none focus:border-amber-500 transition-all font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] text-slate-400 uppercase font-mono block font-bold pl-1">Biography & Shading Accents Pitch</label>
                    <textarea
                      value={artistBio}
                      onChange={(e) => setArtistBio(e.target.value)}
                      rows={3}
                      required
                      placeholder="Showcase your shading style, precision, and delivery quickness."
                      className="w-full text-xs p-3.5 rounded-xl bg-slate-950/70 border border-white/10 text-slate-200 focus:outline-none focus:border-amber-500 transition-all leading-relaxed resize-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] text-slate-400 uppercase font-mono block font-bold pl-1">Drawing rate (৳ BDT Per Sheet Plate)</label>
                    <input
                      type="number"
                      required
                      min={50}
                      max={2000}
                      value={artistRate}
                      onChange={(e) => setArtistRate(Number(e.target.value) || 120)}
                      className="w-full text-xs px-3.5 py-3 rounded-xl bg-slate-950/70 border border-white/10 text-slate-100 font-mono focus:outline-none focus:border-amber-500 transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] text-slate-400 uppercase font-mono block font-bold pl-1">Specialties & Experiment Keywords</label>
                    <div className="flex flex-wrap gap-1.5 min-h-[40px] p-2 rounded-xl bg-slate-950/40 border border-white/5">
                      {artistSpecs.length === 0 ? (
                        <span className="text-[10px] text-slate-600 italic p-1">No keywords added yet. add subject tags below.</span>
                      ) : (
                        artistSpecs.map((tag, i) => (
                          <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-950 border border-white/10 text-[9px] text-slate-300 flex items-center gap-1.5 font-mono">
                            {tag}
                            <button
                              type="button"
                              onClick={() => setArtistSpecs(artistSpecs.filter((_, idx) => idx !== i))}
                              className="text-rose-450 hover:text-white font-bold font-mono focus:outline-none cursor-pointer"
                            >
                              ×
                            </button>
                          </span>
                        ))
                      )}
                    </div>
                    
                    <div className="flex gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="e.g. Physics Optics, Biology physiology"
                        value={newSpecItem}
                        onChange={(e) => setNewSpecItem(e.target.value)}
                        className="px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-white/10 text-slate-100 text-xs flex-1 focus:outline-none focus:border-indigo-600"
                      />
                      <button
                        type="button"
                        onClick={addArtistProfileSpec}
                        className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-705 text-white text-xs font-black font-mono cursor-pointer transition-all uppercase tracking-wider"
                      >
                        Add Tag
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs tracking-widest uppercase hover:bg-amber-400 transition-all cursor-pointer shadow-lg shadow-amber-500/10 mt-2"
                  >
                    Save Studio Credentials
                  </button>
                </form>
              </div>

              {/* Portfolio Samples list inside Dashboard */}
              <div className="p-6 rounded-3xl bg-slate-900/25 border border-white/[0.04] space-y-4">
                <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                  <h3 className="text-xs font-black tracking-widest uppercase font-mono text-white flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-indigo-400" /> PORTFOLIO SPECIMEN SHOWCASE
                  </h3>
                  <div className="flex items-center gap-2">
                    {((user as any).samples || []).length > 0 && (
                      <button
                        type="button"
                        onClick={() => setIsRemoveMode(!isRemoveMode)}
                        className={`text-[10px] font-mono px-2.5 py-1 rounded-xl border transition-all cursor-pointer ${
                          isRemoveMode 
                            ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 font-bold' 
                            : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        {isRemoveMode ? 'Done Selection' : 'Remove'}
                      </button>
                    )}
                    <span className="text-[9px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 font-mono">
                      {((user as any).samples || []).length} drawings published
                    </span>
                  </div>
                </div>

                <div className="space-y-3.5 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-mono font-bold">Publish New Drawing Scan</span>
                    <span className="text-[8px] text-amber-400 font-mono uppercase tracking-wider">Direct live storage</span>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-2.5">
                    <input 
                      type="file"
                      accept="image/*"
                      ref={sampleInputRef}
                      onChange={handleSampleDeviceUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={uploadingSample}
                      onClick={() => sampleInputRef.current?.click()}
                      className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-amber-500/90 to-amber-600/90 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-sans text-xs rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 transition-all select-none shrink-0"
                    >
                      {uploadingSample ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          Browse Device Image
                        </>
                      )}
                    </button>

                    <span className="text-[10px] text-slate-650 font-mono py-1 font-bold">OR</span>

                    <input
                      type="url"
                      placeholder="Paste direct drawing picture URL from internet"
                      value={newSampleUrl}
                      onChange={(e) => setNewSampleUrl(e.target.value)}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 focus:outline-none focus:border-indigo-550 transition-all font-mono placeholder:text-slate-800"
                    />
                  </div>

                  {newSampleUrl && (
                    <div className="flex items-center justify-between p-2 rounded-lg bg-indigo-500/5 border border-indigo-500/10">
                      <span className="text-[9.5px] text-indigo-300 font-mono truncate max-w-[70%]">Selected: {newSampleUrl}</span>
                      <button
                        type="button"
                        onClick={handleAddSampleUrl}
                        className="px-3.5 py-1.5 bg-indigo-650 hover:bg-indigo-500 text-white font-black font-mono text-[9px] rounded-lg cursor-pointer uppercase transition-all shrink-0"
                      >
                        Publish Specimen
                      </button>
                    </div>
                  )}
                </div>

                {/* Show beautiful grid of sample drawings with interactive selection/hover delete */}
                <div className="grid grid-cols-3 gap-3 pt-1">
                  {((user as any).samples || []).map((url: string, index: number) => (
                    <div 
                      key={index} 
                      onClick={() => {
                        if (isRemoveMode) {
                          handleRemoveSampleUrl(index);
                        } else {
                          // Standard action, view in lightbox
                          setActivePortfolioArtist({
                            id: user?.id || '',
                            name: user?.name || '',
                            email: user?.email || '',
                            role: 'artist',
                            bio: (user as any).bio || '',
                            ratePerDrawing: (user as any).rate || (user as any).ratePerDrawing || 150,
                            rating: (user as any).rating || 5,
                            completedCount: (user as any).completedCount || 0,
                            isAvailable: (user as any).available !== false,
                            specialties: (user as any).specialties || [],
                            samples: (user as any).samples || [],
                            avatar: (user as any).profilePic || (user as any).avatar || ''
                          });
                          setActiveSampleIndex(index);
                        }
                      }}
                      className={`group relative h-24 rounded-2xl overflow-hidden border transition-all duration-300 bg-slate-950 shadow-md ${
                        isRemoveMode 
                          ? 'border-rose-500/50 ring-2 ring-rose-500/20 cursor-pointer scale-[0.98] hover:scale-[1.01]' 
                          : 'border-white/5 cursor-zoom-in'
                      }`}
                    >
                      <img src={url} alt="Sample Sketch item" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                      
                      {isRemoveMode ? (
                        /* Remove Mode Overlay: permanently visible */
                        <div className="absolute inset-0 bg-rose-950/40 backdrop-blur-[1px] flex flex-col items-center justify-center gap-1">
                          <div className="p-2 rounded-full bg-rose-600 text-white shadow-lg animate-pulse">
                            <Trash2 className="w-4 h-4" />
                          </div>
                          <span className="text-[8px] font-mono font-bold text-rose-200 uppercase tracking-widest bg-rose-900/60 px-1.5 py-0.5 rounded">Click to Delete</span>
                        </div>
                      ) : (
                        /* Standard Hover Overlay */
                        <div className="absolute inset-0 bg-slate-950/60 group-hover:opacity-100 opacity-0 transition-opacity flex flex-col items-center justify-center gap-1">
                          <span className="text-[8px] font-mono font-bold text-indigo-300 uppercase tracking-wider">Click to View</span>
                        </div>
                      )}
                      
                      <div className="absolute bottom-1 right-1 px-1 bg-slate-950/80 border border-white/10 rounded text-[7.5px] font-mono text-slate-400 group-hover:opacity-0 transition-opacity">
                        #{index + 1}
                      </div>
                    </div>
                  ))}
                  {((user as any).samples || []).length === 0 && (
                    <div className="col-span-3 py-10 text-center text-[11px] text-slate-550 border border-dashed border-white/5 rounded-2xl italic bg-slate-950/20 animate-pulse">
                      No diagram sheets published in your portfolio yet. Browse device scans to showcase your sketching skills instantly!
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* Right column active contract orders (Col Span 7) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="p-6 rounded-3xl bg-slate-900/20 border border-white/[0.04] space-y-5">
                <div className="flex items-center justify-between border-b border-white/[0.04] pb-2">
                  <h3 className="text-xs font-black tracking-widest uppercase font-mono text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-500 animate-spin [animation-duration:15s]" /> INCOMING DIAGRAM CONTRACT CONTRACTS
                  </h3>
                  <button
                    onClick={() => loadInitialData()}
                    className="p-1.5 px-3.5 rounded-lg border border-white/5 bg-slate-950 text-[9px] font-mono text-slate-400 hover:text-white cursor-pointer transition-all"
                  >
                    REFRESH BOARD
                  </button>
                </div>

                {artistJobs.length === 0 ? (
                  <div className="py-24 text-center space-y-3 bg-slate-950/20 border border-dashed border-white/5 rounded-2xl">
                    <Briefcase className="w-10 h-10 text-slate-650 mx-auto opacity-35" />
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      No active drawing projects are assigned to your studio yet. Mark yourself as AVAILABLE to capture physics & biology sketch orders!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {artistJobs.map((job) => (
                      <div 
                        key={job.id}
                        className="p-5 rounded-2xl bg-slate-950/45 border border-white/[0.03] space-y-4 relative overflow-hidden shadow-lg"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.03] pb-2">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 text-[9px] text-indigo-400 font-mono tracking-wider font-bold">
                              {job.subject}
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[8px] font-sans font-bold uppercase flex items-center gap-1 ${
                              (job as any).notebookProvider === 'artist' 
                                ? 'bg-amber-400/10 text-amber-400 border border-amber-500/20' 
                                : 'bg-slate-900 border border-white/5 text-slate-400'
                            }`}>
                              📙 {((job as any).notebookProvider === 'artist' || job.notebookProvider === 'artist') ? 'Artist Purchases Book' : 'Student Delivers Book'}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">ID: {job.id}</span>
                          </div>

                          <div className="text-right">
                            <span className="text-[8px] text-slate-500 block uppercase font-mono font-bold">Assigned Payout</span>
                            <span className="text-emerald-400 font-mono text-xs font-extrabold">৳{job.price} BDT</span>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-extrabold text-white text-sm">{job.practicalTitle}</h4>
                          <p className="text-[11px] text-slate-400 leading-relaxed mt-1">
                            <strong className="text-slate-300">Student Shade requirements:</strong> {job.notes || "No extra guidelines provided."}
                          </p>
                          <div className="text-[9px] text-slate-500 font-mono pt-2 flex flex-wrap gap-4">
                            <span>Scholar: <strong className="text-slate-450">{job.studentName}</strong> ({job.studentEmail})</span>
                            <span>• Ordered: {new Date(job.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>

                        {/* Responsive 3-Step Milestone Progress Bar for Artist */}
                        <div className="p-3 sm:p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-3">
                          <div className="flex items-center justify-between text-xs font-mono">
                            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                              Work Milestone Progress
                            </span>
                            <span className="text-[10px] font-extrabold text-indigo-400">
                              Phase {getCommissionPhase(job.status)} of 3
                            </span>
                          </div>

                          {/* Progress track */}
                          <div className="relative w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-500 rounded-full"
                              style={{ width: `${((getCommissionPhase(job.status) - 1) / 2) * 100}%` }}
                            />
                          </div>

                          {/* 3 Step Cards */}
                          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                            <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                              getCommissionPhase(job.status) >= 1 
                                ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300' 
                                : 'bg-slate-900/50 border-white/5 text-slate-500'
                            }`}>
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                                getCommissionPhase(job.status) >= 1 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'
                              }`}>
                                {getCommissionPhase(job.status) > 1 ? '✓' : '1'}
                              </div>
                              <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">1. Pending</span>
                            </div>

                            <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                              getCommissionPhase(job.status) >= 2 
                                ? 'bg-purple-500/10 border-purple-500/30 text-purple-300' 
                                : 'bg-slate-900/50 border-white/5 text-slate-500'
                            }`}>
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                                getCommissionPhase(job.status) >= 2 ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-500'
                              }`}>
                                {getCommissionPhase(job.status) > 2 ? '✓' : '2'}
                              </div>
                              <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">2. Sketching</span>
                            </div>

                            <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                              getCommissionPhase(job.status) >= 3 
                                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' 
                                : 'bg-slate-900/50 border-white/5 text-slate-500'
                            }`}>
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                                getCommissionPhase(job.status) >= 3 ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'
                              }`}>
                                {getCommissionPhase(job.status) >= 3 ? '✓' : '3'}
                              </div>
                              <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">3. Delivered</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2 border-t border-white/[0.05]">
                          <div className="flex items-center gap-3 flex-wrap">
                            <div>
                              <span className="text-[8px] text-slate-500 block uppercase font-mono font-bold">Current State</span>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase inline-block mt-0.5 ${
                                job.status === 'pending'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                                  : job.status === 'in_progress' || job.status === 'sketching'
                                  ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20'
                                  : job.status === 'delivered' || job.status === 'completed'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-slate-800 text-slate-400'
                              }`}>
                                ● {job.status === 'in_progress' ? 'sketching' : job.status}
                              </span>
                            </div>
                            <div>
                              <span className="text-[8px] text-slate-500 block uppercase font-mono font-bold">Offline Cash</span>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase inline-block mt-0.5 ${
                                job.paymentStatus === 'paid' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                              }`}>
                                {job.paymentStatus === 'paid' ? 'CASH PAID' : 'PENDING'}
                              </span>
                            </div>
                          </div>

                          {/* Action panel */}
                          <div className="w-full sm:w-auto flex justify-end gap-2">
                            {job.status === 'pending' && (
                              <button
                                onClick={() => handleUpdateBookingStatus(job.id, 'sketching')}
                                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-all cursor-pointer uppercase shadow-md shadow-indigo-600/10"
                              >
                                Accept & Start Sketching
                              </button>
                            )}

                            {(job.status === 'in_progress' || job.status === 'sketching') && (
                              <button
                                onClick={() => handleUpdateBookingStatus(job.id, 'delivered')}
                                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs transition-all cursor-pointer uppercase shadow-md shadow-emerald-600/10"
                              >
                                Deliver Completed Drawing
                              </button>
                            )}

                            {(job.status === 'delivered' || job.status === 'completed') && (
                              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 py-1">
                                ✓ Work Delivered
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Live messaging feed inside order card */}
                        <BookingChatPanel booking={job} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      ) : (
        /* =========================================================================
            CASE B: CONSOLIDATED UNIFIED STUDENT VIEW (GUEST OR STUDENT ACCOUNTS)
            ========================================================================= */
        <div className="max-w-6xl mx-auto px-6 pt-10 space-y-10 relative z-10 animate-in fade-in duration-300">
          
          {/* Work Mode Switcher for Artists in Marketplace View */}
          {user && user.role === 'artist' && (
            <div className="flex flex-col sm:flex-row items-center justify-between bg-slate-900/40 p-3 rounded-2xl border border-indigo-500/10 gap-3">
              <div className="flex items-center gap-2 pl-1.5 text-left">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse shrink-0" />
                <div>
                  <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wider font-extrabold block">Student Marketplace View Mode</span>
                  <span className="text-[9px] text-indigo-300 font-mono block">You are browsing other creators. Click to return to order queue management.</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 self-stretch sm:self-auto">
                <button
                  type="button"
                  onClick={() => setArtistViewMode('workspace')}
                  className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-semibold font-sans transition-all text-slate-400 hover:text-white hover:bg-white/[0.02] cursor-pointer"
                >
                  💼 My Studio Workspace
                </button>
                <button
                  type="button"
                  onClick={() => setArtistViewMode('marketplace')}
                  className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold font-sans transition-all bg-gradient-to-r from-indigo-500 to-indigo-650 text-white shadow-md border border-white/5 cursor-pointer"
                >
                  🏛️ View Student Marketplace
                </button>
              </div>
            </div>
          )}

          {/* Header area - Beautiful bento-inspired designer header */}
          <div className="text-center space-y-4 max-w-3xl mx-auto pb-4 relative">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/15 text-xs text-indigo-300 font-mono tracking-widest uppercase font-bold shadow-sm">
              <Palette className="w-3.5 h-3.5 text-amber-500 animate-pulse" /> CERTIFIED SHADING ATELIER
            </div>
            
            <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white leading-none">
              HSC Practical <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-indigo-400 bg-clip-text text-transparent filter drop-shadow-md">Sketch Artists Hub</span>
            </h1>
            
            <p className="text-xs md:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
              Get hand-shaded, high-definition diagrams. Hire verified expert STEM illustrators to construct physics circuits, biology organelles and chemistry apparatus equations for direct notebook grading.
            </p>
          </div>



          {/* 🔧 SYSTEM ADMINISTRATOR MASTER SKETCH PORTAL PANEL */}
          {user?.role === 'admin' && (
            <div className="p-6 rounded-3xl bg-slate-900 border border-indigo-500/25 space-y-6 shadow-2xl shadow-indigo-950/20">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/[0.04] pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                    <Sliders className="w-5 h-5 text-indigo-400 shrink-0" />
                  </div>
                  <div>
                    <h2 className="text-sm font-black text-white uppercase tracking-widest font-mono">
                      SYSTEM PORTAL AUTHORITY SUITE
                    </h2>
                    <p className="text-[10px] text-slate-400 font-semibold font-sans">
                      Durable controls to hire/fire partners, modify catalog, audit registrations, and govern direct scale prices.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-white/5">
                  <button
                    onClick={() => setAdminActiveTab('roster')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      adminActiveTab === 'roster'
                        ? 'bg-indigo-650 text-white shadow-indigo-500/25 shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-white/[0.02]'
                    }`}
                  >
                    Manage Crew Roster ({artists.length})
                  </button>
                  <button
                    onClick={() => setAdminActiveTab('add')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      adminActiveTab === 'add'
                        ? 'bg-indigo-650 text-white shadow-indigo-500/25 shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-white/[0.02]'
                    }`}
                  >
                    Add Certified Partner
                  </button>
                </div>
              </div>

              {adminActiveTab === 'roster' ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[10px] tracking-wider uppercase font-mono text-slate-400 font-black">
                      Active Illustrators Directory & Live Price Escalator
                    </h3>
                    <span className="text-[9px] font-mono text-indigo-300 bg-indigo-500/5 px-2.5 py-0.5 rounded border border-indigo-500/10">
                      Standard pricing updates cascade in real-time
                    </span>
                  </div>

                  {artists.length === 0 ? (
                    <div className="p-8 text-center bg-slate-950/40 rounded-2xl border border-white/5 text-slate-500 text-xs font-mono">
                      No active artists found in database. Feel free to register one in the second tab!
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-2xl border border-white/5 bg-slate-950/60">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-white/[0.04] bg-slate-950 text-[10px] uppercase font-mono text-slate-450 tracking-wider font-extrabold">
                            <th className="py-3 px-4">Illustrator</th>
                            <th className="py-3 px-4">Contact Info</th>
                            <th className="py-3 px-4">Specialties & Activity</th>
                            <th className="py-3 px-4 text-center">Adjust Rate (৳ BDT)</th>
                            <th className="py-3 px-4 text-right">Administrative Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.02] font-sans">
                          {artists.map((art) => (
                            <tr key={art.id} className="hover:bg-white/[0.01] transition-colors">
                              <td className="py-3 px-4">
                                <div className="flex items-center gap-3">
                                  <img
                                    src={art.avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150'}
                                    alt={art.name}
                                    className="w-9 h-9 rounded-lg object-cover border border-white/10 shadow-sm shrink-0"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div>
                                    <div className="font-bold text-white text-[12px]">{art.name}</div>
                                    <span className="text-[8px] font-mono text-indigo-400 uppercase tracking-widest font-bold">
                                      ID: {art.id}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                                {art.email}
                              </td>
                              <td className="py-3 px-4">
                                <div className="space-y-1.5">
                                  <div className="flex flex-wrap gap-1">
                                    {(art.specialties || []).map((sp, keyidx) => (
                                      <span key={keyidx} className="bg-slate-900 px-1.5 py-0.5 rounded text-[8px] text-slate-400 border border-white/[0.04]">
                                        {sp}
                                      </span>
                                    ))}
                                  </div>
                                  <div className="text-[9.5px] text-slate-500 font-mono">
                                    Completed: <b className="text-slate-350">{art.completedCount || 0} sheets</b>
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-4">
                                <div className="flex items-center justify-center gap-2 max-w-[170px] mx-auto bg-slate-900 border border-white/5 rounded-xl p-1 shadow-sm">
                                  {/* Decrement Button */}
                                  <button
                                    onClick={() => handleUpdateArtistRate(art.id, art.ratePerDrawing - 10)}
                                    className="w-6 h-6 rounded-lg bg-slate-950 hover:bg-slate-800 text-rose-400 flex items-center justify-center text-xs font-black transition-all cursor-pointer active:scale-90"
                                    title="Reduce rate by ৳10"
                                  >
                                    -
                                  </button>
                                  {/* Value Input */}
                                  <input
                                    type="number"
                                    value={art.ratePerDrawing}
                                    onChange={(e) => handleUpdateArtistRate(art.id, Math.max(10, Number(e.target.value) || 120))}
                                    className="w-16 bg-transparent text-center font-mono text-white text-xs font-black outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                  />
                                  {/* Increment Button */}
                                  <button
                                    onClick={() => handleUpdateArtistRate(art.id, art.ratePerDrawing + 10)}
                                    className="w-6 h-6 rounded-lg bg-slate-950 hover:bg-slate-800 text-emerald-450 flex items-center justify-center text-xs font-black transition-all cursor-pointer active:scale-90"
                                    title="Increase rate by ৳10"
                                  >
                                    +
                                  </button>
                                </div>
                              </td>
                              <td className="py-3 px-4 text-right">
                                <button
                                  onClick={() => handleDeleteArtist(art.id)}
                                  className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/15 text-[10px] font-mono font-black uppercase tracking-wider transition-all duration-200 inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Fire Profile</span>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <h3 className="text-[10px] tracking-wider uppercase font-mono text-slate-400 font-black">
                    Register Certified STEM Drawing Partner
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end text-xs text-left">
                    <div className="space-y-1">
                      <label className="text-[9.5px] uppercase font-mono text-slate-400 block font-bold">Partner Full Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Faisal Rahman"
                        value={adminNewArtistName}
                        onChange={(e) => setAdminNewArtistName(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/10 text-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none placeholder:text-slate-700"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9.5px] uppercase font-mono text-slate-400 block font-bold">Email / Login Username</label>
                      <input
                        type="email"
                        placeholder="e.g. faisal@sketch.com"
                        value={adminNewArtistEmail}
                        onChange={(e) => setAdminNewArtistEmail(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/10 text-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none placeholder:text-slate-700"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9.5px] uppercase font-mono text-slate-400 block font-bold">Secret Passphrase Phrase</label>
                      <input
                        type="password"
                        placeholder="Minimum 6 characters"
                        value={adminNewArtistPassword}
                        onChange={(e) => setAdminNewArtistPassword(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/10 text-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none placeholder:text-slate-700"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9.5px] uppercase font-mono text-slate-400 block font-bold font-sans">Initial Rate per Diagram (৳)</label>
                      <div className="flex gap-2">
                        <input
                          type="number"
                          placeholder="e.g. 150"
                          value={adminNewArtistRate}
                          onChange={(e) => setAdminNewArtistRate(Number(e.target.value) || 120)}
                          className="w-24 px-3 py-2 bg-slate-950 border border-white/10 text-white rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none font-mono"
                        />
                        <button
                          onClick={handleAddArtistByAdmin}
                          disabled={adminIsSubmitting}
                          className="flex-1 py-1.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black font-mono uppercase tracking-wider transition-all disabled:opacity-50 active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer shadow-indigo-900/40"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>{adminIsSubmitting ? 'Adding...' : 'Add Artist'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* LEFT SECTION (Col Span 7): BROWSE DRAWING CREW */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="flex items-center justify-between border-b border-white/[0.04] pb-3">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                    <Brush className="w-4 h-4 text-amber-400 shrink-0" /> AVAILABLE ILLUSTRATORS ({filteredArtists.length})
                  </h3>
                  <p className="text-[11px] text-slate-500 font-sans">Hand sketches aligning with exact STEM board score criteria.</p>
                </div>
                
                <span className="text-[10px] text-amber-500/80 bg-amber-500/5 px-2.5 py-1 rounded-lg border border-amber-500/10 font-mono">
                  ● 100% SECURE ESCROW CONTRACTS
                </span>
              </div>

              {loading ? (
                <div className="py-24 text-center space-y-3 bg-slate-950/20 border border-white/5 rounded-3xl">
                  <div className="w-8 h-8 rounded-full border-t-2 border-amber-500 animate-spin mx-auto" />
                  <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest animate-pulse">RECONSTITUTING DRAWING PROFILES...</p>
                </div>
              ) : filteredArtists.length === 0 ? (
                <div className="py-20 text-center bg-slate-900/10 border border-dashed border-white/5 rounded-3xl p-6">
                  <HelpCircle className="w-10 h-10 text-slate-650 mx-auto opacity-35 mb-2.5 animate-bounce" />
                  <p className="text-xs text-slate-400">No sketch artists listed correspond to the selected criteria.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 animate-in fade-in duration-300">
                  {filteredArtists.map((artist) => {
                    return (
                      <div 
                        key={artist.id}
                        className="p-5 rounded-2xl bg-slate-900/15 hover:bg-slate-900/35 border border-white/[0.04] hover:border-amber-500/20 transition-all duration-300 flex flex-col justify-between space-y-4 shadow-lg group relative"
                      >
                        <div className="space-y-3.5">
                           <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <img 
                                src={artist.avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150'} 
                                alt={artist.name} 
                                className="w-12 h-12 rounded-xl object-cover border border-white/10 shrink-0 shadow-md group-hover:scale-105 transition-all duration-300" 
                                referrerPolicy="no-referrer"
                              />
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-white text-xs truncate group-hover:text-amber-400 transition-colors">{artist.name}</h4>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                  <span className="flex items-center text-amber-400 text-[10px] font-extrabold">
                                    <Star className="w-3 h-3 fill-amber-400 text-amber-400 mr-0.5" />
                                    {artist.rating.toFixed(1)}
                                  </span>
                                  <span className="text-[9px] text-slate-500 font-mono truncate">• {artist.completedCount || 0} sheets drawn</span>
                                </div>
                              </div>
                            </div>
 
                            <span className={`px-2 py-0.5 rounded-full text-[8px] font-mono tracking-wider uppercase font-extrabold ${
                              artist.isAvailable 
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.05)]' 
                                : 'bg-rose-500/10 text-rose-450 border border-rose-500/15'
                            }`}>
                              {artist.isAvailable ? 'AVAILABLE' : 'BUSY'}
                            </span>
                          </div>
 
                          <p className="text-[11px] text-slate-400 leading-normal italic line-clamp-2">
                            "{artist.bio || 'Accurate metrics and textbook level hand diagrams.'}"
                          </p>
 
                          <div className="flex flex-wrap gap-1 leading-none pt-0.5">
                            {artist.specialties.slice(0, 3).map((sp, keyidx) => (
                              <span key={keyidx} className="bg-slate-950 px-2 py-1 rounded-md text-[8px] text-slate-400 border border-white/[0.04] font-mono">
                                {sp}
                              </span>
                            ))}
                          </div>
                        </div>
 
                        <div className="pt-3.5 border-t border-white/[0.03] flex items-center justify-between">
                          <div>
                            <span className="text-[8px] text-slate-500 block uppercase font-mono font-bold">
                              Standard rate
                            </span>
                            <span className="text-slate-100 font-mono font-extrabold text-xs">
                              ৳{artist.ratePerDrawing} BDT <span className="text-[9px] text-slate-500 font-normal">/ drawing</span>
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            {artist.samples && artist.samples.length > 0 && (
                              <button
                                onClick={() => setActivePortfolioArtist(artist)}
                                className="px-3 py-1.5 rounded-xl border border-white/5 bg-slate-950 text-slate-350 hover:text-white text-[10px] font-black cursor-pointer font-sans transition-all active:scale-95 hover:border-indigo-500/20 block"
                              >
                                PORTFOLIO
                              </button>
                            )}

                            <button
                              disabled={!artist.isAvailable}
                              onClick={() => {
                                if (!user) {
                                  triggerAlert('error', 'Please register or log in first to draft drawing contracts!');
                                  return;
                                }
                                setSelectedArtistToHire(artist);
                              }}
                              className={`px-4 py-1.5 rounded-xl text-[10px] transition-all font-black cursor-pointer border uppercase tracking-wider ${
                                artist.isAvailable
                                  ? 'bg-amber-500 border-amber-400/20 text-slate-950 hover:bg-amber-400 active:scale-95 shadow-md shadow-amber-500/5'
                                  : 'bg-slate-950 border-transparent text-slate-650 cursor-not-allowed'
                              }`}
                            >
                              Hire
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Informative tips */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-950/10 via-indigo-950/15 to-slate-950/20 border border-white/5 space-y-2.5 font-sans">
                <h4 className="text-[10px] font-mono tracking-widest text-indigo-400 uppercase font-black flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-bounce" /> EXPERIMENT DIAGRAMS METRIC MATRIX
                </h4>
                <p className="text-slate-400 leading-relaxed text-xs">
                  All commissioned drawings conform 100% to board syllabus guidelines. Sketches are made on standard A4 drawing pages using grade-appropriate pencil shading (2B, 4B, 6B), clean alignment layouts, millimetric proportional margin ratios and correct anatomical labels.
                </p>
              </div>

            </div>

            {/* RIGHT SECTION (Col Span 5): MY ORDERS SYSTEM PANEL */}
            <div className="lg:col-span-5 bg-slate-900/15 p-6 rounded-3xl border border-white/[0.04] space-y-6">
              
              <div className="border-b border-white/[0.04] pb-3">
                <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-400 shrink-0" /> MY ACTIVE COMMISSIONS
                </h3>
                <p className="text-[11px] text-slate-500 font-sans">Review project contract milestones, handshakes and tracking.</p>
              </div>

              {!user ? (
                <div className="py-16 text-center space-y-4 bg-slate-950/20 rounded-2xl p-5 border border-dashed border-white/5">
                  <User className="w-10 h-10 text-slate-650 mx-auto opacity-35" />
                  <div className="text-xs text-slate-450 max-w-xs mx-auto leading-relaxed font-sans">
                    Please <strong className="text-amber-400 font-black">register or log in</strong> using the main menu credentials to commission sketch profiles and track delivery pipelines.
                  </div>
                </div>
              ) : bookings.length === 0 ? (
                <div className="py-16 text-center space-y-3.5 border border-dashed border-white/5 rounded-2xl p-6">
                  <FileText className="w-10 h-10 text-slate-650 mx-auto opacity-30" />
                  <h5 className="text-xs font-bold text-slate-400">No active drawing orders</h5>
                  <p className="text-[10.5px] text-slate-500 leading-relaxed font-sans">
                    Your drawing queue is empty. Click "Hire" beside any available STEM artist and assign your first experiment workbook diagram!
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[580px] overflow-y-auto pr-1">
                  {bookings.map((booking) => (
                    <div 
                      key={booking.id}
                      className="p-4 rounded-2xl bg-slate-950/80 border border-white/[0.03] space-y-3 animate-in fade-in shadow-md"
                    >
                      <div className="flex items-center justify-between border-b border-white/[0.03] pb-1.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 text-[8px] text-indigo-400 font-mono uppercase font-bold tracking-wider">
                            {booking.subject}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[8px] font-sans font-bold uppercase flex items-center gap-1 ${
                            (booking as any).notebookProvider === 'artist' 
                              ? 'bg-amber-400/10 text-amber-400 border border-amber-500/20' 
                              : 'bg-slate-900 border border-white/5 text-slate-400'
                          }`}>
                            📙 {((booking as any).notebookProvider === 'artist' || booking.notebookProvider === 'artist') ? 'Artist Purchases Book' : 'Student Delivers Book'}
                          </span>
                        </div>
                        <span className="text-[9px] font-mono text-slate-500">ID: {booking.id}</span>
                      </div>

                      <div>
                        <h4 className="font-extrabold text-white text-xs">{booking.practicalTitle}</h4>
                        <p className="text-[10px] text-slate-450 line-clamp-2 mt-0.5 leading-relaxed font-sans italic">
                          "{booking.notes || 'No specific instructions defined.'}"
                        </p>
                      </div>

                      {/* Responsive 3-Step Milestone Progress Bar for Student */}
                      <div className="p-3 sm:p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-3">
                        <div className="flex items-center justify-between text-xs font-mono">
                          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                            Work Milestone Progress
                          </span>
                          <span className="text-[10px] font-extrabold text-indigo-400">
                            Phase {getCommissionPhase(booking.status)} of 3
                          </span>
                        </div>

                        {/* Progress track */}
                        <div className="relative w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-500 rounded-full"
                            style={{ width: `${((getCommissionPhase(booking.status) - 1) / 2) * 100}%` }}
                          />
                        </div>

                        {/* 3 Step Cards */}
                        <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                          <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                            getCommissionPhase(booking.status) >= 1 
                              ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300' 
                              : 'bg-slate-900/50 border-white/5 text-slate-500'
                          }`}>
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                              getCommissionPhase(booking.status) >= 1 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'
                            }`}>
                              {getCommissionPhase(booking.status) > 1 ? '✓' : '1'}
                            </div>
                            <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">1. Pending</span>
                          </div>

                          <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                            getCommissionPhase(booking.status) >= 2 
                              ? 'bg-purple-500/10 border-purple-500/30 text-purple-300' 
                              : 'bg-slate-900/50 border-white/5 text-slate-500'
                          }`}>
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                              getCommissionPhase(booking.status) >= 2 ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-500'
                            }`}>
                              {getCommissionPhase(booking.status) > 2 ? '✓' : '2'}
                            </div>
                            <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">2. Sketching</span>
                          </div>

                          <div className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all ${
                            getCommissionPhase(booking.status) >= 3 
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' 
                              : 'bg-slate-900/50 border-white/5 text-slate-500'
                          }`}>
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono mb-1 ${
                              getCommissionPhase(booking.status) >= 3 ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'
                            }`}>
                              {getCommissionPhase(booking.status) >= 3 ? '✓' : '3'}
                            </div>
                            <span className="text-[9px] sm:text-[10px] font-bold truncate w-full">3. Delivered</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-white/[0.05] grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                        <div>
                          <span className="text-slate-500 block text-[7.5px] uppercase font-mono font-bold">Artist Drawer</span>
                          <strong className="text-slate-300 font-sans">{booking.artistName}</strong>
                        </div>

                        <div>
                          <span className="text-slate-500 block text-[7.5px] uppercase font-mono font-bold">Settled Cost</span>
                          <strong className="text-amber-500 font-mono">৳{booking.price} BDT</strong>
                        </div>

                        <div>
                          <span className="text-slate-500 block text-[7.5px] uppercase font-mono font-bold">Offline Cash</span>
                          <span className={`font-mono text-[8.5px] font-black uppercase ${
                            booking.paymentStatus === 'paid' ? 'text-emerald-400' : 'text-amber-500 animate-pulse'
                          }`}>
                            {booking.paymentStatus === 'paid' ? 'CASH PAID' : 'PENDING'}
                          </span>
                        </div>

                        <div>
                          <span className="text-slate-500 block text-[7.5px] uppercase font-mono font-bold">State Stage</span>
                          <span className={`inline-block px-1.5 py-0.5 rounded text-[8px] font-mono tracking-wider font-extrabold uppercase ${
                            booking.status === 'pending'
                              ? 'bg-amber-500/10 text-amber-400 animate-pulse'
                              : booking.status === 'in_progress' || booking.status === 'sketching'
                              ? 'bg-indigo-500/10 text-indigo-300'
                              : booking.status === 'delivered' || booking.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.06)]'
                              : 'bg-slate-800 text-slate-400'
                          }`}>
                            {booking.status === 'in_progress' ? 'sketching' : booking.status}
                          </span>
                        </div>
                      </div>

                      {/* Action trigger based on current status */}
                      <div className="flex justify-end gap-1.5 pt-1.5 border-t border-white/[0.02] flex-wrap">
                        <button
                          onClick={() => setActiveInvoiceBooking(booking)}
                          className="bg-indigo-950/45 border border-indigo-500/25 hover:bg-indigo-900/40 text-indigo-300 px-3 py-1.5 rounded-xl text-[9px] font-black transition-all cursor-pointer uppercase font-mono flex items-center gap-1 shadow-sm select-none"
                          title="View & Print Official Academy Invoice"
                        >
                          <FileText className="w-3 h-3 text-indigo-400" />
                          <span>Invoice</span>
                        </button>

                        {booking.status === 'pending' && (
                          <button
                            onClick={() => handleUpdateBookingStatus(booking.id, 'cancelled')}
                            className="bg-rose-950/20 border border-rose-500/15 hover:bg-rose-950/40 text-rose-400 px-3 py-1.5 rounded-xl text-[9px] font-black transition-all cursor-pointer uppercase font-mono"
                          >
                            Cancel request
                          </button>
                        )}

                        {(booking.status === 'delivered' || booking.status === 'completed') && (
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 px-2 py-1">
                            ✓ Drawing Sheet Delivered
                          </span>
                        )}

                        {booking.status === 'cancelled' && (
                          <span className="text-[8.5px] font-mono text-rose-500 flex items-center gap-1 leading-none">
                            Contract cancelled.
                          </span>
                        )}
                      </div>

                      {/* Live messaging feed inside order card */}
                      <BookingChatPanel booking={booking} />

                      {/* Fiverr-like rating feedback interface for completed commissions */}
                      {booking.status === 'completed' && (
                        <div className="mt-3.5 pt-3 border-t border-white/[0.03]">
                          {booking.review ? (
                            <div className="bg-emerald-950/10 border border-emerald-500/10 rounded-2xl p-3 space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="text-[8.5px] font-mono font-bold text-slate-400">CERTIFIED RATING:</span>
                                <div className="flex items-center gap-0.5">
                                  {[...Array(5)].map((_, i) => (
                                    <Star 
                                      key={i} 
                                      className={`w-3 h-3 ${
                                        i < booking.review!.rating ? 'text-yellow-450 fill-yellow-450' : 'text-slate-800'
                                      }`} 
                                    />
                                  ))}
                                </div>
                                <span className="text-[10px] font-mono font-bold text-amber-400">({booking.review.rating}.0)</span>
                              </div>
                              {booking.review.comment && (
                                <p className="text-[10.5px] text-slate-300 italic font-sans">
                                  "{booking.review.comment}"
                                </p>
                              )}
                            </div>
                          ) : (
                            <ReviewForm 
                              bookingId={booking.id} 
                              onSubmitReview={handleSubmitReview} 
                            />
                          )}
                        </div>
                      )}

                      {/* Admin Escrow Controls */}
                      {user?.role === 'admin' && (
                        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/45 border border-white/[0.04] mt-2.5">
                          <div className="text-[10px] font-mono">
                            <span className="text-slate-500 uppercase block text-[8px] font-bold">Offline Cash Payment Status</span>
                            <span className={booking.paymentStatus === 'paid' ? 'text-emerald-400 font-black' : 'text-amber-550 font-bold'}>
                              {booking.paymentStatus === 'paid' ? '✓ CASH PAID & APPROVED' : '⚡ PENDING OFFLINE CASH'}
                            </span>
                          </div>
                          <button
                            onClick={async () => {
                              try {
                                const res = await apiFetch(`/api/artists/bookings/${booking.id}/pay`, { method: 'POST' });
                                if (res.ok) {
                                  triggerAlert('success', booking.paymentStatus === 'paid' ? "Offline cash payment marked as unpaid/pending." : "Offline cash payment approved as paid successfully!");
                                  loadInitialData();
                                } else {
                                  triggerAlert('error', "Failed to adjust payment status.");
                                }
                              } catch (e) {
                                triggerAlert('error', "Network error updating payment status.");
                              }
                            }}
                            className={`px-3 py-1.5 rounded-lg text-[9px] font-mono font-black uppercase transition-all cursor-pointer ${
                              booking.paymentStatus === 'paid'
                                ? 'bg-amber-950/20 border border-amber-500/20 text-amber-400 hover:bg-amber-950/40'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                            }`}
                          >
                            {booking.paymentStatus === 'paid' ? 'Mark Unpaid' : 'Confirm Cash Received'}
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

            </div>

          </div>

        </div>
      )}

      {/* =========================================================================
          MODAL 1: DRAW PORTFOLIO LIGHTBOX VIEW FOR ACTIVE ARTIST
          ========================================================================= */}
      <AnimatePresence>
        {activePortfolioArtist && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-2xl rounded-3xl border border-white/10 bg-slate-900 p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between border-b border-white/[0.04] pb-4">
                <div className="flex items-center gap-3">
                  <img 
                    src={activePortfolioArtist.avatar} 
                    alt={activePortfolioArtist.name} 
                    className="w-10 h-10 rounded-xl object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-extrabold text-white text-sm">
                      {activePortfolioArtist.name} • Lab Notebook Sketches
                    </h3>
                    <p className="text-xs text-slate-400">Real pencil hand-shading examples drafted for active secondary board grading.</p>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    setActivePortfolioArtist(null);
                    setActiveSampleIndex(null);
                  }}
                  className="w-8 h-8 rounded-full border border-white/10 bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center text-xs font-bold transition-all cursor-pointer hover:border-slate-700"
                >
                  ✕
                </button>
              </div>

              {/* Grid of sample drawings */}
              <div className="grid grid-cols-2 gap-4">
                {activePortfolioArtist.samples.map((samplePath, i) => {
                  const isOwnerOrAdmin = user && (user.id === activePortfolioArtist.id || user.role === 'admin');
                  return (
                    <div 
                      key={i} 
                      onClick={() => setActiveSampleIndex(i)}
                      className="group relative h-44 rounded-2xl overflow-hidden border border-white/5 cursor-pointer bg-slate-950 hover:border-amber-500/45 transition-all shadow-md"
                    >
                      <img 
                        src={samplePath} 
                        alt="STEM Drawing Sample" 
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all flex items-end p-3 justify-between">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                          Maximize View
                        </span>
                        <div className="flex items-center gap-2">
                          {isOwnerOrAdmin && (
                            <button
                              type="button"
                              onClick={async (e) => {
                                e.stopPropagation(); // Avoid maximizing
                                if (window.confirm("Are you sure you want to permanently remove this drawing sample?")) {
                                  const updatedSamples = activePortfolioArtist.samples.filter((_, idx) => idx !== i);
                                  try {
                                    const url = user.role === 'admin' 
                                      ? `/api/admin/artists/${activePortfolioArtist.id}/samples` 
                                      : '/api/artists/profile';
                                    const res = await apiFetch(url, {
                                      method: 'PUT',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ samples: updatedSamples })
                                    });
                                    if (res.ok) {
                                      triggerAlert('success', 'Drawing sample successfully removed.');
                                      setActivePortfolioArtist({
                                        ...activePortfolioArtist,
                                        samples: updatedSamples
                                      });
                                      loadInitialData();
                                    } else {
                                      triggerAlert('error', 'Failed to update portfolio samples.');
                                    }
                                  } catch (_) {
                                    triggerAlert('error', 'Network failure.');
                                  }
                                }
                              }}
                              className="p-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white cursor-pointer transition-all hover:scale-110"
                              title="Delete this sample"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-white" />
                            </button>
                          )}
                          <Eye className="w-4 h-4 text-amber-400" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Sample illustrative prompts suggestions inside lightbox */}
              <div className="p-4 rounded-2xl bg-indigo-950/15 border border-indigo-400/10 space-y-1">
                <span className="text-[9px] font-mono uppercase font-bold text-indigo-400 tracking-wider">💡 Common Board drawing guidelines</span>
                <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                  These diagrams represent true submissions: note the clean continuous outline borders, centered diagram classifications, fully balanced labels mapped via right-aligned parallel leader lines, and proper page margin configurations.
                </p>
              </div>

              {activeSampleIndex !== null && (
                <div className="fixed inset-0 z-[1001] bg-slate-950/95 flex flex-col items-center justify-center p-4 animate-in fade-in">
                  <button 
                    onClick={() => setActiveSampleIndex(null)}
                    className="absolute top-6 right-6 px-4 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs font-mono font-bold cursor-pointer transition-all hover:bg-slate-850"
                  >
                    Close Image [ESC]
                  </button>
                  <img 
                    src={activePortfolioArtist.samples[activeSampleIndex]} 
                    alt="Maximised STEM sketch" 
                    className="max-w-full max-h-[80vh] object-contain rounded-xl shadow-2xl border border-white/5"
                    referrerPolicy="no-referrer"
                  />
                  <div className="mt-4 flex items-center gap-4 text-xs font-mono">
                    <button
                      disabled={activeSampleIndex === 0}
                      onClick={() => setActiveSampleIndex(activeSampleIndex - 1)}
                      className="px-3 py-1.5 bg-slate-900 rounded border border-white/10 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition-all"
                    >
                      ← Previous
                    </button>
                    <span className="text-slate-400 font-bold">Drawing {activeSampleIndex + 1} of {activePortfolioArtist.samples.length}</span>
                    <button
                      disabled={activeSampleIndex === activePortfolioArtist.samples.length - 1}
                      onClick={() => setActiveSampleIndex(activeSampleIndex + 1)}
                      className="px-3 py-1.5 bg-slate-900 rounded border border-white/10 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition-all"
                    >
                      Next →
                    </button>
                  </div>
                </div>
              )}

              <p className="text-[9px] text-slate-550 font-mono text-center pt-2">
                All uploaded student content is certified by Professor Akash's council for physical portfolio submissions.
              </p>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          MODAL 2: FORM SHEET MODAL - HIRE SELECTED ARTIST
          ========================================================================= */}
      <AnimatePresence>
        {selectedArtistToHire && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg rounded-3xl border border-white/[0.08] bg-slate-900 p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <h3 className="font-black text-white text-lg tracking-tight uppercase font-sans">Commission Drawing Plate</h3>
                  <p className="text-xs text-slate-400">Formulate precise guidelines for {selectedArtistToHire.name}.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedArtistToHire(null)}
                  className="w-8 h-8 rounded-full border border-white/10 bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/10 flex items-center justify-between shadow-md">
                <div className="flex items-center gap-3">
                  <img 
                    src={selectedArtistToHire.avatar} 
                    alt={selectedArtistToHire.name} 
                    className="w-11 h-11 rounded-xl object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="font-extrabold text-white text-xs">{selectedArtistToHire.name}</h4>
                    <span className="text-[10px] text-slate-400 block pt-0.5">Specialist in {selectedArtistToHire.specialties[0] || 'Diagrams'}</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <span className="text-[8px] text-slate-550 block uppercase font-mono font-bold">Plate Rate</span>
                  <strong className="text-amber-400 font-mono text-sm">৳{selectedArtistToHire.ratePerDrawing} BDT</strong>
                </div>
              </div>

              <form onSubmit={handleHireSubmit} className="space-y-4 text-xs font-sans">
                
                <div className="space-y-1.5">
                  <label className="text-[9px] text-slate-400 block uppercase font-mono font-bold pl-1">Experiment title as written in syllabus</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Refraction Index index of water using traveling microscope"
                    value={hirePracticalTitle}
                    onChange={(e) => setHirePracticalTitle(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs focus:outline-none focus:border-amber-500 transition-all font-sans"
                  />
                </div>

                <div className="space-y-1.5 p-3 rounded-2xl bg-amber-500/[0.02] border border-amber-500/10">
                  <div className="flex justify-between items-center">
                    <label className="text-[9px] text-[#fbbf24] block uppercase font-mono font-bold pl-1">🔑 Verification phone number</label>
                    <span className="text-[8px] bg-amber-500/10 text-amber-300 font-mono font-bold px-1 rounded">Mandatory for Middleman cash supervision</span>
                  </div>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 017XXXXXXXX (Must provide real contact format so artist can reach you)"
                    value={hireStudentPhone}
                    onChange={(e) => setHireStudentPhone(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-amber-500/20 text-slate-200 text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/20 transition-all font-sans"
                  />
                  <p className="text-[9px] text-slate-550 pl-1 leading-normal italic font-mono uppercase tracking-[0.02em]">
                    Supervisor Mahabub Rahman Akash secures your cash until final hand-shaded sheet delivery.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] text-slate-400 block uppercase font-mono font-bold pl-1">Experiment Subject</label>
                    <select
                      value={hireSubject}
                      onChange={(e) => setHireSubject(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-white/10 text-slate-350 text-xs focus:outline-none focus:border-indigo-600 transition-all cursor-pointer font-medium"
                    >
                      <option value="Physics">Physics</option>
                      <option value="Biology">Biology</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] text-slate-500 block uppercase font-mono font-bold pl-1">Expected completion delivery</label>
                    <span className="block pt-2 font-mono text-slate-300 font-bold text-xs">Within 48 hours guaranteed</span>
                  </div>
                </div>

                {/* Physical Practical Notebook Provider Option */}
                <div className="p-3.5 bg-slate-950 rounded-2xl border border-white/5 space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-[9px] text-[#fbbf24] block uppercase font-mono font-bold pl-1">📚 Physical Practical Notebook</label>
                    <span className="text-[8px] bg-indigo-500/10 text-indigo-300 font-mono font-bold px-1 rounded">Notebook Option</span>
                  </div>
                  <p className="text-[10.5px] text-slate-400 leading-normal pl-1">
                    Science practical notebook drawings are physical. Choose how the book is supplied:
                  </p>
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setHireNotebookProvider('student')}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        hireNotebookProvider === 'student'
                          ? 'border-indigo-500 bg-indigo-500/[0.04] text-white font-semibold'
                          : 'border-white/[0.03] bg-slate-900/40 text-slate-400 hover:border-white/10 hover:text-slate-350'
                      }`}
                    >
                      <span className="block text-[11px] font-bold font-sans">I will provide book</span>
                      <span className="block text-[8px] font-mono uppercase mt-1 opacity-60 leading-normal">
                        I will deliver my physical book to the drawing specialist
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setHireNotebookProvider('artist')}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        hireNotebookProvider === 'artist'
                          ? 'border-indigo-500 bg-indigo-500/[0.04] text-white font-semibold'
                          : 'border-white/[0.03] bg-slate-900/40 text-slate-400 hover:border-white/10 hover:text-slate-355'
                      }`}
                    >
                      <span className="block text-[11px] font-bold font-sans">Artist provides book</span>
                      <span className="block text-[8px] font-mono uppercase mt-1 opacity-60 leading-normal">
                        Artist will purchase a new physical book on my behalf
                      </span>
                    </button>
                  </div>
                </div>

                {/* Gazi Publications Biology Practical Selector */}
                {hireSubject === 'Biology' && (
                  <div className="p-3.5 bg-slate-950 rounded-2xl border border-white/5 space-y-3 animate-in fade-in slide-in-from-top-1 duration-200">
                    <div className="flex items-center justify-between border-b border-white/5 pb-2">
                      <span className="text-[10px] font-bold text-amber-400 font-mono tracking-wider uppercase">Gazi Publications Selector (Beboharik Jib Biggan)</span>
                      <span className="text-[9px] text-slate-500 font-mono font-bold">1st & 2nd Paper</span>
                    </div>

                    {/* Selector Tabs */}
                    <div className="flex gap-1.5 bg-slate-900 p-1 rounded-xl">
                      <button
                        type="button"
                        onClick={() => setBiologyPaperTab('1st')}
                        className={`flex-1 py-1.5 text-[10px] font-black uppercase font-mono tracking-wide rounded-lg transition-all cursor-pointer ${
                          biologyPaperTab === '1st' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        1st Paper (Botany)
                      </button>
                      <button
                        type="button"
                        onClick={() => setBiologyPaperTab('2nd')}
                        className={`flex-1 py-1.5 text-[10px] font-black uppercase font-mono tracking-wide rounded-lg transition-all cursor-pointer ${
                          biologyPaperTab === '2nd' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        2nd Paper (Zoology)
                      </button>
                    </div>

                    {/* Scrollable list of practicals */}
                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                      {gaziBiologyPracticals
                        .filter(p => biologyPaperTab === '1st' ? p.id.startsWith('bot') : p.id.startsWith('zoo'))
                        .map(p => {
                          const isSelected = hirePracticalTitle === `${p.paper}: ${p.engTitle}`;
                          return (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => setHirePracticalTitle(`${p.paper}: ${p.engTitle}`)}
                              className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                                isSelected 
                                  ? 'border-amber-500 bg-amber-500/[0.04] text-white font-semibold shadow-inner' 
                                  : 'border-white/[0.03] bg-slate-900/60 hover:bg-slate-900 hover:border-white/10 text-slate-300'
                              }`}
                            >
                              <span className="text-[11px] font-medium leading-relaxed text-slate-100">{p.title}</span>
                              <span className="text-[9.5px] text-slate-500 font-mono tracking-tight">{p.engTitle}</span>
                            </button>
                          );
                        })}
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="text-[9px] text-slate-400 block uppercase font-mono font-bold pl-1">Syllabus guideline, shading demand, or specific labels</label>
                  <textarea
                    placeholder="e.g. Please highlight the path of incident light through glass block with clean parallel line arrows."
                    value={hireNotes}
                    onChange={(e) => setHireNotes(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-white/10 text-slate-200 text-xs leading-relaxed resize-none focus:outline-none focus:border-amber-500 transition-all"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/10 tracking-widest uppercase"
                >
                  Confirm and Commission Solved Homework
                </button>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          MODAL 3: INVOICE MODAL (PRINTABLE)
          ========================================================================= */}
      <AnimatePresence>
        {activeInvoiceBooking && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md no-print">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl rounded-3xl border border-white/[0.08] bg-slate-900 p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto print-invoice-container"
            >
              {/* Header and Close button (will be hidden on print via media queries) */}
              <div className="flex items-center justify-between border-b border-white/10 pb-4 no-print">
                <div className="space-y-0.5">
                  <span className="font-mono text-xs uppercase font-extrabold text-indigo-400">Official Academy Escrow Ledger</span>
                  <h2 className="text-sm font-sans font-black text-white">TAX INVOICE & COMMISSION RECEIPT</h2>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-[10px] font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-950/40"
                  >
                    <Printer className="w-3.5 h-3.5 text-white" />
                    <span>Print Invoice</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveInvoiceBooking(null)}
                    className="w-8 h-8 rounded-full border border-white/10 bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center text-xs font-bold cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Real Invoice Layout - Optimized for Print styling */}
              <div className="space-y-6 text-left text-slate-200">
                
                {/* Academy Logo Header Row */}
                <div className="flex justify-between items-start gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-xl font-bold font-sans tracking-tight text-white print:text-black">
                      HSC STEM DRAWING ACADEMY
                    </h1>
                    <p className="text-[10px] text-slate-400 font-mono print:text-slate-600 mt-1 uppercase">
                      Dhaka, Bangladesh • Dhaka Board Syllabus Standards
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-2.5 py-1 rounded bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-mono text-indigo-400 font-bold print:border-black print:text-black">
                      {activeInvoiceBooking.invoiceId || `INV-${activeInvoiceBooking.id}`}
                    </span>
                    <p className="text-[10px] text-slate-500 font-mono mt-1">INVOICE NO.</p>
                  </div>
                </div>

                {/* Grid for Customer and Provider */}
                <div className="grid grid-cols-2 gap-6 text-xs font-sans">
                  <div className="p-4 rounded-xl bg-slate-950/40 border border-white/5 print:bg-white print:text-black print:border-slate-300">
                    <span className="block text-[9px] text-indigo-400 font-mono uppercase font-black tracking-widest mb-2">BILLED TO (STUDENT)</span>
                    <div className="space-y-1">
                      <p className="font-extrabold text-white print:text-black">{activeInvoiceBooking.studentName || 'Academy Member'}</p>
                      <p className="text-slate-400 font-mono text-[10.5px] print:text-slate-700">{activeInvoiceBooking.studentEmail || 'Registered Email'}</p>
                      <p className="text-slate-400 font-mono text-[10.5px] print:text-slate-700">Phone: {activeInvoiceBooking.studentPhone || 'N/A'}</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/40 border border-white/5 print:bg-white print:text-black print:border-slate-300">
                    <span className="block text-[9px] text-amber-500 font-mono uppercase font-black tracking-widest mb-2">DRAWING CREATOR</span>
                    <div className="space-y-1">
                      <p className="font-extrabold text-white print:text-black">{activeInvoiceBooking.artistName}</p>
                      <p className="text-slate-400 font-mono text-[10.5px] print:text-slate-700">HSC Practical Shading Specialist</p>
                      <p className="text-slate-400 font-mono text-[10.5px] print:text-slate-700">Role: Certified Freelancer</p>
                    </div>
                  </div>
                </div>

                {/* Timestamps */}
                <div className="grid grid-cols-2 gap-4 text-[10.5px] font-mono p-3 bg-slate-900/50 border border-white/[0.03] rounded-xl print:border-slate-300 print:bg-white print:text-black">
                  <div>
                    <span className="text-slate-500 block text-[8px] uppercase font-bold">Order Placement Time</span>
                    <span className="text-slate-200 print:text-black">
                      {activeInvoiceBooking.createdAt ? new Date(activeInvoiceBooking.createdAt).toLocaleString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      }) : 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[8px] uppercase font-bold">Admin Escrow Payment Approval</span>
                    <span className="text-emerald-400 font-bold print:text-black">
                      {activeInvoiceBooking.paymentApprovedAt ? new Date(activeInvoiceBooking.paymentApprovedAt).toLocaleString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      }) : (
                        <span className="text-amber-500 font-bold uppercase tracking-wider print:text-slate-600">Pending Authorization</span>
                      )}
                    </span>
                  </div>
                </div>

                {/* Line Items Table */}
                <div className="border border-white/5 rounded-xl overflow-hidden print:border-slate-300">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-950 text-[10px] font-mono text-slate-400 uppercase tracking-wider print:bg-slate-100 print:text-black print:border-b print:border-slate-300">
                        <th className="p-3.5 font-bold">Subject / Syllabus Item</th>
                        <th className="p-3.5 font-bold">Notebook Provider</th>
                        <th className="p-3.5 font-bold text-right">Price per sheet</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.02] font-sans print:divide-slate-200">
                      <tr className="print:text-black">
                        <td className="p-3.5">
                          <p className="font-extrabold text-slate-100 print:text-black">{activeInvoiceBooking.practicalTitle}</p>
                          <span className="text-[9px] font-mono text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded uppercase font-bold mt-1 inline-block print:text-black print:border print:border-slate-300">
                            {activeInvoiceBooking.subject}
                          </span>
                        </td>
                        <td className="p-3.5 font-mono text-[11px] text-slate-300 print:text-black">
                          {activeInvoiceBooking.notebookProvider === 'artist' ? 'Artist Purchased Book' : 'Student Hand-delivered'}
                        </td>
                        <td className="p-3.5 font-mono text-right font-extrabold text-slate-100 print:text-black">
                          ৳{activeInvoiceBooking.price} BDT
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Calculation breakdown */}
                <div className="flex justify-end font-sans">
                  <div className="w-64 space-y-2 p-4 rounded-xl bg-slate-950/40 border border-white/5 print:bg-white print:border-slate-300 print:text-black">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Subtotal:</span>
                      <span className="font-mono text-slate-300 print:text-black">৳{activeInvoiceBooking.price} BDT</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Platform Escrow Fee (0%):</span>
                      <span className="font-mono text-emerald-400 font-bold print:text-black">৳0 BDT</span>
                    </div>
                    <div className="flex justify-between text-sm border-t border-white/5 pt-2 font-extrabold print:border-slate-300 print:text-black">
                      <span>Total Amount:</span>
                      <span className="font-mono text-amber-400 print:text-black">৳{activeInvoiceBooking.price} BDT</span>
                    </div>
                  </div>
                </div>

                {/* Ledger Stamps */}
                <div className="flex items-center justify-between pt-6 border-t border-slate-800 print:border-slate-300">
                  <div className="space-y-1">
                    <span className="text-[8.5px] font-mono text-slate-500 block uppercase font-bold">Ledger Classification</span>
                    <span className={`inline-block px-3 py-1 rounded text-[10px] font-mono tracking-widest font-extrabold uppercase ${
                      activeInvoiceBooking.paymentStatus === 'paid'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                        : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                    }`}>
                      {activeInvoiceBooking.paymentStatus === 'paid' ? '✓ ESCROW RELEASED' : '⚡ ESCROW PENDING RELEASE'}
                    </span>
                  </div>

                  <div className="text-right space-y-1 print:text-black">
                    <p className="text-[10px] font-mono italic text-slate-400 print:text-slate-700">Digital certified ledger of HSC STEM Drawing Hub.</p>
                    <p className="text-[9px] font-mono text-indigo-400 uppercase tracking-wider font-bold">Released to student for practical notebook submission.</p>
                  </div>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
