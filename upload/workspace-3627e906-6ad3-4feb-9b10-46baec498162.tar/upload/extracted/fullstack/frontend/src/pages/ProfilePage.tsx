import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Sparkles, 
  Save, 
  Image as ImageIcon, 
  CheckCircle, 
  AlertCircle,
  Loader2,
  Lock,
  Upload,
  Clock,
  BookOpen,
  Check,
  FileCheck,
  Phone,
  Coins,
  Palette,
  Sliders,
  Trash2,
  AlertTriangle,
  Award,
  ChevronRight,
  ShieldCheck,
  CheckSquare,
  Key
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { user, apiFetch, setUser, updateSession, geminiApiKey, setIsKeyModalOpen } = useAuth();
  
  // Base states
  const [name, setName] = useState<string>('');
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [profilePic, setProfilePic] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const [uploading, setUploading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  
  // Artist-specific states
  const [bio, setBio] = useState<string>('');
  const [ratePerDrawing, setRatePerDrawing] = useState<number>(150);
  const [specialties, setSpecialties] = useState<string[]>([]);
  const [isAvailable, setIsAvailable] = useState<boolean>(true);
  const [samples, setSamples] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState<string>('');
  const [uploadingSample, setUploadingSample] = useState<boolean>(false);

  // References
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sampleInputRef = useRef<HTMLInputElement>(null);

  // Initialize values when user state is resolved
  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setPhoneNumber(user.phoneNumber || '');
      setProfilePic(user.profilePic || '');
      setBio((user as any).bio || '');
      setRatePerDrawing((user as any).ratePerDrawing || 150);
      setSpecialties((user as any).specialties || []);
      setIsAvailable((user as any).isAvailable !== false);
      setSamples((user as any).samples || []);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="h-full flex items-center justify-center p-6 text-slate-400 font-mono text-xs">
        No active user session resolved. Please log in.
      </div>
    );
  }

  // Preseeded avatar presets 
  const avatarPresets = [
    { name: "Neon Cypher", url: "https://api.dicebear.com/7.x/bottts/svg?seed=cypher&backgroundColor=1e1b4b" },
    { name: "Star Scholar", url: "https://api.dicebear.com/7.x/identicon/svg?seed=scholar&backgroundColor=020617" },
    { name: "Quantum Mind", url: "https://api.dicebear.com/7.x/shapes/svg?seed=quantum&backgroundColor=0d1117" },
    { name: "Astral Sage", url: "https://api.dicebear.com/7.x/pixel-art/svg?seed=astral&backgroundColor=111827" },
    { name: "Prism Core", url: "https://api.dicebear.com/7.x/initials/svg?seed=" + encodeURIComponent(user.name || 'Member') + "&backgroundColor=4f46e5" },
    { name: "Cyber Spark", url: "https://api.dicebear.com/7.x/rings/svg?seed=cyber&backgroundColor=0f172a" },
  ];

  // Helper file upload for Profile Portrait
  const handleDeviceFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!validTypes.includes(file.type)) {
      setStatusMessage({ type: 'error', text: 'Forbidden file stream. Image files (JPEG, PNG, WEBP, GIF) are necessary.' });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setStatusMessage({ type: 'error', text: 'Payload overflow. File sizes are capped at 5 megabytes.' });
      return;
    }

    setUploading(true);
    setStatusMessage(null);

    const formData = new FormData();
    formData.append('image', file);

    try {
      const res = await apiFetch('/api/images/upload-file', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        const data = await res.json();
        if (data.url) {
          setProfilePic(data.url);
          setStatusMessage({ type: 'success', text: `Device file '${file.name}' uploaded successfully! Save and apply changes below.` });
        } else {
          setStatusMessage({ type: 'error', text: 'Host rejected upload context mapping.' });
        }
      } else {
        const err = await res.json().catch(() => ({}));
        setStatusMessage({ type: 'error', text: err.error || 'Identity cluster failed to ingest selected file.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Upload connection failed: ${err.message || err}` });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Direct portfolio artwork upload & instant save
  const handlePortfolioDrawingUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!validTypes.includes(file.type)) {
      setStatusMessage({ type: 'error', text: 'Please upload valid diagram formats (JPEG, PNG, WEBP, GIF).' });
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setStatusMessage({ type: 'error', text: 'Limit exceeded: Diagram uploads are capped at 8MB.' });
      return;
    }

    setUploadingSample(true);
    setStatusMessage(null);

    const formData = new FormData();
    formData.append('image', file);

    try {
      const uploadRes = await apiFetch('/api/images/upload-file', {
        method: 'POST',
        body: formData,
      });

      if (uploadRes.ok) {
        const data = await uploadRes.json();
        if (data.url) {
          const updatedSamples = [...samples, data.url];
          
          // Instantly persist into the artist profile database list
          const updateRes = await apiFetch('/api/users/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name,
              profilePic,
              phoneNumber,
              specialties,
              bio,
              ratePerDrawing,
              isAvailable,
              samples: updatedSamples
            })
          });

          if (updateRes.ok) {
            const updateData = await updateRes.json();
            setSamples(updatedSamples);
            if (updateData.token) {
              updateSession(updateData.token, updateData.user);
            } else {
              setUser(updateData.user);
            }
            setStatusMessage({ type: 'success', text: `Specimen '${file.name}' added perfectly to your visual showcase!` });
          } else {
            setStatusMessage({ type: 'error', text: 'Identity ledger rejected updating portfolio samples list.' });
          }
        }
      } else {
        const err = await uploadRes.json().catch(() => ({}));
        setStatusMessage({ type: 'error', text: err.error || 'Server rejected diagram payload upload.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Network exception during showcase upload: ${err.message}` });
    } finally {
      setUploadingSample(false);
      if (sampleInputRef.current) {
        sampleInputRef.current.value = '';
      }
    }
  };

  // Remove sample drawing with instant save
  const handleRemovePortfolioDrawing = async (indexToRemove: number) => {
    const updatedSamples = samples.filter((_, idx) => idx !== indexToRemove);
    setStatusMessage(null);

    try {
      const updateRes = await apiFetch('/api/users/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          profilePic,
          phoneNumber,
          specialties,
          bio,
          ratePerDrawing,
          isAvailable,
          samples: updatedSamples
        })
      });

      if (updateRes.ok) {
        const updateData = await updateRes.json();
        setSamples(updatedSamples);
        if (updateData.token) {
          updateSession(updateData.token, updateData.user);
        } else {
          setUser(updateData.user);
        }
        setStatusMessage({ type: 'success', text: 'Portfolio diagram removed successfully from your live showcase.' });
      } else {
        setStatusMessage({ type: 'error', text: 'Identity records failed to clear drawing target.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Deletion exception: ${err.message}` });
    }
  };

  // Profile Save submit handler
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setStatusMessage({ type: 'error', text: 'Display Name cannot be left blank.' });
      return;
    }

    setSaving(true);
    setStatusMessage(null);

    try {
      const res = await apiFetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: name.trim(),
          profilePic: profilePic.trim(),
          phoneNumber: phoneNumber.trim(),
          // Artist fields passed (will be safely ignored if not an artist on the server)
          specialties,
          bio,
          ratePerDrawing,
          isAvailable,
          samples
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.token) {
          updateSession(data.token, data.user);
        } else {
          setUser(data.user);
        }
        setStatusMessage({ type: 'success', text: 'Your core identity settings, portfolios, and rates were applied live!' });
      } else {
        const err = await res.json().catch(() => ({}));
        setStatusMessage({ type: 'error', text: err.error || 'Server rejected profile ledger update.' });
      }
    } catch (e: any) {
      setStatusMessage({ type: 'error', text: `Synchronization failed: ${e.message || e}` });
    } finally {
      setSaving(false);
    }
  };

  // Specialties Tag Actions
  const handleAddSpecialtyTag = () => {
    if (newTagInput.trim() && !specialties.includes(newTagInput.trim())) {
      setSpecialties([...specialties, newTagInput.trim()]);
      setNewTagInput('');
    }
  };

  const handleRemoveSpecialtyTag = (index: number) => {
    setSpecialties(specialties.filter((_, i) => i !== index));
  };

  const formattedStudyHrs = (user.studyTime / 3600).toFixed(1);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="p-1 sm:p-4 md:p-6 max-w-6xl mx-auto space-y-6 text-slate-100 pb-16 min-w-0 overflow-x-hidden"
    >
      {/* 1. Dynamic Header Banner based on Role (Unique & Stylish) */}
      <div className="relative p-6 md:p-8 rounded-3xl border border-white/5 bg-gradient-to-r from-slate-950 via-[#090e1a] to-slate-950 overflow-hidden shadow-2xl">
        <div className="absolute top-[-50%] right-[-10%] w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-30%] left-[-10%] w-80 h-80 bg-amber-500/5 blur-[100px] rounded-full pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-black tracking-widest uppercase font-mono border ${
                user.role === 'artist' 
                  ? 'text-amber-400 bg-amber-400/10 border-amber-500/25' 
                  : 'text-[#a5b4fc] bg-indigo-500/10 border-indigo-500/25'
              }`}>
                {user.role === 'artist' ? '🎨 Professional Illustrator Hub' : '🎓 Student Academy Hub'}
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-[10px] text-emerald-400 font-mono tracking-widest font-bold flex items-center gap-1">
                ● LIVE CREDENTIALS OK
              </span>
            </div>
            
            <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight text-white font-sans flex items-center gap-3">
              {user.role === 'artist' ? (
                <>
                  <Palette className="w-8 h-8 text-amber-400" />
                  My Professional Studio Profile
                </>
              ) : (
                <>
                  <User className="w-8 h-8 text-indigo-400" />
                  Manage Academy Profile
                </>
              )}
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              {user.role === 'artist' 
                ? "Adjust your biology and physics diagram prices, update your profile credentials, and manage your custom portfolio gallery sketches to hire more academy students."
                : "Customize your academic display name, contact phone number, and avatar illustration. Updates automatically sync with school discussion boards, classes, and commissions."}
            </p>
          </div>

          {/* Gemini API Key Co-Pilot Status */}
          {user.role !== 'artist' && (
            <div className="w-full md:w-auto p-4 bg-slate-900/80 rounded-2xl border border-indigo-500/20 shadow-xl">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3.5 min-w-0">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                    geminiApiKey ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                  }`}>
                    <Key className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] uppercase tracking-widest font-mono text-slate-400 font-bold">Google Gemini API</span>
                      {geminiApiKey ? (
                        <span className="bg-emerald-500/20 text-emerald-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-emerald-400/30 whitespace-nowrap">Active</span>
                      ) : (
                        <span className="bg-indigo-500/20 text-indigo-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-indigo-400/30 whitespace-nowrap">Free Co-Pilot</span>
                      )}
                    </div>
                    <span className="text-sm font-extrabold text-white font-sans block mt-0.5 whitespace-nowrap">
                      {geminiApiKey ? 'Personal Key Active' : 'Bring Your Own Key'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsKeyModalOpen(true)}
                  className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Key className="w-3.5 h-3.5" />
                  {geminiApiKey ? 'Manage Key' : 'Add Key'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 2. Success or Error Status Notice */}
      <AnimatePresence>
        {statusMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className={`p-4 rounded-2xl border flex items-start gap-3 text-xs md:text-sm shadow-xl ${
              statusMessage.type === 'success' 
                ? 'bg-emerald-950/30 border-emerald-500/20 text-emerald-300' 
                : 'bg-rose-950/30 border-rose-500/20 text-rose-300'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckSquare className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-450 shrink-0 mt-0.5" />
            )}
            <div className="space-y-0.5 flex-1">
              <span className="font-bold block">
                {statusMessage.type === 'success' ? 'Modification successful' : 'Operation rejected'}
              </span>
              <span className="text-slate-400 text-xs leading-relaxed block">{statusMessage.text}</span>
            </div>
            <button 
              onClick={() => setStatusMessage(null)}
              className="text-slate-500 hover:text-white text-xs font-bold px-2"
            >
              ×
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* =========================================================================
            LEFT COLUMN: ANALYTICS & IDENTITY CARD 
            ========================================================================= */}
        <div className="space-y-6 lg:col-span-1">
          {/* Identity Card */}
          <div className="p-6 rounded-3xl border border-white/5 bg-[#070b15]/60 backdrop-blur-xl space-y-6 text-center flex flex-col items-center justify-center shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-3xl rounded-full pointer-events-none" />
            
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500 self-start font-mono">
              {user.role === 'artist' ? 'Studio Pass' : 'Academic Card'}
            </h3>
            
            {/* Visual Portrait */}
            <div className="relative">
              <div className={`absolute -inset-2 rounded-full opacity-25 blur ${
                user.role === 'artist' 
                  ? 'bg-gradient-to-tr from-amber-500 via-orange-400 to-indigo-500' 
                  : 'bg-gradient-to-tr from-indigo-500 via-purple-500 to-amber-450'
              }`} />
              
              {profilePic ? (
                <img 
                  src={profilePic} 
                  alt="Avatar Portrait" 
                  referrerPolicy="no-referrer"
                  className="relative w-28 h-28 rounded-2xl border border-white/10 object-cover bg-slate-900 shadow-xl"
                />
              ) : (
                <div className="relative w-28 h-28 rounded-2xl border border-white/10 bg-slate-900 flex items-center justify-center text-slate-450 text-3xl font-black uppercase font-mono shadow-xl animate-pulse">
                  {name ? name.substring(0, 1) : 'S'}
                </div>
              )}
            </div>

            <div className="space-y-2 w-full">
              <h2 className="text-lg font-black text-slate-100 truncate tracking-tight font-sans">
                {name || "Anonymous member"}
              </h2>
              <div className="px-3 py-1 rounded-full bg-slate-950 border border-white/5 text-[10px] text-slate-400 font-mono inline-block max-w-[240px] truncate select-all">
                {user.email}
              </div>
            </div>

            <div className="w-full pt-4 border-t border-white/[0.04] space-y-3.5 text-left text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Role Status:</span>
                <span className={`px-2.5 py-0.5 rounded text-[9px] font-black uppercase flex items-center gap-1 ${
                  user.role === 'artist'
                    ? 'bg-amber-450/15 text-amber-300 border border-amber-500/20'
                    : user.role === 'admin'
                    ? 'bg-purple-500/15 text-purple-300 border border-purple-500/20'
                    : 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/20'
                }`}>
                  {user.role} {user.isAdminStudent ? "(Faculty)" : ""}
                </span>
              </div>

              {phoneNumber && (
                <div className="flex items-center justify-between font-mono">
                  <span className="text-slate-500 font-sans">Contact Mobile:</span>
                  <span className="text-slate-300 font-bold">{phoneNumber}</span>
                </div>
              )}

              {user.role === 'artist' && (
                <>
                  <div className="flex items-center justify-between font-mono">
                    <span className="text-slate-500 font-sans">Plate Rate:</span>
                    <span className="text-amber-400 font-bold">৳{ratePerDrawing} BDT</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Availability:</span>
                    <span className={`text-[10px] font-bold ${isAvailable ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isAvailable ? '● Accepting Hires' : '● Inactive/Busy'}
                    </span>
                  </div>
                </>
              )}

              <div className="text-[11px] text-slate-500 leading-relaxed pt-2 border-t border-white/[0.04]">
                {user.role === 'artist' 
                  ? '🎨 Registered Physical Drawing Professional. You provide physical booklet sketches on-demand to scholars.'
                  : user.role === 'admin'
                  ? '🛡️ System Administrator credentials resolved. Full bypass limits and portal monitoring privileges.'
                  : '📓 Standard Science Cadet. Allowed to commission hand-shaded sheets, join research chats, and ask AI Academy tools.'}
              </div>
            </div>
          </div>

          {/* Stat Box based on Role */}
          {user.role === 'artist' ? (
            <div className="p-6 rounded-3xl border border-white/5 bg-[#070b15]/40 backdrop-blur-xl space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#fbbf24] font-mono flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" /> Professional Credentials
              </h4>
              <div className="grid grid-cols-2 gap-3.5 text-center">
                <div className="p-3 bg-white/[0.02] border border-white/[0.04] rounded-2xl">
                  <span className="text-[9px] uppercase font-bold text-slate-500 block">Completed</span>
                  <span className="text-base font-black text-slate-200 mt-1 block font-mono">
                    {(user as any).completedCount || 0} drawings
                  </span>
                </div>
                <div className="p-3 bg-white/[0.02] border border-white/[0.04] rounded-2xl">
                  <span className="text-[9px] uppercase font-bold text-slate-500 block">Client review</span>
                  <span className="text-base font-black text-indigo-300 mt-1 block font-mono">
                    {((user as any).rating || 5.0).toFixed(1)} / 5.0
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 rounded-3xl border border-white/5 bg-[#070b15]/40 backdrop-blur-xl space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#a5b4fc] font-mono flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-indigo-400" /> Learning Analytics
              </h4>
              <div className="p-4 bg-white/[0.01] border border-white/[0.03] rounded-2xl text-center">
                <span className="text-[9px] uppercase font-sans font-bold text-slate-500 block">Total Study Duration</span>
                <span className="text-xl font-black text-slate-200 block font-mono mt-1.5 flex items-center justify-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  {formattedStudyHrs}<span className="text-xs text-slate-500 font-normal">hours</span>
                </span>
              </div>
            </div>
          )}
        </div>

        {/* =========================================================================
            RIGHT COLUMN: EXTENSIVE RECORD FORM
            ========================================================================= */}
        <div className="lg:col-span-2 space-y-8">
          <form onSubmit={handleUpdateProfile} className="p-6 md:p-8 rounded-3xl border border-white/5 bg-[#070b15]/50 backdrop-blur-xl space-y-6">
            
            <div className="flex items-center justify-between border-b border-white/[0.04] pb-4">
              <h3 className="text-base font-bold text-slate-200 font-sans tracking-tight">
                {user.role === 'artist' ? 'Update Drawing Studio Settings' : 'Edit Profile & Avatar Settings'}
              </h3>
              <span className={`text-[9px] px-2.5 py-0.5 font-bold uppercase tracking-wider rounded font-mono ${
                user.role === 'artist' ? 'text-amber-300 bg-amber-500/10 border-amber-500/20' : 'text-indigo-300 bg-indigo-500/10 border-indigo-500/20'
              }`}>
                {user.role === 'artist' ? 'ARTIST IDENTITY' : 'STUDENT PROFILE'}
              </span>
            </div>

            {/* Profile Avatar Upload with verified support */}
            <div className="space-y-3">
              <label className="text-[11px] uppercase tracking-widest text-slate-400 font-mono font-bold block">
                Profile Portrait Avatar
              </label>

              <div className="p-5 rounded-2xl bg-slate-950/60 border border-white/5 flex flex-col sm:flex-row items-center gap-6">
                {/* Instant preview with camera hover overlay */}
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="relative w-20 h-20 rounded-full bg-slate-900 border border-dashed border-white/20 hover:border-amber-400/50 flex items-center justify-center cursor-pointer overflow-hidden group shrink-0 transition-all duration-300"
                >
                  {profilePic ? (
                    <img 
                      src={profilePic}
                      alt="Avatar Portrait circle" 
                      className="w-full h-full object-cover group-hover:opacity-30 transition-opacity"
                    />
                  ) : (
                    <User className="w-10 h-10 text-slate-655" />
                  )}
                  {/* Hover Upload Overlay */}
                  <div className="absolute inset-0 bg-slate-950/85 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Upload className="w-4 h-4 text-amber-450 animate-bounce" />
                    <span className="text-[7.5px] font-bold text-white uppercase mt-1 tracking-wider">Upload</span>
                  </div>
                </div>

                <div className="flex-1 space-y-2 text-center sm:text-left">
                  <h4 className="text-xs font-bold text-slate-200">Upload portrait block</h4>
                  <p className="text-[11px] text-slate-450 leading-relaxed">
                    Click the bubble preview or use the picker below. JPEG, PNG, WEBP, and GIF up to 5MB supported.
                  </p>
                  
                  <div className="flex flex-wrap justify-center sm:justify-start gap-2.5 pt-1">
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      onChange={handleDeviceFileUpload}
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={uploading}
                      onClick={() => fileInputRef.current?.click()}
                      className={`px-4 py-2 text-xs font-bold font-sans rounded-xl flex items-center gap-2 cursor-pointer transition-all disabled:opacity-40 shadow-lg ${
                        user.role === 'artist' 
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950' 
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                      }`}
                    >
                      {uploading ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          Choose Device File
                        </>
                      )}
                    </button>

                    {profilePic && profilePic.startsWith('/uploads/') && (
                      <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono font-semibold">
                        <FileCheck className="w-3.5 h-3.5" />
                        Uploaded: Ready to apply!
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* General form fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Display Name Input */}
              <div className="space-y-2">
                <label className="text-[11.5px] uppercase tracking-widest text-slate-400 font-mono font-bold block">Display Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-3.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="E.g. Mahabub Rahman"
                    maxLength={50}
                    className="w-full bg-slate-950 border border-white/5 focus:border-amber-400/40 pl-11 pr-4 py-3 rounded-xl text-xs text-slate-200 placeholder:text-slate-700 focus:outline-none transition-all font-sans font-medium"
                    required
                  />
                </div>
              </div>

              {/* Mobile Contact Number */}
              <div className="space-y-2">
                <label className="text-[11.5px] uppercase tracking-widest text-slate-400 font-mono font-bold block">Mobile Contact Number</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-3.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="tel" 
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="e.g. 01700000000"
                    className="w-full bg-slate-950 border border-white/5 focus:border-amber-400/40 pl-11 pr-4 py-3 rounded-xl text-xs text-slate-210 placeholder:text-slate-700 focus:outline-none transition-all font-mono"
                  />
                </div>
              </div>
            </div>

            {/* =========================================================================
                ARTIST-SPECIFIC EDITING FORM FIELDS
                ========================================================================= */}
            {user.role === 'artist' && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-6 pt-2 border-t border-white/[0.04]"
              >
                {/* 1. Artist Bio */}
                <div className="space-y-2">
                  <label className="text-[11.5px] uppercase tracking-widest text-[#fbbf24] font-mono font-bold block">
                    Biography & Diagram Shading Accents
                  </label>
                  <textarea
                    rows={3}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Present your drawing tools, accuracy metrics, shading experience (e.g., HB/2B pencil gradient, physiology sketch plate precision)..."
                    className="w-full bg-slate-950 border border-white/5 focus:border-amber-400/40 p-4 rounded-xl text-xs text-slate-200 placeholder:text-slate-700 focus:outline-none transition-all resize-none leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* 2. Drawing Rate per diagram */}
                  <div className="space-y-2">
                    <label className="text-[11.5px] uppercase tracking-widest text-[#fbbf24] font-mono font-bold block">
                      Sketch Rate (৳ BDT Per Sheet)
                    </label>
                    <div className="relative">
                      <span className="absolute left-4 top-3 text-sm text-slate-500 font-mono font-bold">৳</span>
                      <input 
                        type="number"
                        min={30}
                        max={3000}
                        value={ratePerDrawing}
                        onChange={(e) => setRatePerDrawing(Number(e.target.value) || 120)}
                        className="w-full bg-slate-950 border border-white/5 focus:border-amber-400/40 pl-9 pr-4 py-3 rounded-xl text-xs text-amber-300 font-mono font-bold focus:outline-none"
                      />
                    </div>
                    <span className="text-[9.5px] text-slate-500 block italic">Student pays this amount per drawing Plate. Range: ৳30 - ৳3,000.</span>
                  </div>

                  {/* 3. Availability Slider */}
                  <div className="space-y-2">
                    <label className="text-[11.5px] uppercase tracking-widest text-[#fbbf24] font-mono font-bold block">
                      Contracts Intake Status
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsAvailable(!isAvailable)}
                      className={`w-full py-3 rounded-xl border font-sans text-xs font-bold transition-all duration-200 cursor-pointer flex items-center justify-center gap-2.5 ${
                        isAvailable 
                          ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' 
                          : 'bg-rose-500/10 border-rose-500/20 text-rose-450'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${isAvailable ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
                      <span>{isAvailable ? 'ACCEPTING ACTIVE COMMISSIONS' : 'GO OFF-DUTY (BUSY / CLOSED)'}</span>
                    </button>
                    <span className="text-[9.5px] text-slate-500 block italic">Students can only book you from the drawing marketplace if active.</span>
                  </div>
                </div>

                {/* 4. Specialties Tag Manager */}
                <div className="space-y-2">
                  <label className="text-[11.5px] uppercase tracking-widest text-[#fbbf24] font-mono font-bold block">
                    Specialties Tags Catalog
                  </label>
                  
                  {/* Preloaded tags container */}
                  <div className="flex flex-wrap gap-1.5 p-3 rounded-xl bg-slate-950/65 border border-white/5 min-h-[44px]">
                    {specialties.length === 0 ? (
                      <span className="text-[10px] text-slate-650 italic self-center">No specialized subject keywords registered yet.</span>
                    ) : (
                      specialties.map((tag, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded-lg bg-slate-900 border border-white/10 text-[9.5px] text-slate-300 flex items-center gap-1.5 font-mono select-none">
                          {tag}
                          <button
                            type="button"
                            onClick={() => handleRemoveSpecialtyTag(idx)}
                            className="text-rose-400 hover:text-white font-bold font-mono focus:outline-none focus:ring-0"
                          >
                            ×
                          </button>
                        </span>
                      ))
                    )}
                  </div>

                  {/* Add tag field */}
                  <div className="flex gap-2 pt-1">
                    <input 
                      type="text"
                      placeholder="e.g. Physics Circuits, Mammal Anatomies, Botany Cross-sections"
                      value={newTagInput}
                      onChange={(e) => setNewTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddSpecialtyTag();
                        }
                      }}
                      className="flex-1 bg-slate-950 border border-white/10 px-4 py-2 text-xs rounded-xl focus:outline-none focus:border-amber-400/40 text-slate-100 placeholder:text-slate-700"
                    />
                    <button
                      type="button"
                      onClick={handleAddSpecialtyTag}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-400 font-black font-mono text-xs rounded-xl"
                    >
                      ADD TAG
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* General submit blocks */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-between border-t border-white/[0.04] gap-4">
              <span className="text-[10px] uppercase font-mono text-slate-500 flex items-center gap-1.5 self-start sm:self-auto">
                <Lock className="w-4 h-4 text-slate-600" /> SECURE CONNECTION ESTABLISHED
              </span>
              
              <button
                type="submit"
                disabled={saving || uploading}
                className={`w-full sm:w-auto px-6 py-3 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 shadow-lg transition-all select-none cursor-pointer disabled:opacity-40 hover:scale-[1.01] active:scale-95 ${
                  user.role === 'artist'
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/10'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-650/15'
                }`}
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving changes...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save & Apply Credentials
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* =========================================================================
          COSMIC PORTFOLIO SHOWCASE GALLERY (Extraordinary, uniquely outstanding visual blocks)
          ========================================================================= */}
      {user.role === 'artist' && (
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6 bg-[#070b15]/40 backdrop-blur-xl border border-white/5 rounded-3xl p-6 md:p-8"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.04] pb-4">
            <div className="space-y-1">
              <h2 className="text-xl md:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2.5">
                <Palette className="text-amber-400 w-6 h-6 shrink-0" />
                Live Portfolio Portfolio Workspace
              </h2>
              <p className="text-xs text-slate-400">
                These drawings are listed live on the student commissions page. Upload clear, hand-colored drawing pages to verify your craft.
              </p>
            </div>

            <div className="flex items-center">
              <input 
                type="file"
                ref={sampleInputRef}
                onChange={handlePortfolioDrawingUpload}
                accept="image/jpeg,image/png,image/webp,image/gif"
                className="hidden"
              />
              <button 
                type="button"
                disabled={uploadingSample}
                onClick={() => sampleInputRef.current?.click()}
                className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs rounded-xl uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/10 active:scale-95 transition-all cursor-pointer select-none"
              >
                {uploadingSample ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Publishing upload...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    Upload & Publish Real Drawing
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Uniquely Beautiful Masonry Portfolio Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 pt-2">
            {samples.map((url, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.05 }}
                className="group relative h-64 rounded-2xl overflow-hidden border border-white/5 bg-slate-950/85 hover:border-amber-500/35 shadow-xl transition-all duration-300"
              >
                {/* Image */}
                <img 
                  src={url} 
                  alt={`Portfolio Sketch block #${idx}`} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />

                {/* Subtle paper texture/shade vignette overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-60 pointer-events-none" />

                {/* Info Overlay inside portfolio item */}
                <div className="absolute bottom-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none translate-y-1 group-hover:translate-y-0 transition-transform duration-300">
                  <span className="text-[10px] font-mono uppercase bg-slate-950/90 border border-white/10 text-slate-300 px-2 py-0.5 rounded-md shadow-md">
                    Diagram #{idx + 1}
                  </span>
                  <span className="text-[9px] font-sans font-bold bg-amber-450 text-slate-950 px-2 py-0.5 rounded-md shadow-md uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Live View
                  </span>
                </div>

                {/* Interactive Glassmorphic Delete overlay */}
                <div className="absolute inset-x-0 top-0 p-3 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <button
                    type="button"
                    onClick={() => handleRemovePortfolioDrawing(idx)}
                    className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white shadow-lg pointer-events-auto cursor-pointer flex items-center justify-center transition-all hover:scale-110 active:scale-95"
                    title="Remove Specimen from Portfolio"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            ))}

            {samples.length === 0 && (
              <div className="col-span-1 sm:col-span-2 md:col-span-4 py-16 text-center space-y-4 border-2 border-dashed border-white/5 rounded-2xl bg-white/[0.01]">
                <Palette className="w-12 h-12 text-slate-600 mx-auto animate-pulse" />
                <div className="space-y-1 max-w-sm mx-auto">
                  <h4 className="font-extrabold text-white text-sm">Portfolio Portfolio Empty</h4>
                  <p className="text-xs text-slate-500 leading-normal">
                    You have not published any diagnostic drawing sheets yet. Upload your physics circuits, biology sketches, and chemistry setups to showcase your skills and get hired!
                  </p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};
