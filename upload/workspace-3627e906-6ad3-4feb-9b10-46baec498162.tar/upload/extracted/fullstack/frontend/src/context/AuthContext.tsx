import React, { createContext, useContext, useState, useEffect } from 'react';
import { safeLocalStorage } from '../lib/storage';

export interface UserType {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin' | 'artist';
  studyTime: number;
  profilePic?: string;
  phoneNumber?: string;
  isAdminStudent?: boolean;
  isPremium?: boolean;
  paymentHistory?: any[];
  aiCredits?: number;
}

export interface AuthContextProps {
  token: string | null;
  user: UserType | null;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
  isAuthenticated: boolean;
  isLoading: boolean;
  geminiApiKey: string;
  setGeminiApiKey: (key: string) => void;
  isKeyModalOpen: boolean;
  setIsKeyModalOpen: (open: boolean) => void;
  login: (token: string, user: UserType) => void;
  logout: () => void;
  apiFetch: (url: string, options?: RequestInit) => Promise<Response>;
  updateUserStudyTime: (seconds: number) => Promise<void>;
  updateSession: (token: string, user: UserType) => void;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(safeLocalStorage.getItem('png_token'));
  const [user, setUser] = useState<UserType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [geminiApiKey, setGeminiApiKeyState] = useState<string>(() => safeLocalStorage.getItem('user_gemini_key') || '');
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);

  const setGeminiApiKey = (key: string) => {
    const trimmed = key.trim();
    setGeminiApiKeyState(trimmed);
    if (trimmed) {
      safeLocalStorage.setItem('user_gemini_key', trimmed);
    } else {
      safeLocalStorage.removeItem('user_gemini_key');
    }
  };

  // Helper fetch method which automatically attaches Bearer auth header and optional Google Account Gemini API Key header
  const apiFetch = async (url: string, options: RequestInit = {}): Promise<Response> => {
    const activeToken = token || safeLocalStorage.getItem('png_token');
    const customGeminiKey = geminiApiKey || safeLocalStorage.getItem('user_gemini_key');
    const headers = {
      ...(options.headers || {}),
    } as Record<string, string>;

    if (activeToken) {
      headers['Authorization'] = `Bearer ${activeToken}`;
    }
    if (customGeminiKey && customGeminiKey.trim()) {
      headers['x-gemini-api-key'] = customGeminiKey.trim();
    }

    return fetch(url, {
      ...options,
      headers,
    });
  };

  // Check login credentials on boot
  useEffect(() => {
    const initializeAuth = async () => {
      const activeToken = safeLocalStorage.getItem('png_token');
      if (activeToken) {
        try {
          const res = await fetch('/api/auth/me', {
            headers: {
              'Authorization': `Bearer ${activeToken}`
            }
          });
          if (res.ok) {
            const data = await res.json();
            if (data.user) {
              setUser(data.user);
            } else {
              // Token was invalid on the server side
              safeLocalStorage.removeItem('png_token');
              setToken(null);
            }
          } else {
            safeLocalStorage.removeItem('png_token');
            setToken(null);
          }
        } catch (err) {
          console.error("Failed to authenticate session token on startup:", err);
        }
      }
      setIsLoading(false);
    };

    initializeAuth();
  }, [token]);

  // Handle successful logins
  const login = (newToken: string, newUser: UserType) => {
    safeLocalStorage.setItem('png_token', newToken);
    setToken(newToken);
    setUser(newUser);
  };

  // Update session on profile modifications
  const updateSession = (newToken: string, newUser: UserType) => {
    safeLocalStorage.setItem('png_token', newToken);
    setToken(newToken);
    setUser(newUser);
  };

  // Perform session destruction
  const logout = () => {
    safeLocalStorage.removeItem('png_token');
    setToken(null);
    setUser(null);
  };

  // Increment user cumulative logs securely in the database
  const updateUserStudyTime = async (seconds: number) => {
    try {
      const res = await apiFetch('/api/auth/track-time', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ seconds }),
      });
      if (res.ok) {
        const data = await res.json();
        if (typeof data.studyTime === 'number' && user) {
          setUser({ ...user, studyTime: data.studyTime });
        }
      }
    } catch (err) {
      console.error("Could not register study session details:", err);
    }
  };

  const [language, setLanguageState] = useState<'en' | 'bn'>(() => {
    const saved = safeLocalStorage.getItem('png_lang');
    return (saved === 'bn' || saved === 'en') ? (saved as 'en' | 'bn') : 'en';
  });

  const setLanguage = (lang: 'en' | 'bn') => {
    setLanguageState(lang);
    safeLocalStorage.setItem('png_lang', lang);
  };

  const isAuthenticated = !!token && !!user;

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        setUser,
        isAuthenticated,
        isLoading,
        geminiApiKey,
        setGeminiApiKey,
        isKeyModalOpen,
        setIsKeyModalOpen,
        login,
        logout,
        apiFetch,
        updateUserStudyTime,
        updateSession,
        language,
        setLanguage,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be called from within an AuthProvider root context node');
  }
  return context;
};
