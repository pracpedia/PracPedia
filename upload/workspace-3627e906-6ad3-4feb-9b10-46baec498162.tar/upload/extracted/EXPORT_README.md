# 📚 MERN Practical Notebook Gallery — Developer Guide

Welcome to the **Practical Notebook Gallery**, a beautiful, next-generation cloud catalog platform configured to organize chemistry and general science notebooks inside interactive folder hierarchies.

This guide provides a walk-through on how to run, scale, and host both the **React Frontend** and the **Express/Node.js MongoDB Backend** on your local machine using VS Code.

---

## 📂 PROJECT STRUCTURE
The codebase is structured under the `fullstack` subdirectory containing our frontend and backend workspaces:

```
├── fullstack/
│   ├── backend/            # Express, Mongoose, JWT and Multer backend architecture
│   │   ├── config/             # Database connection triggers
│   │   ├── controllers/        # Logical controllers processing database calls
│   │   ├── middleware/         # Security checks and Admin tokens filters
│   │   ├── models/             # Mongoose schemas (Users, Subjects, Practicals)
│   │   ├── routes/             # API Routers mapping urls to controller sequences
│   │   ├── uploads/            # Local folder preserving uploaded physical sheets
│   │   └── server.ts           # Server entry point
│   │
│   └── frontend/           # React Client codebase under Vite
│       ├── public/
│       └── src/
│           ├── components/     # Custom modular components (Sidebar, Lightbox, Stats)
│           ├── context/        # React Context API validating logins & JWTs
│           ├── pages/          # Full visual screens (Landing, Auth, Console)
│           ├── index.css       # Tailwind utility configuration
│           ├── App.tsx         # App orchestrator & navigation pipelines
│           └── main.tsx        # Client bootstrapper
```

---

## 🛠️ LOCAL CONFIGURATION STEPS (VS CODE)

Follow these directions to configure and boot the MERN stack locally from scratch:

### 1️⃣ PREREQUISITES
Ensure you have the following installed on your developer workstation:
*   [Node.js (v18+)](https://nodejs.org/)
*   [MongoDB Community Server](https://www.mongodb.com/try/download/community) (Or set up a free cluster on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas))

---

### 2️⃣ BACKEND DEPLOYMENT & BOOTING
1. Open your terminal in VS Code and locate the server directory:
   ```bash
   cd fullstack/backend
   ```
2. Build the dependency modules required by Express, Mongoose, JWT, and Multer:
   ```bash
   npm install
   ```
3. Initialize credentials by copying the example environment variables:
   ```bash
   cp .env.example .env
   ```
4. Update the newly created `.env` file with your credentials:
   ```env
   # fullstack/backend/.env file
   PORT=5000
   JWT_SECRET=your_super_secret_session_encryption_key_2026
   MONGO_URI=mongodb://localhost:27017/practical_notebook_gallery
   ```
5. Ensure your local MongoDB Service is active, then launch the Express API layer:
   ```bash
   # In development mode
   npm run dev
   
   # Or standard production mode
   npm start
   ```
   *The backend console will print:* `MongoDB Connected: localhost` and `Backend Server booted on port 5000`.

---

### 3️⃣ FRONTEND DEPLOYMENT & BOOTING
1. Split your terminal window inside VS Code to launch a concurrent shell node, and step inside the layout directory:
   ```bash
   cd fullstack/frontend
   ```
2. Build the dependencies required by React, Lucide icons, and Tailwind:
   ```bash
   npm install
   ```
3. Boot up the Vite client compilation node:
   ```bash
   npm run dev
   ```
4. Open the active development url in your local browser window:
   `http://localhost:5173`

---

## 🔑 ACTIVE USER LIFETIME DEMO PRESETS
The system automatically logs credential profiles to let you test roles immediately. Use the following profiles to test layout modes inside your local environment or the live Playground console:

### 🧑‍🔬 ADMINISTRATOR ACCREDITATION (Full Read/Write Access):
*   **Email:** `admin@gallery.com`
*   **Password:** `admin123`
*   *Actions:* Create folders, edit metadata descriptions, upload high-resolution images, delete pages.

### 🧑‍🎓 STANDARD STUDENT SCOPE (Read-Only Browsing):
*   **Email:** `student@gallery.com`
*   **Password:** `user123`
*   *Actions:* Access dashboards, click folders, explore sheets in zooming lightbox screens.
